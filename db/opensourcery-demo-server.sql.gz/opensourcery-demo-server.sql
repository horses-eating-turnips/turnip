-- MySQL dump 10.13  Distrib 5.1.49-MariaDB, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: di_local
-- ------------------------------------------------------
-- Server version	5.1.49-MariaDB-mariadb82

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access`
--

DROP TABLE IF EXISTS `access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `mask` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access`
--

LOCK TABLES `access` WRITE;
/*!40000 ALTER TABLE `access` DISABLE KEYS */;
/*!40000 ALTER TABLE `access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `aid` varchar(255) NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL DEFAULT '',
  `callback` varchar(255) NOT NULL DEFAULT '',
  `parameters` longtext NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES ('comment_publish_action','comment','comment_publish_action','','Publish comment'),('comment_unpublish_action','comment','comment_unpublish_action','','Unpublish comment'),('node_publish_action','node','node_publish_action','','Publish post'),('node_unpublish_action','node','node_unpublish_action','','Unpublish post'),('node_make_sticky_action','node','node_make_sticky_action','','Make post sticky'),('node_make_unsticky_action','node','node_make_unsticky_action','','Make post unsticky'),('node_promote_action','node','node_promote_action','','Promote post to front page'),('node_unpromote_action','node','node_unpromote_action','','Remove post from front page'),('node_save_action','node','node_save_action','','Save post'),('user_block_user_action','user','user_block_user_action','','Block current user'),('user_block_ip_action','user','user_block_ip_action','','Ban IP address of current user'),('views_bulk_operations_delete_node_action','node','views_bulk_operations_delete_node_action','','Delete node'),('views_bulk_operations_delete_user_action','user','views_bulk_operations_delete_user_action','','Delete user'),('views_bulk_operations_delete_comment_action','comment','views_bulk_operations_delete_comment_action','','Delete comment'),('views_bulk_operations_delete_term_action','term','views_bulk_operations_delete_term_action','','Delete term');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actions_aid`
--

DROP TABLE IF EXISTS `actions_aid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions_aid` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions_aid`
--

LOCK TABLES `actions_aid` WRITE;
/*!40000 ALTER TABLE `actions_aid` DISABLE KEYS */;
/*!40000 ALTER TABLE `actions_aid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advanced_help_index`
--

DROP TABLE IF EXISTS `advanced_help_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advanced_help_index` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(255) NOT NULL DEFAULT '',
  `topic` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`sid`),
  KEY `language` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advanced_help_index`
--

LOCK TABLES `advanced_help_index` WRITE;
/*!40000 ALTER TABLE `advanced_help_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `advanced_help_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authmap`
--

DROP TABLE IF EXISTS `authmap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authmap` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `authname` varchar(128) NOT NULL DEFAULT '',
  `module` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`aid`),
  UNIQUE KEY `authname` (`authname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authmap`
--

LOCK TABLES `authmap` WRITE;
/*!40000 ALTER TABLE `authmap` DISABLE KEYS */;
/*!40000 ALTER TABLE `authmap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch`
--

DROP TABLE IF EXISTS `batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(64) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `batch` longtext,
  PRIMARY KEY (`bid`),
  KEY `token` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch`
--

LOCK TABLES `batch` WRITE;
/*!40000 ALTER TABLE `batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `better_formats_defaults`
--

DROP TABLE IF EXISTS `better_formats_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `better_formats_defaults` (
  `rid` int(10) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `format` mediumint(8) unsigned NOT NULL,
  `type_weight` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `better_formats_defaults`
--

LOCK TABLES `better_formats_defaults` WRITE;
/*!40000 ALTER TABLE `better_formats_defaults` DISABLE KEYS */;
INSERT INTO `better_formats_defaults` VALUES (1,'node',0,1,0),(1,'comment',0,1,0),(1,'block',0,1,25),(2,'node',0,1,0),(2,'comment',0,1,0),(2,'block',0,1,25);
/*!40000 ALTER TABLE `better_formats_defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(64) NOT NULL DEFAULT '',
  `delta` varchar(32) NOT NULL DEFAULT '0',
  `theme` varchar(64) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  `region` varchar(64) NOT NULL DEFAULT '',
  `custom` tinyint(4) NOT NULL DEFAULT '0',
  `throttle` tinyint(4) NOT NULL DEFAULT '0',
  `visibility` tinyint(4) NOT NULL DEFAULT '0',
  `pages` text NOT NULL,
  `title` varchar(64) NOT NULL DEFAULT '',
  `cache` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `tmd` (`theme`,`module`,`delta`),
  KEY `list` (`theme`,`status`,`region`,`weight`,`module`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` VALUES (1,'user','0','garland',0,0,'',0,0,0,'','',-1),(2,'user','1','garland',0,0,'',0,0,0,'','',-1),(3,'system','0','garland',0,10,'',0,0,0,'','',-1);
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks_roles`
--

DROP TABLE IF EXISTS `blocks_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks_roles` (
  `module` varchar(64) NOT NULL,
  `delta` varchar(32) NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`module`,`delta`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks_roles`
--

LOCK TABLES `blocks_roles` WRITE;
/*!40000 ALTER TABLE `blocks_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocks_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boxes`
--

DROP TABLE IF EXISTS `boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boxes` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext,
  `info` varchar(128) NOT NULL DEFAULT '',
  `format` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `info` (`info`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boxes`
--

LOCK TABLES `boxes` WRITE;
/*!40000 ALTER TABLE `boxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `boxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_views`
--

DROP TABLE IF EXISTS `cache_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_views` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_views`
--

LOCK TABLES `cache_views` WRITE;
/*!40000 ALTER TABLE `cache_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_views_data`
--

DROP TABLE IF EXISTS `cache_views_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_views_data` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_views_data`
--

LOCK TABLES `cache_views_data` WRITE;
/*!40000 ALTER TABLE `cache_views_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_views_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `nid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(64) NOT NULL DEFAULT '',
  `comment` longtext NOT NULL,
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `format` smallint(6) NOT NULL DEFAULT '0',
  `thread` varchar(255) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `mail` varchar(64) DEFAULT NULL,
  `homepage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cid`),
  KEY `pid` (`pid`),
  KEY `nid` (`nid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_field_blog_images`
--

DROP TABLE IF EXISTS `content_field_blog_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_field_blog_images` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `delta` int(10) unsigned NOT NULL DEFAULT '0',
  `field_blog_images_fid` int(11) DEFAULT NULL,
  `field_blog_images_list` tinyint(4) DEFAULT NULL,
  `field_blog_images_data` text,
  PRIMARY KEY (`vid`,`delta`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_field_blog_images`
--

LOCK TABLES `content_field_blog_images` WRITE;
/*!40000 ALTER TABLE `content_field_blog_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_field_blog_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_field_event_image`
--

DROP TABLE IF EXISTS `content_field_event_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_field_event_image` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `delta` int(10) unsigned NOT NULL DEFAULT '0',
  `field_event_image_fid` int(11) DEFAULT NULL,
  `field_event_image_list` tinyint(4) DEFAULT NULL,
  `field_event_image_data` text,
  PRIMARY KEY (`vid`,`delta`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_field_event_image`
--

LOCK TABLES `content_field_event_image` WRITE;
/*!40000 ALTER TABLE `content_field_event_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_field_event_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_node_field`
--

DROP TABLE IF EXISTS `content_node_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_node_field` (
  `field_name` varchar(32) NOT NULL DEFAULT '',
  `type` varchar(127) NOT NULL DEFAULT '',
  `global_settings` mediumtext NOT NULL,
  `required` tinyint(4) NOT NULL DEFAULT '0',
  `multiple` tinyint(4) NOT NULL DEFAULT '0',
  `db_storage` tinyint(4) NOT NULL DEFAULT '1',
  `module` varchar(127) NOT NULL DEFAULT '',
  `db_columns` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_node_field`
--

LOCK TABLES `content_node_field` WRITE;
/*!40000 ALTER TABLE `content_node_field` DISABLE KEYS */;
INSERT INTO `content_node_field` VALUES ('field_blog_images','filefield','a:3:{s:10:\"list_field\";s:1:\"0\";s:12:\"list_default\";i:1;s:17:\"description_field\";s:1:\"0\";}',1,1,0,'filefield','a:3:{s:3:\"fid\";a:3:{s:4:\"type\";s:3:\"int\";s:8:\"not null\";b:0;s:5:\"views\";b:1;}s:4:\"list\";a:4:{s:4:\"type\";s:3:\"int\";s:4:\"size\";s:4:\"tiny\";s:8:\"not null\";b:0;s:5:\"views\";b:1;}s:4:\"data\";a:3:{s:4:\"type\";s:4:\"text\";s:9:\"serialize\";b:1;s:5:\"views\";b:1;}}',1,0),('field_event_date','datetime','a:7:{s:11:\"granularity\";a:5:{s:4:\"year\";s:4:\"year\";s:5:\"month\";s:5:\"month\";s:3:\"day\";s:3:\"day\";s:4:\"hour\";s:4:\"hour\";s:6:\"minute\";s:6:\"minute\";}s:11:\"timezone_db\";s:3:\"UTC\";s:11:\"tz_handling\";s:4:\"site\";s:6:\"todate\";s:8:\"required\";s:6:\"repeat\";i:0;s:16:\"repeat_collapsed\";s:0:\"\";s:14:\"default_format\";s:5:\"short\";}',1,0,1,'date','a:2:{s:5:\"value\";a:4:{s:4:\"type\";s:8:\"datetime\";s:8:\"not null\";b:0;s:8:\"sortable\";b:1;s:5:\"views\";b:1;}s:6:\"value2\";a:4:{s:4:\"type\";s:8:\"datetime\";s:8:\"not null\";b:0;s:8:\"sortable\";b:1;s:5:\"views\";b:0;}}',1,0),('field_event_image','filefield','a:3:{s:10:\"list_field\";s:1:\"0\";s:12:\"list_default\";i:1;s:17:\"description_field\";s:1:\"0\";}',1,1,0,'filefield','a:3:{s:3:\"fid\";a:3:{s:4:\"type\";s:3:\"int\";s:8:\"not null\";b:0;s:5:\"views\";b:1;}s:4:\"list\";a:4:{s:4:\"type\";s:3:\"int\";s:4:\"size\";s:4:\"tiny\";s:8:\"not null\";b:0;s:5:\"views\";b:1;}s:4:\"data\";a:3:{s:4:\"type\";s:4:\"text\";s:9:\"serialize\";b:1;s:5:\"views\";b:1;}}',1,0),('field_slide_image','filefield','a:3:{s:10:\"list_field\";s:1:\"0\";s:12:\"list_default\";i:1;s:17:\"description_field\";s:1:\"0\";}',1,0,1,'filefield','a:3:{s:3:\"fid\";a:3:{s:4:\"type\";s:3:\"int\";s:8:\"not null\";b:0;s:5:\"views\";b:1;}s:4:\"list\";a:4:{s:4:\"type\";s:3:\"int\";s:4:\"size\";s:4:\"tiny\";s:8:\"not null\";b:0;s:5:\"views\";b:1;}s:4:\"data\";a:3:{s:4:\"type\";s:4:\"text\";s:9:\"serialize\";b:1;s:5:\"views\";b:1;}}',1,0),('field_slide_link','link','a:7:{s:10:\"attributes\";a:4:{s:6:\"target\";s:7:\"default\";s:3:\"rel\";s:0:\"\";s:5:\"class\";s:0:\"\";s:5:\"title\";s:0:\"\";}s:7:\"display\";a:1:{s:10:\"url_cutoff\";s:2:\"80\";}s:3:\"url\";i:0;s:5:\"title\";s:8:\"required\";s:11:\"title_value\";s:0:\"\";s:13:\"enable_tokens\";i:0;s:12:\"validate_url\";i:1;}',0,0,1,'link','a:3:{s:3:\"url\";a:4:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:2048;s:8:\"not null\";b:0;s:8:\"sortable\";b:1;}s:5:\"title\";a:4:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:255;s:8:\"not null\";b:0;s:8:\"sortable\";b:1;}s:10:\"attributes\";a:3:{s:4:\"type\";s:4:\"text\";s:4:\"size\";s:6:\"medium\";s:8:\"not null\";b:0;}}',1,0);
/*!40000 ALTER TABLE `content_node_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_node_field_instance`
--

DROP TABLE IF EXISTS `content_node_field_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_node_field_instance` (
  `field_name` varchar(32) NOT NULL DEFAULT '',
  `type_name` varchar(32) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL DEFAULT '',
  `widget_type` varchar(32) NOT NULL DEFAULT '',
  `widget_settings` mediumtext NOT NULL,
  `display_settings` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `widget_module` varchar(127) NOT NULL DEFAULT '',
  `widget_active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_name`,`type_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_node_field_instance`
--

LOCK TABLES `content_node_field_instance` WRITE;
/*!40000 ALTER TABLE `content_node_field_instance` DISABLE KEYS */;
INSERT INTO `content_node_field_instance` VALUES ('field_blog_images','blog',-1,'Image(s)','imagefield_widget','a:19:{s:15:\"file_extensions\";s:16:\"png gif jpg jpeg\";s:9:\"file_path\";s:0:\"\";s:18:\"progress_indicator\";s:3:\"bar\";s:21:\"max_filesize_per_file\";s:0:\"\";s:21:\"max_filesize_per_node\";s:0:\"\";s:14:\"max_resolution\";s:1:\"0\";s:14:\"min_resolution\";s:1:\"0\";s:3:\"alt\";s:11:\"[title-raw]\";s:10:\"custom_alt\";i:0;s:5:\"title\";s:0:\"\";s:12:\"custom_title\";i:0;s:10:\"title_type\";s:9:\"textfield\";s:13:\"default_image\";N;s:17:\"use_default_image\";i:0;s:6:\"insert\";i:1;s:13:\"insert_styles\";a:8:{s:5:\"image\";s:5:\"image\";s:20:\"imagecache_blog-list\";s:20:\"imagecache_blog-list\";s:4:\"auto\";i:0;s:4:\"link\";i:0;s:21:\"imagecache_event-list\";i:0;s:25:\"imagecache_medium-content\";i:0;s:23:\"imagecache_primary-menu\";i:0;s:20:\"imagecache_menu_icon\";i:0;}s:14:\"insert_default\";s:5:\"image\";s:12:\"insert_class\";s:0:\"\";s:12:\"insert_width\";s:0:\"\";}','a:7:{s:6:\"weight\";s:2:\"-1\";s:6:\"parent\";s:0:\"\";s:5:\"label\";a:1:{s:6:\"format\";s:6:\"hidden\";}s:6:\"teaser\";a:2:{s:6:\"format\";s:6:\"hidden\";s:7:\"exclude\";i:1;}s:4:\"full\";a:2:{s:6:\"format\";s:6:\"hidden\";s:7:\"exclude\";i:1;}i:4;a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}s:5:\"token\";a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}}','','imagefield',1),('field_event_date','event',-4,'Date/time','date_popup','a:11:{s:13:\"default_value\";s:5:\"blank\";s:18:\"default_value_code\";s:0:\"\";s:14:\"default_value2\";s:4:\"same\";s:19:\"default_value_code2\";s:0:\"\";s:12:\"input_format\";s:12:\"m/d/Y - g:ia\";s:19:\"input_format_custom\";s:0:\"\";s:9:\"increment\";s:1:\"1\";s:10:\"text_parts\";a:0:{}s:10:\"year_range\";s:5:\"-3:+3\";s:14:\"label_position\";s:5:\"above\";s:10:\"single_day\";i:1;}','a:5:{s:5:\"label\";a:2:{s:6:\"format\";s:5:\"above\";s:7:\"exclude\";i:0;}s:6:\"teaser\";a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}s:4:\"full\";a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}i:4;a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}s:5:\"token\";a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}}','','date',1),('field_event_image','event',-2,'Image(s)','imagefield_widget','a:19:{s:15:\"file_extensions\";s:16:\"png gif jpg jpeg\";s:9:\"file_path\";s:0:\"\";s:18:\"progress_indicator\";s:3:\"bar\";s:21:\"max_filesize_per_file\";s:0:\"\";s:21:\"max_filesize_per_node\";s:0:\"\";s:14:\"max_resolution\";s:1:\"0\";s:14:\"min_resolution\";s:1:\"0\";s:3:\"alt\";s:11:\"[title-raw]\";s:10:\"custom_alt\";i:0;s:5:\"title\";s:0:\"\";s:12:\"custom_title\";i:0;s:10:\"title_type\";s:9:\"textfield\";s:13:\"default_image\";N;s:17:\"use_default_image\";i:0;s:6:\"insert\";N;s:13:\"insert_styles\";N;s:14:\"insert_default\";N;s:12:\"insert_class\";N;s:12:\"insert_width\";N;}','a:5:{s:5:\"label\";a:2:{s:6:\"format\";s:5:\"above\";s:7:\"exclude\";i:0;}s:6:\"teaser\";a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}s:4:\"full\";a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}i:4;a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}s:5:\"token\";a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}}','','imagefield',1),('field_slide_image','slide',-4,'Slide image','imagefield_widget','a:19:{s:15:\"file_extensions\";s:16:\"png gif jpg jpeg\";s:9:\"file_path\";s:6:\"slides\";s:18:\"progress_indicator\";s:3:\"bar\";s:21:\"max_filesize_per_file\";s:0:\"\";s:21:\"max_filesize_per_node\";s:0:\"\";s:14:\"max_resolution\";s:1:\"0\";s:14:\"min_resolution\";s:7:\"960x320\";s:3:\"alt\";s:0:\"\";s:10:\"custom_alt\";i:1;s:5:\"title\";s:0:\"\";s:12:\"custom_title\";i:0;s:10:\"title_type\";s:9:\"textfield\";s:13:\"default_image\";N;s:17:\"use_default_image\";i:0;s:6:\"insert\";N;s:13:\"insert_styles\";N;s:14:\"insert_default\";N;s:12:\"insert_class\";N;s:12:\"insert_width\";N;}','a:5:{s:5:\"label\";a:2:{s:6:\"format\";s:5:\"above\";s:7:\"exclude\";i:0;}s:6:\"teaser\";a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}s:4:\"full\";a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}i:4;a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}s:5:\"token\";a:2:{s:6:\"format\";s:11:\"image_plain\";s:7:\"exclude\";i:0;}}','Any image size with at least enough resolution to look good on the homepage slideshow.','imagefield',1),('field_slide_link','slide',-2,'Link','link','a:2:{s:13:\"default_value\";a:1:{i:0;a:2:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:0:\"\";}}s:17:\"default_value_php\";N;}','a:5:{s:5:\"label\";a:2:{s:6:\"format\";s:5:\"above\";s:7:\"exclude\";i:0;}s:6:\"teaser\";a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}s:4:\"full\";a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}i:4;a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}s:5:\"token\";a:2:{s:6:\"format\";s:7:\"default\";s:7:\"exclude\";i:0;}}','','link',1);
/*!40000 ALTER TABLE `content_node_field_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_type_blog`
--

DROP TABLE IF EXISTS `content_type_blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_type_blog` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_type_blog`
--

LOCK TABLES `content_type_blog` WRITE;
/*!40000 ALTER TABLE `content_type_blog` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_type_blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_type_event`
--

DROP TABLE IF EXISTS `content_type_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_type_event` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `field_event_date_value` datetime DEFAULT NULL,
  `field_event_date_value2` datetime DEFAULT NULL,
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_type_event`
--

LOCK TABLES `content_type_event` WRITE;
/*!40000 ALTER TABLE `content_type_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_type_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_type_slide`
--

DROP TABLE IF EXISTS `content_type_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_type_slide` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `field_slide_image_fid` int(11) DEFAULT NULL,
  `field_slide_image_list` tinyint(4) DEFAULT NULL,
  `field_slide_image_data` text,
  `field_slide_link_url` varchar(2048) DEFAULT NULL,
  `field_slide_link_title` varchar(255) DEFAULT NULL,
  `field_slide_link_attributes` mediumtext,
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_type_slide`
--

LOCK TABLES `content_type_slide` WRITE;
/*!40000 ALTER TABLE `content_type_slide` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_type_slide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `context`
--

DROP TABLE IF EXISTS `context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `context` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `tag` varchar(255) NOT NULL DEFAULT '',
  `conditions` text,
  `reactions` text,
  `condition_mode` int(11) DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `context`
--

LOCK TABLES `context` WRITE;
/*!40000 ALTER TABLE `context` DISABLE KEYS */;
/*!40000 ALTER TABLE `context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ctools_css_cache`
--

DROP TABLE IF EXISTS `ctools_css_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ctools_css_cache` (
  `cid` varchar(128) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `css` longtext,
  `filter` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ctools_css_cache`
--

LOCK TABLES `ctools_css_cache` WRITE;
/*!40000 ALTER TABLE `ctools_css_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `ctools_css_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ctools_object_cache`
--

DROP TABLE IF EXISTS `ctools_object_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ctools_object_cache` (
  `sid` varchar(64) NOT NULL,
  `name` varchar(128) NOT NULL,
  `obj` varchar(32) NOT NULL,
  `updated` int(10) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`sid`,`obj`,`name`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ctools_object_cache`
--

LOCK TABLES `ctools_object_cache` WRITE;
/*!40000 ALTER TABLE `ctools_object_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `ctools_object_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `date_format_locale`
--

DROP TABLE IF EXISTS `date_format_locale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `date_format_locale` (
  `format` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `type` varchar(200) NOT NULL,
  `language` varchar(12) NOT NULL,
  PRIMARY KEY (`type`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `date_format_locale`
--

LOCK TABLES `date_format_locale` WRITE;
/*!40000 ALTER TABLE `date_format_locale` DISABLE KEYS */;
/*!40000 ALTER TABLE `date_format_locale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `date_format_types`
--

DROP TABLE IF EXISTS `date_format_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `date_format_types` (
  `type` varchar(200) NOT NULL,
  `title` varchar(255) NOT NULL,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `date_format_types`
--

LOCK TABLES `date_format_types` WRITE;
/*!40000 ALTER TABLE `date_format_types` DISABLE KEYS */;
INSERT INTO `date_format_types` VALUES ('long','Long',1),('medium','Medium',1),('short','Short',1),('day','Day',1),('time','Time',1);
/*!40000 ALTER TABLE `date_format_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `date_formats`
--

DROP TABLE IF EXISTS `date_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `date_formats` (
  `dfid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `format` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `type` varchar(200) NOT NULL,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dfid`),
  UNIQUE KEY `formats` (`format`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `date_formats`
--

LOCK TABLES `date_formats` WRITE;
/*!40000 ALTER TABLE `date_formats` DISABLE KEYS */;
INSERT INTO `date_formats` VALUES (1,'Y-m-d H:i','short',1),(2,'m/d/Y - H:i','short',1),(3,'d/m/Y - H:i','short',1),(4,'Y/m/d - H:i','short',1),(5,'d.m.Y - H:i','short',1),(6,'m/d/Y - g:ia','short',1),(7,'d/m/Y - g:ia','short',1),(8,'Y/m/d - g:ia','short',1),(9,'M j Y - H:i','short',1),(10,'j M Y - H:i','short',1),(11,'Y M j - H:i','short',1),(12,'M j Y - g:ia','short',1),(13,'j M Y - g:ia','short',1),(14,'Y M j - g:ia','short',1),(15,'D, Y-m-d H:i','medium',1),(16,'D, m/d/Y - H:i','medium',1),(17,'D, d/m/Y - H:i','medium',1),(18,'D, Y/m/d - H:i','medium',1),(19,'F j, Y - H:i','medium',1),(20,'j F, Y - H:i','medium',1),(21,'Y, F j - H:i','medium',1),(22,'D, m/d/Y - g:ia','medium',1),(23,'D, d/m/Y - g:ia','medium',1),(24,'D, Y/m/d - g:ia','medium',1),(25,'F j, Y - g:ia','medium',1),(26,'j F Y - g:ia','medium',1),(27,'Y, F j - g:ia','medium',1),(28,'j. F Y - G:i','medium',1),(29,'l, F j, Y - H:i','long',1),(30,'l, j F, Y - H:i','long',1),(31,'l, Y,  F j - H:i','long',1),(32,'l, F j, Y - g:ia','long',1),(33,'l, j F Y - g:ia','long',1),(34,'l, Y,  F j - g:ia','long',1),(35,'l, j. F Y - G:i','long',1),(36,'j F Y','day',1),(37,'l, M j','day',1),(38,'l, j M','day',1),(39,'n/j/Y','day',1),(40,'g:ia','time',1),(41,'H:i','time',1),(42,'g:ia T','time',1);
/*!40000 ALTER TABLE `date_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devel_queries`
--

DROP TABLE IF EXISTS `devel_queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devel_queries` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `function` varchar(255) NOT NULL DEFAULT '',
  `query` text NOT NULL,
  `hash` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `qid` (`qid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devel_queries`
--

LOCK TABLES `devel_queries` WRITE;
/*!40000 ALTER TABLE `devel_queries` DISABLE KEYS */;
/*!40000 ALTER TABLE `devel_queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devel_times`
--

DROP TABLE IF EXISTS `devel_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devel_times` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `time` float DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `qid` (`qid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devel_times`
--

LOCK TABLES `devel_times` WRITE;
/*!40000 ALTER TABLE `devel_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `devel_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `filemime` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `uid` (`uid`),
  KEY `status` (`status`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_formats`
--

DROP TABLE IF EXISTS `filter_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filter_formats` (
  `format` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `roles` varchar(255) NOT NULL DEFAULT '',
  `cache` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`format`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_formats`
--

LOCK TABLES `filter_formats` WRITE;
/*!40000 ALTER TABLE `filter_formats` DISABLE KEYS */;
INSERT INTO `filter_formats` VALUES (1,'Filtered HTML',',1,2,',1),(2,'Full HTML','',1);
/*!40000 ALTER TABLE `filter_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filters` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `format` int(11) NOT NULL DEFAULT '0',
  `module` varchar(64) NOT NULL DEFAULT '',
  `delta` tinyint(4) NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `fmd` (`format`,`module`,`delta`),
  KEY `list` (`format`,`weight`,`module`,`delta`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters`
--

LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
INSERT INTO `filters` VALUES (1,1,'filter',2,0),(2,1,'filter',0,1),(3,1,'filter',1,2),(4,1,'filter',3,10),(5,2,'filter',2,0),(6,2,'filter',1,1),(7,2,'filter',3,10);
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flood`
--

DROP TABLE IF EXISTS `flood`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flood` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(64) NOT NULL DEFAULT '',
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `allow` (`event`,`hostname`,`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flood`
--

LOCK TABLES `flood` WRITE;
/*!40000 ALTER TABLE `flood` DISABLE KEYS */;
/*!40000 ALTER TABLE `flood` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_custom`
--

DROP TABLE IF EXISTS `menu_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_custom` (
  `menu_name` varchar(32) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  PRIMARY KEY (`menu_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_custom`
--

LOCK TABLES `menu_custom` WRITE;
/*!40000 ALTER TABLE `menu_custom` DISABLE KEYS */;
INSERT INTO `menu_custom` VALUES ('navigation','Navigation','The navigation menu is provided by Drupal and is the main interactive menu for any site. It is usually the only menu that contains personalized links for authenticated users, and is often not even visible to anonymous users.'),('primary-links','Primary links','Primary links are often used at the theme layer to show the major sections of a site. A typical representation for primary links would be tabs along the top.'),('secondary-links','Secondary links','Secondary links are often used for pages like legal notices, contact details, and other secondary navigation items that play a lesser role than primary links'),('devel','Development','Development links.'),('features','Features','Menu items for any enabled features.');
/*!40000 ALTER TABLE `menu_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_links`
--

DROP TABLE IF EXISTS `menu_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_links` (
  `menu_name` varchar(32) NOT NULL DEFAULT '',
  `mlid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plid` int(10) unsigned NOT NULL DEFAULT '0',
  `link_path` varchar(255) NOT NULL DEFAULT '',
  `router_path` varchar(255) NOT NULL DEFAULT '',
  `link_title` varchar(255) NOT NULL DEFAULT '',
  `options` text,
  `module` varchar(255) NOT NULL DEFAULT 'system',
  `hidden` smallint(6) NOT NULL DEFAULT '0',
  `external` smallint(6) NOT NULL DEFAULT '0',
  `has_children` smallint(6) NOT NULL DEFAULT '0',
  `expanded` smallint(6) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `depth` smallint(6) NOT NULL DEFAULT '0',
  `customized` smallint(6) NOT NULL DEFAULT '0',
  `p1` int(10) unsigned NOT NULL DEFAULT '0',
  `p2` int(10) unsigned NOT NULL DEFAULT '0',
  `p3` int(10) unsigned NOT NULL DEFAULT '0',
  `p4` int(10) unsigned NOT NULL DEFAULT '0',
  `p5` int(10) unsigned NOT NULL DEFAULT '0',
  `p6` int(10) unsigned NOT NULL DEFAULT '0',
  `p7` int(10) unsigned NOT NULL DEFAULT '0',
  `p8` int(10) unsigned NOT NULL DEFAULT '0',
  `p9` int(10) unsigned NOT NULL DEFAULT '0',
  `updated` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mlid`),
  KEY `path_menu` (`link_path`(128),`menu_name`),
  KEY `menu_plid_expand_child` (`menu_name`,`plid`,`expanded`,`has_children`),
  KEY `menu_parents` (`menu_name`,`p1`,`p2`,`p3`,`p4`,`p5`,`p6`,`p7`,`p8`,`p9`),
  KEY `router_path` (`router_path`(128))
) ENGINE=MyISAM AUTO_INCREMENT=455 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_links`
--

LOCK TABLES `menu_links` WRITE;
/*!40000 ALTER TABLE `menu_links` DISABLE KEYS */;
INSERT INTO `menu_links` VALUES ('admin',1,0,'admin','admin','Administer','a:0:{}','system',0,0,1,0,9,1,0,1,0,0,0,0,0,0,0,0,0),('navigation',2,0,'node','node','Content','a:0:{}','system',-1,0,0,0,0,1,0,2,0,0,0,0,0,0,0,0,0),('navigation',3,0,'batch','batch','','a:0:{}','system',-1,0,0,0,0,1,0,3,0,0,0,0,0,0,0,0,0),('navigation',4,0,'logout','logout','Log out','a:0:{}','system',0,0,0,0,10,1,0,4,0,0,0,0,0,0,0,0,0),('navigation',5,0,'rss.xml','rss.xml','RSS feed','a:0:{}','system',-1,0,0,0,0,1,0,5,0,0,0,0,0,0,0,0,0),('navigation',6,0,'user','user','User account','a:0:{}','system',-1,0,0,0,0,1,0,6,0,0,0,0,0,0,0,0,0),('navigation',7,0,'admin_menu/toggle-modules','admin_menu/toggle-modules','','a:0:{}','system',-1,0,0,0,0,1,0,7,0,0,0,0,0,0,0,0,0),('navigation',8,0,'node/%','node/%','','a:0:{}','system',-1,0,0,0,0,1,0,8,0,0,0,0,0,0,0,0,0),('navigation',9,0,'admin_menu/flush-cache','admin_menu/flush-cache','','a:0:{}','system',-1,0,0,0,0,1,0,9,0,0,0,0,0,0,0,0,0),('admin',10,1,'admin/compact','admin/compact','Compact mode','a:0:{}','system',-1,0,0,0,0,2,0,1,10,0,0,0,0,0,0,0,0),('navigation',11,0,'filter/tips','filter/tips','Compose tips','a:0:{}','system',1,0,0,0,0,1,0,11,0,0,0,0,0,0,0,0,0),('admin',12,1,'admin/content','admin/content','Content management','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:27:\"Manage your site\'s content.\";}}','system',0,0,1,0,-10,2,0,1,12,0,0,0,0,0,0,0,0),('navigation',13,0,'node/add','node/add','Create content','a:0:{}','system',0,0,1,0,1,1,0,13,0,0,0,0,0,0,0,0,0),('navigation',14,0,'system/files','system/files','File download','a:0:{}','system',-1,0,0,0,0,1,0,14,0,0,0,0,0,0,0,0,0),('admin',15,1,'admin/help','admin/help','Help','a:0:{}','system',0,0,0,0,9,2,0,1,15,0,0,0,0,0,0,0,0),('admin',16,1,'admin/reports','admin/reports','Reports','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:59:\"View reports from system logs and other status information.\";}}','system',0,0,1,0,5,2,0,1,16,0,0,0,0,0,0,0,0),('admin',17,1,'admin/build','admin/build','Site building','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:38:\"Control how your site looks and feels.\";}}','system',0,0,1,0,-10,2,0,1,17,0,0,0,0,0,0,0,0),('admin',18,1,'admin/settings','admin/settings','Site configuration','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:40:\"Adjust basic site configuration options.\";}}','system',0,0,1,0,-5,2,0,1,18,0,0,0,0,0,0,0,0),('navigation',19,0,'user/autocomplete','user/autocomplete','User autocomplete','a:0:{}','system',-1,0,0,0,0,1,0,19,0,0,0,0,0,0,0,0,0),('admin',20,1,'admin/user','admin/user','User management','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:61:\"Manage your site\'s users, groups and access to site features.\";}}','system',0,0,1,0,0,2,0,1,20,0,0,0,0,0,0,0,0),('navigation',21,0,'user/%','user/%','My account','a:0:{}','system',0,0,0,0,0,1,0,21,0,0,0,0,0,0,0,0,0),('admin',22,20,'admin/user/rules','admin/user/rules','Access rules','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:80:\"List and create rules to disallow usernames, e-mail addresses, and IP addresses.\";}}','system',0,0,0,0,0,3,0,1,20,22,0,0,0,0,0,0,0),('admin',23,18,'admin/settings/actions','admin/settings/actions','Actions','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:41:\"Manage the actions defined for your site.\";}}','system',0,0,0,0,0,3,0,1,18,23,0,0,0,0,0,0,0),('admin',24,18,'admin/settings/admin_menu','admin/settings/admin_menu','Administration menu','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:36:\"Adjust administration menu settings.\";}}','system',0,0,0,0,0,3,0,1,18,24,0,0,0,0,0,0,0),('admin',25,18,'admin/settings/admin','admin/settings/admin','Administration tools','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:39:\"Settings for site administration tools.\";}}','system',0,0,0,0,0,3,0,1,18,25,0,0,0,0,0,0,0),('admin',26,17,'admin/build/block','admin/build/block','Blocks','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:79:\"Configure what block content appears in your site\'s sidebars and other regions.\";}}','system',0,0,0,0,0,3,0,1,17,26,0,0,0,0,0,0,0),('admin',27,18,'admin/settings/clean-urls','admin/settings/clean-urls','Clean URLs','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:43:\"Enable or disable clean URLs for your site.\";}}','system',0,0,0,0,0,3,0,1,18,27,0,0,0,0,0,0,0),('admin',28,12,'admin/content/node','admin/content/node','Content','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:43:\"View, edit, and delete your site\'s content.\";}}','system',0,0,0,0,0,3,0,1,12,28,0,0,0,0,0,0,0),('admin',29,12,'admin/content/types','admin/content/types','Content types','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:82:\"Manage posts by content type, including default status, front page promotion, etc.\";}}','system',0,0,0,0,0,3,0,1,12,29,0,0,0,0,0,0,0),('admin',30,18,'admin/settings/date-time','admin/settings/date-time','Date and time','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:89:\"Settings for how Drupal displays date and time, as well as the system\'s default timezone.\";}}','system',0,0,0,0,0,3,0,1,18,30,0,0,0,0,0,0,0),('navigation',31,0,'node/%/delete','node/%/delete','Delete','a:0:{}','system',-1,0,0,0,1,1,0,31,0,0,0,0,0,0,0,0,0),('navigation',32,21,'user/%/delete','user/%/delete','Delete','a:0:{}','system',-1,0,0,0,0,2,0,21,32,0,0,0,0,0,0,0,0),('admin',33,18,'admin/settings/error-reporting','admin/settings/error-reporting','Error reporting','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:93:\"Control how Drupal deals with errors including 403/404 errors as well as PHP error reporting.\";}}','system',0,0,0,0,0,3,0,1,18,33,0,0,0,0,0,0,0),('admin',34,18,'admin/settings/file-system','admin/settings/file-system','File system','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:68:\"Tell Drupal where to store uploaded files and how they are accessed.\";}}','system',0,0,0,0,0,3,0,1,18,34,0,0,0,0,0,0,0),('admin',35,18,'admin/settings/image-toolkit','admin/settings/image-toolkit','Image toolkit','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:74:\"Choose which image toolkit to use if you have installed optional toolkits.\";}}','system',0,0,0,0,0,3,0,1,18,35,0,0,0,0,0,0,0),('admin',36,18,'admin/settings/filters','admin/settings/filters','Input formats','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:127:\"Configure how content input by users is filtered, including allowed HTML tags. Also allows enabling of module-provided filters.\";}}','system',0,0,0,0,0,3,0,1,18,36,0,0,0,0,0,0,0),('admin',37,18,'admin/settings/logging','admin/settings/logging','Logging and alerts','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:156:\"Settings for logging and alerts modules. Various modules can route Drupal\'s system events to different destination, such as syslog, database, email, ...etc.\";}}','system',0,0,1,0,0,3,0,1,18,37,0,0,0,0,0,0,0),('admin',38,17,'admin/build/modules','admin/build/modules','Modules','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:47:\"Enable or disable add-on modules for your site.\";}}','system',0,0,0,0,0,3,0,1,17,38,0,0,0,0,0,0,0),('admin',39,18,'admin/settings/performance','admin/settings/performance','Performance','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:101:\"Enable or disable page caching for anonymous users and set CSS and JS bandwidth optimization options.\";}}','system',0,0,0,0,0,3,0,1,18,39,0,0,0,0,0,0,0),('admin',40,20,'admin/user/permissions','admin/user/permissions','Permissions','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:64:\"Determine access to features by selecting permissions for roles.\";}}','system',0,0,0,0,0,3,0,1,20,40,0,0,0,0,0,0,0),('admin',41,12,'admin/content/node-settings','admin/content/node-settings','Post settings','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:126:\"Control posting behavior, such as teaser length, requiring previews before posting, and the number of posts on the front page.\";}}','system',0,0,0,0,0,3,0,1,12,41,0,0,0,0,0,0,0),('admin',42,12,'admin/content/rss-publishing','admin/content/rss-publishing','RSS publishing','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:92:\"Configure the number of items per feed and whether feeds should be titles/teasers/full-text.\";}}','system',0,0,0,0,0,3,0,1,12,42,0,0,0,0,0,0,0),('admin',43,20,'admin/user/roles','admin/user/roles','Roles','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:30:\"List, edit, or add user roles.\";}}','system',0,0,0,0,0,3,0,1,20,43,0,0,0,0,0,0,0),('admin',44,18,'admin/settings/site-information','admin/settings/site-information','Site information','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:107:\"Change basic site information, such as the site name, slogan, e-mail address, mission, front page and more.\";}}','system',0,0,0,0,0,3,0,1,18,44,0,0,0,0,0,0,0),('admin',45,18,'admin/settings/site-maintenance','admin/settings/site-maintenance','Site maintenance','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:63:\"Take the site off-line for maintenance or bring it back online.\";}}','system',0,0,0,0,0,3,0,1,18,45,0,0,0,0,0,0,0),('admin',46,16,'admin/reports/status','admin/reports/status','Status report','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:74:\"Get a status report about your site\'s operation and any detected problems.\";}}','system',0,0,0,0,10,3,0,1,16,46,0,0,0,0,0,0,0),('navigation',47,0,'node/%/submissions','node/%/submissions','Submissions','a:0:{}','system',-1,0,0,0,0,1,0,47,0,0,0,0,0,0,0,0,0),('admin',48,17,'admin/build/themes','admin/build/themes','Themes','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:57:\"Change which theme your site uses or allows users to set.\";}}','system',0,0,0,0,0,3,0,1,17,48,0,0,0,0,0,0,0),('admin',49,20,'admin/user/settings','admin/user/settings','User settings','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:101:\"Configure default behavior of users, including registration requirements, e-mails, and user pictures.\";}}','system',0,0,0,0,0,3,0,1,20,49,0,0,0,0,0,0,0),('admin',50,20,'admin/user/user','admin/user/user','Users','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:26:\"List, add, and edit users.\";}}','system',0,0,0,0,0,3,0,1,20,50,0,0,0,0,0,0,0),('navigation',51,13,'node/add/webform','node/add/webform','Webform','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:138:\"Create a new form or questionnaire accessible to users. Submission results and statistics are recorded and accessible to privileged users.\";}}','system',0,0,0,0,0,2,0,13,51,0,0,0,0,0,0,0,0),('navigation',52,0,'node/%/done','node/%/done','Webform confirmation','a:0:{}','system',-1,0,0,0,0,1,0,52,0,0,0,0,0,0,0,0,0),('admin',53,18,'admin/settings/webform','admin/settings/webform','Webform settings','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:46:\"Global configuration of webform functionality.\";}}','system',0,0,0,0,0,3,0,1,18,53,0,0,0,0,0,0,0),('admin',54,12,'admin/content/webform','admin/content/webform','Webforms','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:54:\"View and edit all the available webforms on your site.\";}}','system',0,0,0,0,0,3,0,1,12,54,0,0,0,0,0,0,0),('admin',55,15,'admin/help/admin_menu','admin/help/admin_menu','admin_menu','a:0:{}','system',-1,0,0,0,0,3,0,1,15,55,0,0,0,0,0,0,0),('admin',56,15,'admin/help/better_formats','admin/help/better_formats','better_formats','a:0:{}','system',-1,0,0,0,0,3,0,1,15,56,0,0,0,0,0,0,0),('admin',57,15,'admin/help/block','admin/help/block','block','a:0:{}','system',-1,0,0,0,0,3,0,1,15,57,0,0,0,0,0,0,0),('admin',58,15,'admin/help/filter','admin/help/filter','filter','a:0:{}','system',-1,0,0,0,0,3,0,1,15,58,0,0,0,0,0,0,0),('admin',59,15,'admin/help/help','admin/help/help','help','a:0:{}','system',-1,0,0,0,0,3,0,1,15,59,0,0,0,0,0,0,0),('admin',60,15,'admin/help/node','admin/help/node','node','a:0:{}','system',-1,0,0,0,0,3,0,1,15,60,0,0,0,0,0,0,0),('admin',61,15,'admin/help/role_delegation','admin/help/role_delegation','role_delegation','a:0:{}','system',-1,0,0,0,0,3,0,1,15,61,0,0,0,0,0,0,0),('admin',62,15,'admin/help/system','admin/help/system','system','a:0:{}','system',-1,0,0,0,0,3,0,1,15,62,0,0,0,0,0,0,0),('admin',63,15,'admin/help/user','admin/help/user','user','a:0:{}','system',-1,0,0,0,0,3,0,1,15,63,0,0,0,0,0,0,0),('admin',64,15,'admin/help/webform','admin/help/webform','webform','a:0:{}','system',-1,0,0,0,0,3,0,1,15,64,0,0,0,0,0,0,0),('admin',65,36,'admin/settings/filters/%','admin/settings/filters/%','','a:0:{}','system',-1,0,0,0,0,4,0,1,18,36,65,0,0,0,0,0,0),('admin',66,27,'admin/settings/clean-urls/check','admin/settings/clean-urls/check','Clean URL check','a:0:{}','system',-1,0,0,0,0,4,0,1,18,27,66,0,0,0,0,0,0),('admin',67,23,'admin/settings/actions/configure','admin/settings/actions/configure','Configure an advanced action','a:0:{}','system',-1,0,0,0,0,4,0,1,18,23,67,0,0,0,0,0,0),('admin',68,26,'admin/build/block/configure','admin/build/block/configure','Configure block','a:0:{}','system',-1,0,0,0,0,4,0,1,17,26,68,0,0,0,0,0,0),('admin',69,30,'admin/settings/date-time/lookup','admin/settings/date-time/lookup','Date and time lookup','a:0:{}','system',-1,0,0,0,0,4,0,1,18,30,69,0,0,0,0,0,0),('admin',70,26,'admin/build/block/delete','admin/build/block/delete','Delete block','a:0:{}','system',-1,0,0,0,0,4,0,1,17,26,70,0,0,0,0,0,0),('admin',71,36,'admin/settings/filters/delete','admin/settings/filters/delete','Delete input format','a:0:{}','system',-1,0,0,0,0,4,0,1,18,36,71,0,0,0,0,0,0),('admin',72,22,'admin/user/rules/delete','admin/user/rules/delete','Delete rule','a:0:{}','system',-1,0,0,0,0,4,0,1,20,22,72,0,0,0,0,0,0),('admin',73,43,'admin/user/roles/edit','admin/user/roles/edit','Edit role','a:0:{}','system',-1,0,0,0,0,4,0,1,20,43,73,0,0,0,0,0,0),('admin',74,22,'admin/user/rules/edit','admin/user/rules/edit','Edit rule','a:0:{}','system',-1,0,0,0,0,4,0,1,20,22,74,0,0,0,0,0,0),('admin',75,46,'admin/reports/status/php','admin/reports/status/php','PHP','a:0:{}','system',-1,0,0,0,0,4,0,1,16,46,75,0,0,0,0,0,0),('admin',76,41,'admin/content/node-settings/rebuild','admin/content/node-settings/rebuild','Rebuild permissions','a:0:{}','system',-1,0,0,0,0,4,0,1,12,41,76,0,0,0,0,0,0),('admin',77,23,'admin/settings/actions/orphan','admin/settings/actions/orphan','Remove orphans','a:0:{}','system',-1,0,0,0,0,4,0,1,18,23,77,0,0,0,0,0,0),('admin',78,46,'admin/reports/status/run-cron','admin/reports/status/run-cron','Run cron','a:1:{s:5:\"alter\";b:1;}','system',-1,0,0,0,0,4,0,1,16,46,78,0,0,0,0,0,0),('admin',79,46,'admin/reports/status/sql','admin/reports/status/sql','SQL','a:0:{}','system',-1,0,0,0,0,4,0,1,16,46,79,0,0,0,0,0,0),('admin',80,12,'admin/content/node-type/webform','admin/content/node-type/webform','Webform','a:0:{}','system',-1,0,0,0,0,3,0,1,12,80,0,0,0,0,0,0,0),('navigation',81,0,'node/%/submission/%','node/%/submission/%','Webform submission','a:0:{}','system',-1,0,0,0,0,1,0,81,0,0,0,0,0,0,0,0,0),('navigation',82,0,'webform/ajax/options/%','webform/ajax/options/%','','a:0:{}','system',-1,0,0,0,0,1,0,82,0,0,0,0,0,0,0,0,0),('admin',83,0,'admin/content/node-type/webform/delete','admin/content/node-type/webform/delete','Delete','a:0:{}','system',-1,0,0,0,0,1,0,83,0,0,0,0,0,0,0,0,0),('admin',84,23,'admin/settings/actions/delete/%','admin/settings/actions/delete/%','Delete action','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:17:\"Delete an action.\";}}','system',-1,0,0,0,0,4,0,1,18,23,84,0,0,0,0,0,0),('admin',85,26,'admin/build/block/list/js','admin/build/block/list/js','JavaScript List Form','a:0:{}','system',-1,0,0,0,0,4,0,1,17,26,85,0,0,0,0,0,0),('admin',86,38,'admin/build/modules/list/confirm','admin/build/modules/list/confirm','List','a:0:{}','system',-1,0,0,0,0,4,0,1,17,38,86,0,0,0,0,0,0),('navigation',87,0,'user/reset/%/%/%','user/reset/%/%/%','Reset password','a:0:{}','system',-1,0,0,0,0,1,0,87,0,0,0,0,0,0,0,0,0),('admin',88,38,'admin/build/modules/uninstall/confirm','admin/build/modules/uninstall/confirm','Uninstall','a:0:{}','system',-1,0,0,0,0,4,0,1,17,38,88,0,0,0,0,0,0),('navigation',89,0,'node/%/webform-results/analysis/%','node/%/webform-results/analysis/%','Analysis','a:0:{}','system',-1,0,0,0,0,1,0,89,0,0,0,0,0,0,0,0,0),('navigation',90,0,'node/%/revisions/%/delete','node/%/revisions/%/delete','Delete earlier revision','a:0:{}','system',-1,0,0,0,0,1,0,90,0,0,0,0,0,0,0,0,0),('navigation',91,0,'node/%/revisions/%/revert','node/%/revisions/%/revert','Revert to earlier revision','a:0:{}','system',-1,0,0,0,0,1,0,91,0,0,0,0,0,0,0,0,0),('navigation',92,0,'node/%/revisions/%/view','node/%/revisions/%/view','Revisions','a:0:{}','system',-1,0,0,0,0,1,0,92,0,0,0,0,0,0,0,0,0),('admin',93,17,'admin/build/menu','admin/build/menu','Menus','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:116:\"Control your site\'s navigation menu, primary links and secondary links. as well as rename and reorganize menu items.\";}}','system',0,0,1,0,0,3,0,1,17,93,0,0,0,0,0,0,0),('admin',94,16,'admin/reports/dblog','admin/reports/dblog','Recent log entries','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:43:\"View events that have recently been logged.\";}}','system',0,0,0,0,-1,3,0,1,16,94,0,0,0,0,0,0,0),('admin',95,16,'admin/reports/access-denied','admin/reports/access-denied','Top \'access denied\' errors','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:35:\"View \'access denied\' errors (403s).\";}}','system',0,0,0,0,0,3,0,1,16,95,0,0,0,0,0,0,0),('admin',96,16,'admin/reports/page-not-found','admin/reports/page-not-found','Top \'page not found\' errors','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:36:\"View \'page not found\' errors (404s).\";}}','system',0,0,0,0,0,3,0,1,16,96,0,0,0,0,0,0,0),('admin',97,18,'admin/settings/vertical-tabs','admin/settings/vertical-tabs','Vertical Tabs','a:0:{}','system',0,0,0,0,0,3,0,1,18,97,0,0,0,0,0,0,0),('admin',98,15,'admin/help/dblog','admin/help/dblog','dblog','a:0:{}','system',-1,0,0,0,0,3,0,1,15,98,0,0,0,0,0,0,0),('admin',99,15,'admin/help/menu','admin/help/menu','menu','a:0:{}','system',-1,0,0,0,0,3,0,1,15,99,0,0,0,0,0,0,0),('admin',100,17,'admin/build/menu-customize/%','admin/build/menu-customize/%','Customize menu','a:0:{}','system',-1,0,0,0,0,3,0,1,17,100,0,0,0,0,0,0,0),('admin',101,37,'admin/settings/logging/dblog','admin/settings/logging/dblog','Database logging','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:169:\"Settings for logging to the Drupal database logs. This is the most common method for small to medium sites on shared hosting. The logs are viewable from the admin pages.\";}}','system',0,0,0,0,0,4,0,1,18,37,101,0,0,0,0,0,0),('admin',102,16,'admin/reports/event/%','admin/reports/event/%','Details','a:0:{}','system',-1,0,0,0,0,3,0,1,16,102,0,0,0,0,0,0,0),('admin',103,0,'admin/build/menu-customize/%/delete','admin/build/menu-customize/%/delete','Delete menu','a:0:{}','system',-1,0,0,0,0,1,0,103,0,0,0,0,0,0,0,0,0),('admin',104,93,'admin/build/menu/item/%/delete','admin/build/menu/item/%/delete','Delete menu item','a:0:{}','system',-1,0,0,0,0,4,0,1,17,93,104,0,0,0,0,0,0),('admin',105,93,'admin/build/menu/item/%/edit','admin/build/menu/item/%/edit','Edit menu item','a:0:{}','system',-1,0,0,0,0,4,0,1,17,93,105,0,0,0,0,0,0),('admin',106,93,'admin/build/menu/item/%/reset','admin/build/menu/item/%/reset','Reset menu item','a:0:{}','system',-1,0,0,0,0,4,0,1,17,93,106,0,0,0,0,0,0),('admin',107,93,'admin/build/menu-customize/navigation','admin/build/menu-customize/%','Navigation','a:0:{}','menu',0,0,0,0,0,4,0,1,17,93,107,0,0,0,0,0,0),('admin',108,93,'admin/build/menu-customize/primary-links','admin/build/menu-customize/%','Primary links','a:0:{}','menu',0,0,0,0,0,4,0,1,17,93,108,0,0,0,0,0,0),('admin',109,93,'admin/build/menu-customize/secondary-links','admin/build/menu-customize/%','Secondary links','a:0:{}','menu',0,0,0,0,0,4,0,1,17,93,109,0,0,0,0,0,0),('devel',110,0,'admin/reports/status/run-cron','admin/reports/status/run-cron','Run cron','a:0:{}','devel',0,0,0,0,0,1,0,110,0,0,0,0,0,0,0,0,0),('devel',111,0,'admin/settings/devel','admin/settings','Devel settings','a:0:{}','devel',0,0,0,0,0,1,0,111,0,0,0,0,0,0,0,0,0),('primary-links',112,0,'blog','blog','Blog','a:0:{}','system',0,0,0,0,0,1,0,112,0,0,0,0,0,0,0,0,0),('primary-links',113,0,'events','events','Events','a:0:{}','system',0,0,0,0,0,1,0,113,0,0,0,0,0,0,0,0,0),('navigation',114,0,'content/js_add_more','content/js_add_more','','a:0:{}','system',-1,0,0,0,0,1,0,114,0,0,0,0,0,0,0,0,0),('admin',115,1,'admin/advanced_help','admin/advanced_help','Advanced help','a:0:{}','system',0,0,0,0,9,2,0,1,115,0,0,0,0,0,0,0,0),('navigation',116,0,'nodequeue/autocomplete','nodequeue/autocomplete','Autocomplete','a:0:{}','system',-1,0,0,0,0,1,0,116,0,0,0,0,0,0,0,0,0),('navigation',117,0,'taxonomy/autocomplete','taxonomy/autocomplete','Autocomplete taxonomy','a:0:{}','system',-1,0,0,0,0,1,0,117,0,0,0,0,0,0,0,0,0),('devel',118,0,'devel/queries','devel/queries','Database queries','a:0:{}','system',0,0,1,0,0,1,0,118,0,0,0,0,0,0,0,0,0),('navigation',119,0,'comment/delete','comment/delete','Delete comment','a:0:{}','system',-1,0,0,0,0,1,0,119,0,0,0,0,0,0,0,0,0),('devel',120,0,'devel/source','devel/source','Display the PHP code of any file in your Drupal installation','a:0:{}','system',-1,0,0,0,0,1,0,120,0,0,0,0,0,0,0,0,0),('navigation',121,0,'comment/edit','comment/edit','Edit comment','a:0:{}','system',-1,0,0,0,0,1,0,121,0,0,0,0,0,0,0,0,0),('navigation',122,0,'filefield/progress','filefield/progress','','a:0:{}','system',-1,0,0,0,0,1,0,122,0,0,0,0,0,0,0,0,0),('devel',123,0,'devel/php','devel/php','Execute PHP Code','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:21:\"Execute some PHP code\";}}','system',0,0,0,0,0,1,0,123,0,0,0,0,0,0,0,0,0),('devel',124,0,'devel/reference','devel/reference','Function reference','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:73:\"View a list of currently defined user functions with documentation links.\";}}','system',0,0,0,0,0,1,0,124,0,0,0,0,0,0,0,0,0),('devel',125,0,'devel/elements','devel/elements','Hook_elements()','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:51:\"View the active form/render elements for this site.\";}}','system',0,0,0,0,0,1,0,125,0,0,0,0,0,0,0,0,0),('devel',126,0,'devel/phpinfo','devel/phpinfo','PHPinfo()','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:36:\"View your server\'s PHP configuration\";}}','system',0,0,0,0,0,1,0,126,0,0,0,0,0,0,0,0,0),('devel',127,0,'devel/reinstall','devel/reinstall','Reinstall modules','a:2:{s:10:\"attributes\";a:1:{s:5:\"title\";s:64:\"Run hook_uninstall() and then hook_install() for a given module.\";}s:5:\"alter\";b:1;}','system',0,0,0,0,0,1,0,127,0,0,0,0,0,0,0,0,0),('devel',128,0,'devel/session','devel/session','Session viewer','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:31:\"List the contents of $_SESSION.\";}}','system',0,0,0,0,0,1,0,128,0,0,0,0,0,0,0,0,0),('devel',129,0,'devel/switch','devel/switch','Switch user','a:0:{}','system',-1,0,0,0,0,1,0,129,0,0,0,0,0,0,0,0,0),('navigation',130,0,'wysiwyg/%','wysiwyg/%','','a:0:{}','system',-1,0,0,0,0,1,0,130,0,0,0,0,0,0,0,0,0),('navigation',131,0,'user/timezone','user/timezone','User timezone','a:0:{}','system',-1,0,0,0,0,1,0,131,0,0,0,0,0,0,0,0,0),('devel',132,0,'devel/variable','devel/variable','Variable editor','a:2:{s:10:\"attributes\";a:1:{s:5:\"title\";s:31:\"Edit and delete site variables.\";}s:5:\"alter\";b:1;}','system',0,0,0,0,0,1,0,132,0,0,0,0,0,0,0,0,0),('navigation',133,0,'views/ajax','views/ajax','Views','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:31:\"Ajax callback for view loading.\";}}','system',-1,0,0,0,0,1,0,133,0,0,0,0,0,0,0,0,0),('primary-links',134,112,'blog/rss.xml','blog/rss.xml','','a:0:{}','system',-1,0,0,0,0,2,0,112,134,0,0,0,0,0,0,0,0),('primary-links',135,112,'blog/archive','blog/archive','','a:0:{}','system',-1,0,0,0,0,2,0,112,135,0,0,0,0,0,0,0,0),('primary-links',136,113,'events/rss.xml','events/rss.xml','','a:0:{}','system',-1,0,0,0,0,2,0,113,136,0,0,0,0,0,0,0,0),('primary-links',137,113,'events/archive','events/archive','','a:0:{}','system',-1,0,0,0,0,2,0,113,137,0,0,0,0,0,0,0,0),('navigation',138,0,'search/advanced_help/%','search/advanced_help/%','','a:0:{}','system',0,0,0,0,0,1,0,138,0,0,0,0,0,0,0,0,0),('navigation',139,0,'help/%/%','help/%/%','','a:0:{}','system',-1,0,0,0,0,1,0,139,0,0,0,0,0,0,0,0,0),('navigation',140,0,'ctools/autocomplete/node','ctools/autocomplete/node','','a:0:{}','system',-1,0,0,0,0,1,0,140,0,0,0,0,0,0,0,0,0),('navigation',141,0,'js/path_redirect/autocomplete_404','js/path_redirect/autocomplete_404','','a:0:{}','system',-1,0,0,0,0,1,0,141,0,0,0,0,0,0,0,0,0),('admin',142,16,'admin/reports/updates','admin/reports/updates','Available updates','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:82:\"Get a status report about available updates for your installed modules and themes.\";}}','system',0,0,0,0,10,3,0,1,16,142,0,0,0,0,0,0,0),('navigation',143,13,'node/add/blog','node/add/blog','Blog post','a:0:{}','system',0,0,0,0,0,2,0,13,143,0,0,0,0,0,0,0,0),('admin',144,12,'admin/content/comment','admin/content/comment','Comments','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:61:\"List and edit site comments and the comment moderation queue.\";}}','system',0,0,0,0,0,3,0,1,12,144,0,0,0,0,0,0,0),('admin',145,18,'admin/settings/devel','admin/settings/devel','Devel settings','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:164:\"Helper functions, pages, and blocks to assist Drupal developers. The devel blocks can be managed via the <a href=\"/admin/build/block\">block administration</a> page.\";}}','system',0,0,0,0,0,3,0,1,18,145,0,0,0,0,0,0,0),('devel',146,0,'devel/cache/clear','devel/cache/clear','Empty cache','a:2:{s:10:\"attributes\";a:1:{s:5:\"title\";s:100:\"Clear the CSS cache and all database cache tables which store page, node, theme and variable caches.\";}s:5:\"alter\";b:1;}','system',0,0,0,0,0,1,0,146,0,0,0,0,0,0,0,0,0),('devel',147,118,'devel/queries/empty','devel/queries/empty','Empty database queries','a:0:{}','system',0,0,0,0,0,2,0,118,147,0,0,0,0,0,0,0,0),('navigation',148,13,'node/add/event','node/add/event','Event','a:0:{}','system',0,0,0,0,0,2,0,13,148,0,0,0,0,0,0,0,0),('admin',149,17,'admin/build/features','admin/build/features','Features','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:16:\"Manage features.\";}}','system',0,0,0,0,0,3,0,1,17,149,0,0,0,0,0,0,0),('admin',150,12,'admin/content/nodequeue','admin/content/nodequeue','Nodequeue','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:38:\"Create and maintain simple nodequeues.\";}}','system',0,0,0,0,0,3,0,1,12,150,0,0,0,0,0,0,0),('navigation',151,13,'node/add/page','node/add/page','Page','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:258:\"A <em>page</em> is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";}}','system',0,0,0,0,0,2,0,13,151,0,0,0,0,0,0,0,0),('admin',152,17,'admin/build/pages','admin/build/pages','Pages','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:84:\"Add, edit and remove overridden system pages and user defined pages from the system.\";}}','system',0,0,0,0,0,3,0,1,17,152,0,0,0,0,0,0,0),('devel',153,0,'devel/menu/reset','devel/menu/reset','Rebuild menus','a:2:{s:10:\"attributes\";a:1:{s:5:\"title\";s:113:\"Rebuild menu based on hook_menu() and revert any custom changes. All menu items return to their default settings.\";}s:5:\"alter\";b:1;}','system',0,0,0,0,0,1,0,153,0,0,0,0,0,0,0,0,0),('navigation',154,0,'comment/reply/%','comment/reply/%','Reply to comment','a:0:{}','system',-1,0,0,0,0,1,0,154,0,0,0,0,0,0,0,0,0),('navigation',155,0,'advanced_help/search/%','advanced_help/search/%','Search help','a:0:{}','system',0,0,0,0,0,1,0,155,0,0,0,0,0,0,0,0,0),('navigation',156,13,'node/add/slide','node/add/slide','Slide','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:46:\"An image to be used in the homepage slideshow.\";}}','system',0,0,0,0,0,2,0,13,156,0,0,0,0,0,0,0,0),('admin',157,18,'admin/settings/strongarm','admin/settings/strongarm','Strongarm','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:59:\"Manage Drupal variable settings that have been strongarmed.\";}}','system',0,0,0,0,0,3,0,1,18,157,0,0,0,0,0,0,0),('admin',158,12,'admin/content/taxonomy','admin/content/taxonomy','Taxonomy','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:67:\"Manage tagging, categorization, and classification of your content.\";}}','system',0,0,0,0,0,3,0,1,12,158,0,0,0,0,0,0,0),('navigation',159,0,'taxonomy/term/%','taxonomy/term/%','Taxonomy term','a:0:{}','system',-1,0,0,0,0,1,0,159,0,0,0,0,0,0,0,0,0),('devel',160,0,'devel/theme/registry','devel/theme/registry','Theme registry','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:63:\"View a list of available theme functions across the whole site.\";}}','system',0,0,0,0,0,1,0,160,0,0,0,0,0,0,0,0,0),('admin',161,17,'admin/build/path','admin/build/path','URL aliases','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:46:\"Change your site\'s URL paths by aliasing them.\";}}','system',0,0,0,0,0,3,0,1,17,161,0,0,0,0,0,0,0),('admin',162,17,'admin/build/path-redirect','admin/build/path-redirect','URL redirects','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:39:\"Redirect users from one URL to another.\";}}','system',0,0,0,0,0,3,0,1,17,162,0,0,0,0,0,0,0),('admin',163,18,'admin/settings/wysiwyg','admin/settings/wysiwyg','Wysiwyg','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:30:\"Configure client-side editors.\";}}','system',0,0,0,0,0,3,0,1,18,163,0,0,0,0,0,0,0),('admin',164,15,'admin/help/calendar','admin/help/calendar','calendar','a:0:{}','system',-1,0,0,0,0,3,0,1,15,164,0,0,0,0,0,0,0),('admin',165,15,'admin/help/comment','admin/help/comment','comment','a:0:{}','system',-1,0,0,0,0,3,0,1,15,165,0,0,0,0,0,0,0),('admin',166,15,'admin/help/content','admin/help/content','content','a:0:{}','system',-1,0,0,0,0,3,0,1,15,166,0,0,0,0,0,0,0),('admin',167,15,'admin/help/context','admin/help/context','context','a:0:{}','system',-1,0,0,0,0,3,0,1,15,167,0,0,0,0,0,0,0),('admin',168,15,'admin/help/date','admin/help/date','date','a:0:{}','system',-1,0,0,0,0,3,0,1,15,168,0,0,0,0,0,0,0),('admin',169,15,'admin/help/devel','admin/help/devel','devel','a:0:{}','system',-1,0,0,0,0,3,0,1,15,169,0,0,0,0,0,0,0),('admin',170,15,'admin/help/features','admin/help/features','features','a:0:{}','system',-1,0,0,0,0,3,0,1,15,170,0,0,0,0,0,0,0),('admin',171,15,'admin/help/image_resize_filter','admin/help/image_resize_filter','image_resize_filter','a:0:{}','system',-1,0,0,0,0,3,0,1,15,171,0,0,0,0,0,0,0),('admin',172,15,'admin/help/path','admin/help/path','path','a:0:{}','system',-1,0,0,0,0,3,0,1,15,172,0,0,0,0,0,0,0),('admin',173,15,'admin/help/path_redirect','admin/help/path_redirect','path_redirect','a:0:{}','system',-1,0,0,0,0,3,0,1,15,173,0,0,0,0,0,0,0),('admin',174,15,'admin/help/pathauto','admin/help/pathauto','pathauto','a:0:{}','system',-1,0,0,0,0,3,0,1,15,174,0,0,0,0,0,0,0),('admin',175,15,'admin/help/strongarm','admin/help/strongarm','strongarm','a:0:{}','system',-1,0,0,0,0,3,0,1,15,175,0,0,0,0,0,0,0),('admin',176,15,'admin/help/taxonomy','admin/help/taxonomy','taxonomy','a:0:{}','system',-1,0,0,0,0,3,0,1,15,176,0,0,0,0,0,0,0),('admin',177,15,'admin/help/token','admin/help/token','token','a:0:{}','system',-1,0,0,0,0,3,0,1,15,177,0,0,0,0,0,0,0),('admin',178,15,'admin/help/update','admin/help/update','update','a:0:{}','system',-1,0,0,0,0,3,0,1,15,178,0,0,0,0,0,0,0),('admin',179,15,'admin/help/wysiwyg','admin/help/wysiwyg','wysiwyg','a:0:{}','system',-1,0,0,0,0,3,0,1,15,179,0,0,0,0,0,0,0),('admin',180,12,'admin/content/node2','admin/content/node2','','a:0:{}','system',-1,0,0,0,0,3,0,1,12,180,0,0,0,0,0,0,0),('admin',181,149,'admin/build/features/%','admin/build/features/%','','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:32:\"Display components of a feature.\";}}','system',-1,0,0,0,0,4,0,1,17,149,181,0,0,0,0,0,0),('navigation',182,0,'ctools/context/ajax/add','ctools/context/ajax/add','','a:0:{}','system',-1,0,0,0,0,1,0,182,0,0,0,0,0,0,0,0,0),('navigation',183,0,'ctools/context/ajax/delete','ctools/context/ajax/delete','','a:0:{}','system',-1,0,0,0,0,1,0,183,0,0,0,0,0,0,0,0,0),('navigation',184,0,'ctools/context/ajax/configure','ctools/context/ajax/configure','','a:0:{}','system',-1,0,0,0,0,1,0,184,0,0,0,0,0,0,0,0,0),('admin',185,12,'admin/content/node-type/blog','admin/content/node-type/blog','Blog post','a:0:{}','system',-1,0,0,0,0,3,0,1,12,185,0,0,0,0,0,0,0),('admin',186,149,'admin/build/features/cleanup','admin/build/features/cleanup','Cleanup','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:53:\"Detect and disable any orphaned feature dependencies.\";}}','system',-1,0,0,0,1,4,0,1,17,149,186,0,0,0,0,0,0),('admin',187,161,'admin/build/path/delete','admin/build/path/delete','Delete alias','a:0:{}','system',-1,0,0,0,0,4,0,1,17,161,187,0,0,0,0,0,0),('admin',188,152,'admin/build/pages/argument','admin/build/pages/argument','','a:0:{}','system',-1,0,0,0,0,4,0,1,17,152,188,0,0,0,0,0,0),('admin',189,161,'admin/build/path/edit','admin/build/path/edit','Edit alias','a:0:{}','system',-1,0,0,0,0,4,0,1,17,161,189,0,0,0,0,0,0),('admin',190,12,'admin/content/node-type/event','admin/content/node-type/event','Event','a:0:{}','system',-1,0,0,0,0,3,0,1,12,190,0,0,0,0,0,0,0),('admin',191,158,'admin/content/taxonomy/%','admin/content/taxonomy/%','List terms','a:0:{}','system',-1,0,0,0,0,4,0,1,12,158,191,0,0,0,0,0,0),('admin',192,12,'admin/content/node-type/page','admin/content/node-type/page','Page','a:0:{}','system',-1,0,0,0,0,3,0,1,12,192,0,0,0,0,0,0,0),('admin',193,12,'admin/content/node-type/slide','admin/content/node-type/slide','Slide','a:0:{}','system',-1,0,0,0,0,3,0,1,12,193,0,0,0,0,0,0,0),('devel',194,132,'devel/variable/edit/%','devel/variable/edit/%','Variable editor','a:0:{}','system',-1,0,0,0,0,2,0,132,194,0,0,0,0,0,0,0,0),('admin',195,150,'admin/content/nodequeue/%','admin/content/nodequeue/%','','a:0:{}','system',-1,0,0,0,0,4,0,1,12,150,195,0,0,0,0,0,0),('admin',196,142,'admin/reports/updates/check','admin/reports/updates/check','Manual update check','a:0:{}','system',-1,0,0,0,0,4,0,1,16,142,196,0,0,0,0,0,0),('navigation',197,0,'ctools/context/ajax/access/add','ctools/context/ajax/access/add','','a:0:{}','system',-1,0,0,0,0,1,0,197,0,0,0,0,0,0,0,0,0),('navigation',198,0,'ctools/context/ajax/access/delete','ctools/context/ajax/access/delete','','a:0:{}','system',-1,0,0,0,0,1,0,198,0,0,0,0,0,0,0,0,0),('navigation',199,0,'ctools/context/ajax/access/configure','ctools/context/ajax/access/configure','','a:0:{}','system',-1,0,0,0,0,1,0,199,0,0,0,0,0,0,0,0,0),('admin',200,30,'admin/settings/date-time/formats/lookup','admin/settings/date-time/formats/lookup','Date and time lookup','a:0:{}','system',-1,0,0,0,0,4,0,1,18,30,200,0,0,0,0,0,0),('admin',201,0,'admin/content/node-type/blog/delete','admin/content/node-type/blog/delete','Delete','a:0:{}','system',-1,0,0,0,0,1,0,201,0,0,0,0,0,0,0,0,0),('navigation',202,0,'filefield/ahah/%/%/%','filefield/ahah/%/%/%','','a:0:{}','system',-1,0,0,0,0,1,0,202,0,0,0,0,0,0,0,0,0),('admin',203,0,'admin/content/node-type/event/delete','admin/content/node-type/event/delete','Delete','a:0:{}','system',-1,0,0,0,0,1,0,203,0,0,0,0,0,0,0,0,0),('admin',204,0,'admin/content/node-type/page/delete','admin/content/node-type/page/delete','Delete','a:0:{}','system',-1,0,0,0,0,1,0,204,0,0,0,0,0,0,0,0,0),('admin',205,0,'admin/content/node-type/slide/delete','admin/content/node-type/slide/delete','Delete','a:0:{}','system',-1,0,0,0,0,1,0,205,0,0,0,0,0,0,0,0,0),('admin',206,0,'admin/content/nodequeue/%/delete','admin/content/nodequeue/%/delete','Delete','a:0:{}','system',-1,0,0,0,5,1,0,206,0,0,0,0,0,0,0,0,0),('admin',207,30,'admin/settings/date-time/delete/%','admin/settings/date-time/delete/%','Delete date format type','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:52:\"Allow users to delete a configured date format type.\";}}','system',-1,0,0,0,0,4,0,1,18,30,207,0,0,0,0,0,0),('admin',208,162,'admin/build/path-redirect/delete/%','admin/build/path-redirect/delete/%','Delete redirect','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:32:\"Delete an existing URL redirect.\";}}','system',-1,0,0,0,0,4,0,1,17,162,208,0,0,0,0,0,0),('admin',209,152,'admin/build/pages/edit/%','admin/build/pages/edit/%','Edit','a:0:{}','system',-1,0,0,0,0,4,0,1,17,152,209,0,0,0,0,0,0),('admin',210,1,'admin/views/ajax/autocomplete/user','admin/views/ajax/autocomplete/user','','a:0:{}','system',-1,0,0,0,0,2,0,1,210,0,0,0,0,0,0,0,0),('admin',211,162,'admin/build/path-redirect/edit/%','admin/build/path-redirect/edit/%','Edit redirect','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:30:\"Edit an existing URL redirect.\";}}','system',-1,0,0,0,0,4,0,1,17,162,211,0,0,0,0,0,0),('admin',212,158,'admin/content/taxonomy/edit/term','admin/content/taxonomy/edit/term','Edit term','a:0:{}','system',-1,0,0,0,0,4,0,1,12,158,212,0,0,0,0,0,0),('admin',213,149,'admin/build/features/export/populate','admin/build/features/export/populate','Populate feature','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:61:\"AHAH callback to populate a feature from selected components.\";}}','system',-1,0,0,0,0,4,0,1,17,149,213,0,0,0,0,0,0),('admin',214,0,'admin/build/features/%/status','admin/build/features/%/status','Status','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:28:\"Javascript status call back.\";}}','system',-1,0,0,0,0,1,0,214,0,0,0,0,0,0,0,0,0),('admin',215,30,'admin/settings/date-time/formats/delete/%','admin/settings/date-time/formats/delete/%','Delete date format','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:47:\"Allow users to delete a configured date format.\";}}','system',-1,0,0,0,0,4,0,1,18,30,215,0,0,0,0,0,0),('admin',216,152,'admin/build/pages/%/operation/%','admin/build/pages/%/operation/%','','a:0:{}','system',-1,0,0,0,0,4,0,1,17,152,216,0,0,0,0,0,0),('admin',217,152,'admin/build/pages/%/enable/%','admin/build/pages/%/enable/%','','a:0:{}','system',-1,0,0,0,0,4,0,1,17,152,217,0,0,0,0,0,0),('admin',218,152,'admin/build/pages/%/disable/%','admin/build/pages/%/disable/%','','a:0:{}','system',-1,0,0,0,0,4,0,1,17,152,218,0,0,0,0,0,0),('admin',219,0,'admin/content/nodequeue/%/clear/%','admin/content/nodequeue/%/clear/%','Clear','a:0:{}','system',-1,0,0,0,0,1,0,219,0,0,0,0,0,0,0,0,0),('admin',220,158,'admin/content/taxonomy/edit/vocabulary/%','admin/content/taxonomy/edit/vocabulary/%','Edit vocabulary','a:0:{}','system',-1,0,0,0,0,4,0,1,12,158,220,0,0,0,0,0,0),('admin',221,0,'admin/content/nodequeue/%/add/%/%','admin/content/nodequeue/%/add/%/%','','a:0:{}','system',-1,0,0,0,0,1,0,221,0,0,0,0,0,0,0,0,0),('admin',222,0,'admin/content/nodequeue/%/remove-node/%/%','admin/content/nodequeue/%/remove-node/%/%','','a:0:{}','system',-1,0,0,0,0,1,0,222,0,0,0,0,0,0,0,0,0),('primary-links',223,0,'node/1','node/%','Home','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:7:\"Welcome\";}}','menu',0,0,0,0,-42,1,0,223,0,0,0,0,0,0,0,0,0),('primary-links',224,0,'node/2','node/%','About','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:18:\"About OpenSourcery\";}}','menu',0,0,0,0,0,1,0,224,0,0,0,0,0,0,0,0,0),('secondary-links',225,0,'node/3','node/%','Contact','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:10:\"Contact Us\";}}','menu',0,0,0,0,0,1,0,225,0,0,0,0,0,0,0,0,0),('admin',226,0,'admin/content/node-type/blog/fields/field_blog_images/remove','admin/content/node-type/blog/fields/field_blog_images/remove','Remove field','a:0:{}','system',-1,0,0,0,0,1,0,226,0,0,0,0,0,0,0,0,0),('admin',227,0,'admin/content/node-type/event/fields/field_event_date/remove','admin/content/node-type/event/fields/field_event_date/remove','Remove field','a:0:{}','system',-1,0,0,0,0,1,0,227,0,0,0,0,0,0,0,0,0),('admin',228,0,'admin/content/node-type/event/fields/field_event_image/remove','admin/content/node-type/event/fields/field_event_image/remove','Remove field','a:0:{}','system',-1,0,0,0,0,1,0,228,0,0,0,0,0,0,0,0,0),('admin',229,0,'admin/content/node-type/slide/fields/field_slide_image/remove','admin/content/node-type/slide/fields/field_slide_image/remove','Remove field','a:0:{}','system',-1,0,0,0,0,1,0,229,0,0,0,0,0,0,0,0,0),('admin',230,0,'admin/content/node-type/slide/fields/field_slide_link/remove','admin/content/node-type/slide/fields/field_slide_link/remove','Remove field','a:0:{}','system',-1,0,0,0,0,1,0,230,0,0,0,0,0,0,0,0,0),('admin_menu',231,0,'<front>','','<img class=\"admin-menu-icon\" src=\"/misc/favicon.ico\" width=\"16\" height=\"16\" alt=\"Home\" />','a:3:{s:11:\"extra class\";s:15:\"admin-menu-icon\";s:4:\"html\";b:1;s:5:\"alter\";b:1;}','admin_menu',0,1,1,0,-100,1,0,231,0,0,0,0,0,0,0,0,0),('admin_menu',232,0,'logout','logout','Log out @username','a:3:{s:11:\"extra class\";s:35:\"admin-menu-action admin-menu-logout\";s:1:\"t\";a:0:{}s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,-100,1,0,232,0,0,0,0,0,0,0,0,0),('admin_menu',233,0,'user','user','icon_users','a:3:{s:11:\"extra class\";s:50:\"admin-menu-action admin-menu-icon admin-menu-users\";s:4:\"html\";b:1;s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-90,1,0,233,0,0,0,0,0,0,0,0,0),('admin_menu',234,0,'admin/advanced_help','admin/advanced_help','Advanced help','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,9,1,0,234,0,0,0,0,0,0,0,0,0),('admin_menu',235,0,'admin/content','admin/content','Content management','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,-10,1,0,235,0,0,0,0,0,0,0,0,0),('admin_menu',236,0,'admin/help','admin/help','Help','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,9,1,0,236,0,0,0,0,0,0,0,0,0),('admin_menu',237,0,'admin/reports','admin/reports','Reports','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,5,1,0,237,0,0,0,0,0,0,0,0,0),('admin_menu',238,0,'admin/build','admin/build','Site building','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,-10,1,0,238,0,0,0,0,0,0,0,0,0),('admin_menu',239,0,'admin/settings','admin/settings','Site configuration','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,-5,1,0,239,0,0,0,0,0,0,0,0,0),('admin_menu',240,0,'admin/user','admin/user','User management','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,1,0,240,0,0,0,0,0,0,0,0,0),('admin_menu',241,240,'admin/user/rules','admin/user/rules','Access rules','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,240,241,0,0,0,0,0,0,0,0),('admin_menu',242,239,'admin/settings/actions','admin/settings/actions','Actions','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,239,242,0,0,0,0,0,0,0,0),('admin_menu',243,239,'admin/settings/admin_menu','admin/settings/admin_menu','Administration menu','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,243,0,0,0,0,0,0,0,0),('admin_menu',244,239,'admin/settings/admin','admin/settings/admin','Administration tools','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,239,244,0,0,0,0,0,0,0,0),('admin_menu',245,237,'admin/reports/updates','admin/reports/updates','Available updates','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,10,2,0,237,245,0,0,0,0,0,0,0,0),('admin_menu',246,238,'admin/build/block','admin/build/block','Blocks','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,246,0,0,0,0,0,0,0,0),('admin_menu',247,239,'admin/settings/clean-urls','admin/settings/clean-urls','Clean URLs','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,247,0,0,0,0,0,0,0,0),('admin_menu',248,235,'admin/content/comment','admin/content/comment','Comments','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,235,248,0,0,0,0,0,0,0,0),('admin_menu',249,235,'admin/content/node','admin/content/node','Content','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,235,249,0,0,0,0,0,0,0,0),('admin_menu',250,235,'admin/content/types','admin/content/types','Content types','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,235,250,0,0,0,0,0,0,0,0),('admin_menu',251,239,'admin/settings/date-time','admin/settings/date-time','Date and time','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,239,251,0,0,0,0,0,0,0,0),('admin_menu',252,239,'admin/settings/devel','admin/settings/devel','Devel settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,252,0,0,0,0,0,0,0,0),('admin_menu',253,239,'admin/settings/error-reporting','admin/settings/error-reporting','Error reporting','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,253,0,0,0,0,0,0,0,0),('admin_menu',254,238,'admin/build/features','admin/build/features','Features','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,254,0,0,0,0,0,0,0,0),('admin_menu',255,239,'admin/settings/file-system','admin/settings/file-system','File system','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,255,0,0,0,0,0,0,0,0),('admin_menu',256,239,'admin/settings/image-toolkit','admin/settings/image-toolkit','Image toolkit','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,256,0,0,0,0,0,0,0,0),('admin_menu',257,239,'admin/settings/filters','admin/settings/filters','Input formats','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,239,257,0,0,0,0,0,0,0,0),('admin_menu',258,239,'admin/settings/logging','admin/settings/logging','Logging and alerts','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,239,258,0,0,0,0,0,0,0,0),('admin_menu',259,238,'admin/build/menu','admin/build/menu','Menus','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,259,0,0,0,0,0,0,0,0),('admin_menu',260,238,'admin/build/modules','admin/build/modules','Modules','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,260,0,0,0,0,0,0,0,0),('admin_menu',261,235,'admin/content/nodequeue','admin/content/nodequeue','Nodequeue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,235,261,0,0,0,0,0,0,0,0),('admin_menu',262,238,'admin/build/pages','admin/build/pages','Pages','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,262,0,0,0,0,0,0,0,0),('admin_menu',263,239,'admin/settings/performance','admin/settings/performance','Performance','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,263,0,0,0,0,0,0,0,0),('admin_menu',264,240,'admin/user/permissions','admin/user/permissions','Permissions','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,240,264,0,0,0,0,0,0,0,0),('admin_menu',265,235,'admin/content/node-settings','admin/content/node-settings','Post settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,235,265,0,0,0,0,0,0,0,0),('admin_menu',266,235,'admin/content/rss-publishing','admin/content/rss-publishing','RSS publishing','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,235,266,0,0,0,0,0,0,0,0),('admin_menu',267,237,'admin/reports/dblog','admin/reports/dblog','Recent log entries','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-1,2,0,237,267,0,0,0,0,0,0,0,0),('admin_menu',268,240,'admin/user/roles','admin/user/roles','Roles','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,240,268,0,0,0,0,0,0,0,0),('admin_menu',269,239,'admin/settings/site-information','admin/settings/site-information','Site information','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,269,0,0,0,0,0,0,0,0),('admin_menu',270,239,'admin/settings/site-maintenance','admin/settings/site-maintenance','Site maintenance','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,270,0,0,0,0,0,0,0,0),('admin_menu',271,237,'admin/reports/status','admin/reports/status','Status report','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,10,2,0,237,271,0,0,0,0,0,0,0,0),('admin_menu',272,239,'admin/settings/strongarm','admin/settings/strongarm','Strongarm','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,272,0,0,0,0,0,0,0,0),('admin_menu',273,235,'admin/content/taxonomy','admin/content/taxonomy','Taxonomy','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,235,273,0,0,0,0,0,0,0,0),('admin_menu',274,238,'admin/build/themes','admin/build/themes','Themes','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,274,0,0,0,0,0,0,0,0),('admin_menu',275,237,'admin/reports/access-denied','admin/reports/access-denied','Top \'access denied\' errors','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,237,275,0,0,0,0,0,0,0,0),('admin_menu',276,237,'admin/reports/page-not-found','admin/reports/page-not-found','Top \'page not found\' errors','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,237,276,0,0,0,0,0,0,0,0),('admin_menu',277,238,'admin/build/path','admin/build/path','URL aliases','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,277,0,0,0,0,0,0,0,0),('admin_menu',278,238,'admin/build/path-redirect','admin/build/path-redirect','URL redirects','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,238,278,0,0,0,0,0,0,0,0),('admin_menu',279,240,'admin/user/settings','admin/user/settings','User settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,240,279,0,0,0,0,0,0,0,0),('admin_menu',280,240,'admin/user/user','admin/user/user','Users','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,240,280,0,0,0,0,0,0,0,0),('admin_menu',281,239,'admin/settings/vertical-tabs','admin/settings/vertical-tabs','Vertical Tabs','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,281,0,0,0,0,0,0,0,0),('admin_menu',282,239,'admin/settings/webform','admin/settings/webform','Webform settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,239,282,0,0,0,0,0,0,0,0),('admin_menu',283,235,'admin/content/webform','admin/content/webform','Webforms','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,235,283,0,0,0,0,0,0,0,0),('admin_menu',284,239,'admin/settings/wysiwyg','admin/settings/wysiwyg','Wysiwyg','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,239,284,0,0,0,0,0,0,0,0),('admin_menu',285,277,'admin/build/path/add','admin/build/path/add','Add alias','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,277,285,0,0,0,0,0,0,0),('admin_menu',286,246,'admin/build/block/add','admin/build/block/add','Add block','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,246,286,0,0,0,0,0,0,0),('admin_menu',287,250,'admin/content/types/add','admin/content/types/add','Add content type','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,250,287,0,0,0,0,0,0,0),('admin_menu',288,262,'admin/build/pages/add','admin/build/pages/add','Add custom page','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,262,288,0,0,0,0,0,0,0),('admin_menu',289,257,'admin/settings/filters/add','admin/settings/filters/add','Add input format','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,3,0,239,257,289,0,0,0,0,0,0,0),('admin_menu',290,259,'admin/build/menu/add','admin/build/menu/add','Add menu','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,259,290,0,0,0,0,0,0,0),('admin_menu',291,278,'admin/build/path-redirect/add','admin/build/path-redirect/add','Add redirect','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,278,291,0,0,0,0,0,0,0),('admin_menu',292,241,'admin/user/rules/add','admin/user/rules/add','Add rule','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,240,241,292,0,0,0,0,0,0,0),('admin_menu',293,280,'admin/user/user/create','admin/user/user/create','Add user','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,240,280,293,0,0,0,0,0,0,0),('admin_menu',294,244,'admin/settings/admin/theme','admin/settings/admin/theme','Administration theme','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,10,3,0,239,244,294,0,0,0,0,0,0,0),('admin_menu',295,248,'admin/content/comment/approval','admin/content/comment/approval','Approval queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,248,295,0,0,0,0,0,0,0),('admin_menu',296,277,'admin/build/path/pathauto','admin/build/path/pathauto','Automated alias settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,10,3,0,238,277,296,0,0,0,0,0,0,0),('admin_menu',297,241,'admin/user/rules/check','admin/user/rules/check','Check rules','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,240,241,297,0,0,0,0,0,0,0),('admin_menu',298,274,'admin/build/themes/settings','admin/build/themes/settings','Configure','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,3,0,238,274,298,0,0,0,0,0,0,0),('admin_menu',299,254,'admin/build/features/create','admin/build/features/create','Create feature','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,10,3,0,238,254,299,0,0,0,0,0,0,0),('admin_menu',300,258,'admin/settings/logging/dblog','admin/settings/logging/dblog','Database logging','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,239,258,300,0,0,0,0,0,0,0),('admin_menu',301,251,'admin/settings/date-time/configure','admin/settings/date-time/configure','Date and time','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,239,251,301,0,0,0,0,0,0,0),('admin_menu',302,257,'admin/settings/filters/defaults','admin/settings/filters/defaults','Defaults','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,2,3,0,239,257,302,0,0,0,0,0,0,0),('admin_menu',303,277,'admin/build/path/delete_bulk','admin/build/path/delete_bulk','Delete aliases','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,30,3,0,238,277,303,0,0,0,0,0,0,0),('admin_menu',304,250,'admin/content/types/fields','admin/content/types/fields','Fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,250,304,0,0,0,0,0,0,0),('admin_menu',305,251,'admin/settings/date-time/formats','admin/settings/date-time/formats','Formats','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,1,3,0,239,251,305,0,0,0,0,0,0,0),('admin_menu',306,262,'admin/build/pages/import','admin/build/pages/import','Import page','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,262,306,0,0,0,0,0,0,0),('admin_menu',307,246,'admin/build/block/list','admin/build/block/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,-10,3,0,238,246,307,0,0,0,0,0,0,0),('admin_menu',308,262,'admin/build/pages/list','admin/build/pages/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,238,262,308,0,0,0,0,0,0,0),('admin_menu',309,277,'admin/build/path/list','admin/build/path/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,238,277,309,0,0,0,0,0,0,0),('admin_menu',310,261,'admin/content/nodequeue/list','admin/content/nodequeue/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-1,3,0,235,261,310,0,0,0,0,0,0,0),('admin_menu',311,278,'admin/build/path-redirect/list','admin/build/path-redirect/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,238,278,311,0,0,0,0,0,0,0),('admin_menu',312,249,'admin/content/node/overview','admin/content/node/overview','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,235,249,312,0,0,0,0,0,0,0),('admin_menu',313,273,'admin/content/taxonomy/list','admin/content/taxonomy/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,235,273,313,0,0,0,0,0,0,0),('admin_menu',314,250,'admin/content/types/list','admin/content/types/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,235,250,314,0,0,0,0,0,0,0),('admin_menu',315,245,'admin/reports/updates/list','admin/reports/updates/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,237,245,315,0,0,0,0,0,0,0),('admin_menu',316,241,'admin/user/rules/list','admin/user/rules/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,240,241,316,0,0,0,0,0,0,0),('admin_menu',317,280,'admin/user/user/list','admin/user/user/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,240,280,317,0,0,0,0,0,0,0),('admin_menu',318,260,'admin/build/modules/list','admin/build/modules/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,260,318,0,0,0,0,0,0,0),('admin_menu',319,274,'admin/build/themes/select','admin/build/themes/select','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-1,3,0,238,274,319,0,0,0,0,0,0,0),('admin_menu',320,257,'admin/settings/filters/list','admin/settings/filters/list','List','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,239,257,320,0,0,0,0,0,0,0),('admin_menu',321,259,'admin/build/menu/list','admin/build/menu/list','List menus','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,238,259,321,0,0,0,0,0,0,0),('admin_menu',322,254,'admin/build/features/manage','admin/build/features/manage','Manage','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,254,322,0,0,0,0,0,0,0),('admin_menu',323,242,'admin/settings/actions/manage','admin/settings/actions/manage','Manage actions','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-2,3,0,239,242,323,0,0,0,0,0,0,0),('admin_menu',324,284,'admin/settings/wysiwyg/profile','admin/settings/wysiwyg/profile','Profiles','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,239,284,324,0,0,0,0,0,0,0),('admin_menu',325,248,'admin/content/comment/new','admin/content/comment/new','Published comments','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,3,0,235,248,325,0,0,0,0,0,0,0),('admin_menu',326,244,'admin/settings/admin/rebuild','admin/settings/admin/rebuild','Rebuild','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,10,3,0,239,244,326,0,0,0,0,0,0,0),('admin_menu',327,259,'admin/build/menu/settings','admin/build/menu/settings','Settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,5,3,0,238,259,327,0,0,0,0,0,0,0),('admin_menu',328,257,'admin/settings/filters/settings','admin/settings/filters/settings','Settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,3,3,0,239,257,328,0,0,0,0,0,0,0),('admin_menu',329,261,'admin/content/nodequeue/settings','admin/content/nodequeue/settings','Settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,261,329,0,0,0,0,0,0,0),('admin_menu',330,278,'admin/build/path-redirect/settings','admin/build/path-redirect/settings','Settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,10,3,0,238,278,330,0,0,0,0,0,0,0),('admin_menu',331,244,'admin/settings/admin/settings','admin/settings/admin/settings','Settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,239,244,331,0,0,0,0,0,0,0),('admin_menu',332,245,'admin/reports/updates/settings','admin/reports/updates/settings','Settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,237,245,332,0,0,0,0,0,0,0),('admin_menu',333,260,'admin/build/modules/uninstall','admin/build/modules/uninstall','Uninstall','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,238,260,333,0,0,0,0,0,0,0),('admin_menu',334,261,'admin/content/nodequeue/add/nodequeue','admin/content/nodequeue/add/nodequeue','Add @type','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,261,334,0,0,0,0,0,0,0),('admin_menu',335,305,'admin/settings/date-time/formats/add','admin/settings/date-time/formats/add','Add format','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,3,4,0,239,251,305,335,0,0,0,0,0,0),('admin_menu',336,307,'admin/build/block/list/bluemarine','admin/build/block/list/bluemarine','Bluemarine','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,336,0,0,0,0,0,0),('admin_menu',337,298,'admin/build/themes/settings/bluemarine','admin/build/themes/settings/bluemarine','Bluemarine','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,337,0,0,0,0,0,0),('admin_menu',338,307,'admin/build/block/list/chameleon','admin/build/block/list/chameleon','Chameleon','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,338,0,0,0,0,0,0),('admin_menu',339,298,'admin/build/themes/settings/chameleon','admin/build/themes/settings/chameleon','Chameleon','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,339,0,0,0,0,0,0),('admin_menu',340,305,'admin/settings/date-time/formats/configure','admin/settings/date-time/formats/configure','Configure','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,4,0,239,251,305,340,0,0,0,0,0,0),('admin_menu',341,307,'admin/build/block/list/cube','admin/build/block/list/cube','Cube','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,341,0,0,0,0,0,0),('admin_menu',342,298,'admin/build/themes/settings/cube','admin/build/themes/settings/cube','Cube','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,342,0,0,0,0,0,0),('admin_menu',343,305,'admin/settings/date-time/formats/custom','admin/settings/date-time/formats/custom','Custom formats','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,2,4,0,239,251,305,343,0,0,0,0,0,0),('admin_menu',344,307,'admin/build/block/list/doune','admin/build/block/list/doune','Doune','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,4,0,238,246,307,344,0,0,0,0,0,0),('admin_menu',345,298,'admin/build/themes/settings/doune','admin/build/themes/settings/doune','Doune','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,345,0,0,0,0,0,0),('admin_menu',346,307,'admin/build/block/list/garland','admin/build/block/list/garland','Garland','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,346,0,0,0,0,0,0),('admin_menu',347,298,'admin/build/themes/settings/garland','admin/build/themes/settings/garland','Garland','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,347,0,0,0,0,0,0),('admin_menu',348,298,'admin/build/themes/settings/global','admin/build/themes/settings/global','Global settings','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-1,4,0,238,274,298,348,0,0,0,0,0,0),('admin_menu',349,307,'admin/build/block/list/marvin','admin/build/block/list/marvin','Marvin','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,349,0,0,0,0,0,0),('admin_menu',350,298,'admin/build/themes/settings/marvin','admin/build/themes/settings/marvin','Marvin','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,350,0,0,0,0,0,0),('admin_menu',351,307,'admin/build/block/list/minnelli','admin/build/block/list/minnelli','Minnelli','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,351,0,0,0,0,0,0),('admin_menu',352,298,'admin/build/themes/settings/minnelli','admin/build/themes/settings/minnelli','Minnelli','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,352,0,0,0,0,0,0),('admin_menu',353,307,'admin/build/block/list/pushbutton','admin/build/block/list/pushbutton','Pushbutton','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,353,0,0,0,0,0,0),('admin_menu',354,298,'admin/build/themes/settings/pushbutton','admin/build/themes/settings/pushbutton','Pushbutton','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,354,0,0,0,0,0,0),('admin_menu',355,307,'admin/build/block/list/rubik','admin/build/block/list/rubik','Rubik','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,355,0,0,0,0,0,0),('admin_menu',356,298,'admin/build/themes/settings/rubik','admin/build/themes/settings/rubik','Rubik','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,356,0,0,0,0,0,0),('admin_menu',357,307,'admin/build/block/list/tao','admin/build/block/list/tao','Tao','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,357,0,0,0,0,0,0),('admin_menu',358,298,'admin/build/themes/settings/tao','admin/build/themes/settings/tao','Tao','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,358,0,0,0,0,0,0),('admin_menu',359,307,'admin/build/block/list/zen','admin/build/block/list/zen','Zen','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,246,307,359,0,0,0,0,0,0),('admin_menu',360,298,'admin/build/themes/settings/zen','admin/build/themes/settings/zen','Zen','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,4,0,238,274,298,360,0,0,0,0,0,0),('admin_menu',361,273,'admin/content/taxonomy/add/vocabulary','admin/content/taxonomy/add/vocabulary','Add vocabulary','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,273,361,0,0,0,0,0,0,0),('admin_menu',362,231,'admin/reports/status/run-cron','admin/reports/status/run-cron','Run cron','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,50,2,0,231,362,0,0,0,0,0,0,0,0),('admin_menu',364,239,'admin/by-module','admin/by-module','By module','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,-10,2,0,239,364,0,0,0,0,0,0,0,0),('admin_menu',365,231,'http://drupal.org','','Drupal.org','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,1,0,100,2,0,231,365,0,0,0,0,0,0,0,0),('admin_menu',366,365,'http://drupal.org/project/issues/drupal','','Drupal issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,-10,3,0,231,365,366,0,0,0,0,0,0,0),('admin_menu',367,365,'http://drupal.org/project/issues/admin','','Admin issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,367,0,0,0,0,0,0,0),('admin_menu',368,365,'http://drupal.org/project/issues/admin_menu','','Administration menu issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,368,0,0,0,0,0,0,0),('admin_menu',369,365,'http://drupal.org/project/issues/advanced_help','','Advanced help issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,369,0,0,0,0,0,0,0),('admin_menu',370,365,'http://drupal.org/project/issues/better_formats','','Better Formats issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,370,0,0,0,0,0,0,0),('admin_menu',371,365,'http://drupal.org/project/issues/cck','','Content issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,371,0,0,0,0,0,0,0),('admin_menu',372,365,'http://drupal.org/project/issues/context','','Context issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,372,0,0,0,0,0,0,0),('admin_menu',373,365,'http://drupal.org/project/issues/context_admin','','Contextual Administration issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,373,0,0,0,0,0,0,0),('admin_menu',374,365,'http://drupal.org/project/issues/ctools','','Chaos tools issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,374,0,0,0,0,0,0,0),('admin_menu',375,365,'http://drupal.org/project/issues/date','','Date issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,375,0,0,0,0,0,0,0),('admin_menu',376,365,'http://drupal.org/project/issues/devel','','Devel issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,376,0,0,0,0,0,0,0),('admin_menu',377,365,'http://drupal.org/project/issues/doune_theme_settings','','Doune Theme Settings issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,377,0,0,0,0,0,0,0),('admin_menu',378,365,'http://drupal.org/project/issues/features','','Features issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,378,0,0,0,0,0,0,0),('admin_menu',379,365,'http://drupal.org/project/issues/filefield','','FileField issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,379,0,0,0,0,0,0,0),('admin_menu',380,365,'http://drupal.org/project/issues/image_resize_filter','','Image resize filter issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,380,0,0,0,0,0,0,0),('admin_menu',381,365,'http://drupal.org/project/issues/imagefield','','ImageField issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,381,0,0,0,0,0,0,0),('admin_menu',382,365,'http://drupal.org/project/issues/insert','','Insert issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,382,0,0,0,0,0,0,0),('admin_menu',383,365,'http://drupal.org/project/issues/less','','LESS CSS Preprocessor issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,383,0,0,0,0,0,0,0),('admin_menu',384,365,'http://drupal.org/project/issues/libraries','','Libraries issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,384,0,0,0,0,0,0,0),('admin_menu',385,365,'http://drupal.org/project/issues/link','','Link issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,385,0,0,0,0,0,0,0),('admin_menu',386,365,'http://drupal.org/project/issues/nodequeue','','Nodequeue issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,386,0,0,0,0,0,0,0),('admin_menu',387,365,'http://drupal.org/project/issues/os_admin','','OpenSourcery Admin issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,387,0,0,0,0,0,0,0),('admin_menu',388,365,'http://drupal.org/project/issues/os_base','','OpenSourcery base issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,388,0,0,0,0,0,0,0),('admin_menu',389,365,'http://drupal.org/project/issues/os_blog','','Blog post issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,389,0,0,0,0,0,0,0),('admin_menu',390,365,'http://drupal.org/project/issues/os_event','','OpenSourcery Events Feature issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,390,0,0,0,0,0,0,0),('admin_menu',391,365,'http://drupal.org/project/issues/os_slideshow','','Action Center Homepage Slideshow issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,391,0,0,0,0,0,0,0),('admin_menu',392,365,'http://drupal.org/project/issues/path_redirect','','Path redirect issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,392,0,0,0,0,0,0,0),('admin_menu',393,365,'http://drupal.org/project/issues/pathauto','','Pathauto issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,393,0,0,0,0,0,0,0),('admin_menu',394,365,'http://drupal.org/project/issues/role_delegation','','Role Delegation issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,394,0,0,0,0,0,0,0),('admin_menu',395,365,'http://drupal.org/project/issues/semanticviews','','Semantic Views issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,395,0,0,0,0,0,0,0),('admin_menu',396,365,'http://drupal.org/project/issues/strongarm','','Strongarm issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,396,0,0,0,0,0,0,0),('admin_menu',397,365,'http://drupal.org/project/issues/token','','Token issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,397,0,0,0,0,0,0,0),('admin_menu',398,365,'http://drupal.org/project/issues/views','','Views issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,398,0,0,0,0,0,0,0),('admin_menu',399,365,'http://drupal.org/project/issues/views_bulk_operations','','Views Bulk Operations issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,399,0,0,0,0,0,0,0),('admin_menu',400,365,'http://drupal.org/project/issues/views_cycle','','Views Cycle issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,400,0,0,0,0,0,0,0),('admin_menu',401,365,'http://drupal.org/project/issues/wp_comments','','WordPress Comments issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,401,0,0,0,0,0,0,0),('admin_menu',402,365,'http://drupal.org/project/issues/wysiwyg','','Wysiwyg issue queue','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,1,0,0,0,3,0,231,365,402,0,0,0,0,0,0,0),('admin_menu',403,235,'node/add','node/add','Create content','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,2,0,235,403,0,0,0,0,0,0,0,0),('admin_menu',404,403,'node/add/blog','node/add/blog','Blog post','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,403,404,0,0,0,0,0,0,0),('admin_menu',405,403,'node/add/event','node/add/event','Event','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,403,405,0,0,0,0,0,0,0),('admin_menu',406,403,'node/add/page','node/add/page','Page','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,403,406,0,0,0,0,0,0,0),('admin_menu',407,403,'node/add/slide','node/add/slide','Slide','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,403,407,0,0,0,0,0,0,0),('admin_menu',408,403,'node/add/webform','node/add/webform','Webform','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,3,0,235,403,408,0,0,0,0,0,0,0),('admin_menu',409,250,'admin/content/node-type/page','admin/content/node-type/page','Edit !content-type','a:2:{s:1:\"t\";a:1:{s:13:\"!content-type\";s:4:\"Page\";}s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,3,0,235,250,409,0,0,0,0,0,0,0),('admin_menu',410,409,'admin/content/node-type/page/display','admin/content/node-type/page/display','Display fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,2,4,0,235,250,409,410,0,0,0,0,0,0),('admin_menu',411,410,'admin/content/node-type/page/display/basic','admin/content/node-type/page/display/basic','Basic','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,409,410,411,0,0,0,0,0),('admin_menu',412,410,'admin/content/node-type/page/display/rss','admin/content/node-type/page/display/rss','RSS','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,409,410,412,0,0,0,0,0),('admin_menu',413,410,'admin/content/node-type/page/display/token','admin/content/node-type/page/display/token','Token','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,409,410,413,0,0,0,0,0),('admin_menu',414,409,'admin/content/node-type/page/fields','admin/content/node-type/page/fields','Manage fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,4,0,235,250,409,414,0,0,0,0,0,0),('admin_menu',415,250,'admin/content/node-type/blog','admin/content/node-type/blog','Edit !content-type','a:2:{s:1:\"t\";a:1:{s:13:\"!content-type\";s:9:\"Blog post\";}s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,3,0,235,250,415,0,0,0,0,0,0,0),('admin_menu',416,415,'admin/content/node-type/blog/display','admin/content/node-type/blog/display','Display fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,2,4,0,235,250,415,416,0,0,0,0,0,0),('admin_menu',417,416,'admin/content/node-type/blog/display/basic','admin/content/node-type/blog/display/basic','Basic','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,415,416,417,0,0,0,0,0),('admin_menu',418,416,'admin/content/node-type/blog/display/rss','admin/content/node-type/blog/display/rss','RSS','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,415,416,418,0,0,0,0,0),('admin_menu',419,416,'admin/content/node-type/blog/display/token','admin/content/node-type/blog/display/token','Token','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,415,416,419,0,0,0,0,0),('admin_menu',420,415,'admin/content/node-type/blog/fields','admin/content/node-type/blog/fields','Manage fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,1,4,0,235,250,415,420,0,0,0,0,0,0),('admin_menu',421,420,'admin/content/node-type/blog/fields/field_blog_images','admin/content/node-type/blog/fields/field_blog_images','Image(s)','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,415,420,421,0,0,0,0,0),('admin_menu',422,250,'admin/content/node-type/event','admin/content/node-type/event','Edit !content-type','a:2:{s:1:\"t\";a:1:{s:13:\"!content-type\";s:5:\"Event\";}s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,3,0,235,250,422,0,0,0,0,0,0,0),('admin_menu',423,422,'admin/content/node-type/event/display','admin/content/node-type/event/display','Display fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,2,4,0,235,250,422,423,0,0,0,0,0,0),('admin_menu',424,423,'admin/content/node-type/event/display/basic','admin/content/node-type/event/display/basic','Basic','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,422,423,424,0,0,0,0,0),('admin_menu',425,423,'admin/content/node-type/event/display/rss','admin/content/node-type/event/display/rss','RSS','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,422,423,425,0,0,0,0,0),('admin_menu',426,423,'admin/content/node-type/event/display/token','admin/content/node-type/event/display/token','Token','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,422,423,426,0,0,0,0,0),('admin_menu',427,422,'admin/content/node-type/event/fields','admin/content/node-type/event/fields','Manage fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,1,4,0,235,250,422,427,0,0,0,0,0,0),('admin_menu',428,427,'admin/content/node-type/event/fields/field_event_date','admin/content/node-type/event/fields/field_event_date','Date/time','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,422,427,428,0,0,0,0,0),('admin_menu',429,427,'admin/content/node-type/event/fields/field_event_image','admin/content/node-type/event/fields/field_event_image','Image(s)','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,422,427,429,0,0,0,0,0),('admin_menu',430,250,'admin/content/node-type/slide','admin/content/node-type/slide','Edit !content-type','a:2:{s:1:\"t\";a:1:{s:13:\"!content-type\";s:5:\"Slide\";}s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,3,0,235,250,430,0,0,0,0,0,0,0),('admin_menu',431,430,'admin/content/node-type/slide/display','admin/content/node-type/slide/display','Display fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,2,4,0,235,250,430,431,0,0,0,0,0,0),('admin_menu',432,431,'admin/content/node-type/slide/display/basic','admin/content/node-type/slide/display/basic','Basic','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,430,431,432,0,0,0,0,0),('admin_menu',433,431,'admin/content/node-type/slide/display/rss','admin/content/node-type/slide/display/rss','RSS','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,430,431,433,0,0,0,0,0),('admin_menu',434,431,'admin/content/node-type/slide/display/token','admin/content/node-type/slide/display/token','Token','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,430,431,434,0,0,0,0,0),('admin_menu',435,430,'admin/content/node-type/slide/fields','admin/content/node-type/slide/fields','Manage fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,1,4,0,235,250,430,435,0,0,0,0,0,0),('admin_menu',436,435,'admin/content/node-type/slide/fields/field_slide_image','admin/content/node-type/slide/fields/field_slide_image','Slide image','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,430,435,436,0,0,0,0,0),('admin_menu',437,435,'admin/content/node-type/slide/fields/field_slide_link','admin/content/node-type/slide/fields/field_slide_link','Link','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,430,435,437,0,0,0,0,0),('admin_menu',438,250,'admin/content/node-type/webform','admin/content/node-type/webform','Edit !content-type','a:2:{s:1:\"t\";a:1:{s:13:\"!content-type\";s:7:\"Webform\";}s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,0,3,0,235,250,438,0,0,0,0,0,0,0),('admin_menu',439,438,'admin/content/node-type/webform/display','admin/content/node-type/webform/display','Display fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,1,0,2,4,0,235,250,438,439,0,0,0,0,0,0),('admin_menu',440,439,'admin/content/node-type/webform/display/basic','admin/content/node-type/webform/display/basic','Basic','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,5,0,235,250,438,439,440,0,0,0,0,0),('admin_menu',441,439,'admin/content/node-type/webform/display/rss','admin/content/node-type/webform/display/rss','RSS','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,438,439,441,0,0,0,0,0),('admin_menu',442,439,'admin/content/node-type/webform/display/token','admin/content/node-type/webform/display/token','Token','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,5,0,235,250,438,439,442,0,0,0,0,0),('admin_menu',443,438,'admin/content/node-type/webform/fields','admin/content/node-type/webform/fields','Manage fields','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,1,4,0,235,250,438,443,0,0,0,0,0,0),('admin_menu',444,231,'admin_menu/flush-cache','admin_menu/flush-cache','Flush all caches','a:2:{s:5:\"alter\";b:1;s:5:\"query\";s:11:\"destination\";}','admin_menu',0,0,1,0,20,2,0,231,444,0,0,0,0,0,0,0,0),('admin_menu',445,444,'admin_menu/flush-cache/admin_menu','admin_menu/flush-cache','Administration menu','a:2:{s:5:\"alter\";b:1;s:5:\"query\";s:11:\"destination\";}','admin_menu',0,0,0,0,0,3,0,231,444,445,0,0,0,0,0,0,0),('admin_menu',446,444,'admin_menu/flush-cache/cache','admin_menu/flush-cache','Cache tables','a:2:{s:5:\"alter\";b:1;s:5:\"query\";s:11:\"destination\";}','admin_menu',0,0,0,0,0,3,0,231,444,446,0,0,0,0,0,0,0),('admin_menu',447,444,'admin_menu/flush-cache/menu','admin_menu/flush-cache','Menu','a:2:{s:5:\"alter\";b:1;s:5:\"query\";s:11:\"destination\";}','admin_menu',0,0,0,0,0,3,0,231,444,447,0,0,0,0,0,0,0),('admin_menu',448,444,'admin_menu/flush-cache/requisites','admin_menu/flush-cache','Page requisites','a:2:{s:5:\"alter\";b:1;s:5:\"query\";s:11:\"destination\";}','admin_menu',0,0,0,0,0,3,0,231,444,448,0,0,0,0,0,0,0),('admin_menu',449,444,'admin_menu/flush-cache/theme','admin_menu/flush-cache','Theme registry','a:2:{s:5:\"alter\";b:1;s:5:\"query\";s:11:\"destination\";}','admin_menu',0,0,0,0,0,3,0,231,444,449,0,0,0,0,0,0,0),('admin_menu',450,231,'devel/variable','devel/variable','Variable editor','a:1:{s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,20,2,0,231,450,0,0,0,0,0,0,0,0),('admin_menu',451,232,'devel/switch/OpenSourcery Administrator','devel/switch','<em>OpenSourcery Administrator</em>','a:3:{s:5:\"query\";s:20:\"destination=node%2F1\";s:4:\"html\";b:1;s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,232,451,0,0,0,0,0,0,0,0),('admin_menu',452,232,'devel/switch/Editor','devel/switch','Editor','a:3:{s:5:\"query\";s:20:\"destination=node%2F1\";s:4:\"html\";b:0;s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,232,452,0,0,0,0,0,0,0,0),('admin_menu',453,232,'devel/switch/Administrator','devel/switch','Administrator','a:3:{s:5:\"query\";s:20:\"destination=node%2F1\";s:4:\"html\";b:0;s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,0,2,0,232,453,0,0,0,0,0,0,0,0),('admin_menu',454,231,'admin_menu/toggle-modules','admin_menu/toggle-modules','Disable developer modules','a:2:{s:5:\"query\";s:11:\"destination\";s:5:\"alter\";b:1;}','admin_menu',0,0,0,0,88,2,0,231,454,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `menu_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_router`
--

DROP TABLE IF EXISTS `menu_router`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_router` (
  `path` varchar(255) NOT NULL DEFAULT '',
  `load_functions` text NOT NULL,
  `to_arg_functions` text NOT NULL,
  `access_callback` varchar(255) NOT NULL DEFAULT '',
  `access_arguments` text,
  `page_callback` varchar(255) NOT NULL DEFAULT '',
  `page_arguments` text,
  `fit` int(11) NOT NULL DEFAULT '0',
  `number_parts` smallint(6) NOT NULL DEFAULT '0',
  `tab_parent` varchar(255) NOT NULL DEFAULT '',
  `tab_root` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_callback` varchar(255) NOT NULL DEFAULT '',
  `title_arguments` varchar(255) NOT NULL DEFAULT '',
  `type` int(11) NOT NULL DEFAULT '0',
  `block_callback` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `position` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL DEFAULT '0',
  `file` mediumtext,
  PRIMARY KEY (`path`),
  KEY `fit` (`fit`),
  KEY `tab_parent` (`tab_parent`),
  KEY `tab_root_weight_title` (`tab_root`(64),`weight`,`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_router`
--

LOCK TABLES `menu_router` WRITE;
/*!40000 ALTER TABLE `menu_router` DISABLE KEYS */;
INSERT INTO `menu_router` VALUES ('node','','','user_access','a:1:{i:0;s:14:\"access content\";}','node_page_default','a:0:{}',1,1,'','node','Content','t','',4,'','','',0,''),('rss.xml','','','user_access','a:1:{i:0;s:14:\"access content\";}','node_feed','a:0:{}',1,1,'','rss.xml','RSS feed','t','',4,'','','',0,''),('batch','','','1','a:0:{}','system_batch_page','a:0:{}',1,1,'','batch','','t','',4,'','','',0,'modules/system/system.admin.inc'),('logout','','','user_is_logged_in','a:0:{}','user_logout','a:0:{}',1,1,'','logout','Log out','t','',6,'','','',10,'modules/user/user.pages.inc'),('user','','','1','a:0:{}','user_page','a:0:{}',1,1,'','user','User account','t','',4,'','','',0,'modules/user/user.pages.inc'),('admin','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_main_admin_page','a:0:{}',1,1,'','admin','Administer','t','',6,'','','',9,'modules/system/system.admin.inc'),('blog','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:4:\"blog\";i:1;s:6:\"page_1\";}',1,1,'','blog','Blog','t','',6,'','','',0,''),('events','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:10:\"event_list\";i:1;s:6:\"page_1\";}',1,1,'','events','Events','t','',6,'','','',0,''),('user/login','','','user_is_anonymous','a:0:{}','user_page','a:0:{}',3,2,'user','user','Log in','t','',136,'','','',0,'modules/user/user.pages.inc'),('nodequeue/autocomplete','','','user_access','a:1:{i:0;s:17:\"manipulate queues\";}','nodequeue_autocomplete','a:0:{}',3,2,'','nodequeue/autocomplete','Autocomplete','t','',4,'','','',0,''),('system/files','','','1','a:0:{}','file_download','a:0:{}',3,2,'','system/files','File download','t','',4,'','','',0,''),('filefield/progress','','','user_access','a:1:{i:0;s:14:\"access content\";}','filefield_progress','a:0:{}',3,2,'','filefield/progress','','t','',4,'','','',0,''),('user/timezone','','','1','a:0:{}','user_timezone','a:0:{}',3,2,'','user/timezone','User timezone','t','',4,'','','',0,''),('admin_menu/flush-cache','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','admin_menu_flush_cache','a:0:{}',3,2,'','admin_menu/flush-cache','','t','',4,'','','',0,'profiles/os_demo/modules/development/admin_menu/admin_menu.inc'),('admin_menu/toggle-modules','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','admin_menu_toggle_modules','a:0:{}',3,2,'','admin_menu/toggle-modules','','t','',4,'','','',0,'profiles/os_demo/modules/development/admin_menu/admin_menu.inc'),('admin/advanced_help','','','user_access','a:1:{i:0;s:24:\"view advanced help index\";}','advanced_help_index_page','a:0:{}',3,2,'','admin/advanced_help','Advanced help','t','',6,'','','',9,''),('content/js_add_more','','','user_access','a:1:{i:0;s:14:\"access content\";}','content_add_more_js','a:0:{}',3,2,'','content/js_add_more','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.node_form.inc'),('taxonomy/autocomplete','','','user_access','a:1:{i:0;s:14:\"access content\";}','taxonomy_autocomplete','a:0:{}',3,2,'','taxonomy/autocomplete','Autocomplete taxonomy','t','',4,'','','',0,'modules/taxonomy/taxonomy.pages.inc'),('admin/by-module','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_admin_by_module','a:0:{}',3,2,'admin','admin','By module','t','',128,'','','',2,'modules/system/system.admin.inc'),('admin/by-task','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_main_admin_page','a:0:{}',3,2,'admin','admin','By task','t','',136,'','','',0,'modules/system/system.admin.inc'),('filter/tips','','','1','a:0:{}','filter_tips_long','a:0:{}',3,2,'','filter/tips','Compose tips','t','',20,'','','',0,'modules/filter/filter.pages.inc'),('node/add','','','_node_add_access','a:0:{}','node_add_page','a:0:{}',3,2,'','node/add','Create content','t','',6,'','','',1,'modules/node/node.pages.inc'),('comment/delete','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_delete','a:0:{}',3,2,'','comment/delete','Delete comment','t','',4,'','','',0,'modules/comment/comment.admin.inc'),('devel/source','','','user_access','a:1:{i:0;s:19:\"display source code\";}','devel_display_source','a:0:{}',3,2,'','devel/source','Display the PHP code of any file in your Drupal installation','t','',4,'','','',0,''),('comment/edit','','','user_access','a:1:{i:0;s:13:\"post comments\";}','comment_edit','a:0:{}',3,2,'','comment/edit','Edit comment','t','',4,'','','',0,'modules/comment/comment.pages.inc'),('devel/switch','','','user_access','a:1:{i:0;s:12:\"switch users\";}','devel_switch_user','a:0:{}',3,2,'','devel/switch','Switch user','t','',4,'','','',0,''),('blog/rss.xml','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:4:\"blog\";i:1;s:6:\"feed_1\";}',3,2,'','blog/rss.xml','','t','',4,'','','',0,''),('user/register','','','user_register_access','a:0:{}','drupal_get_form','a:1:{i:0;s:13:\"user_register\";}',3,2,'user','user','Create new account','t','',128,'','','',0,'modules/user/user.pages.inc'),('views/ajax','','','1','a:0:{}','views_ajax','a:0:{}',3,2,'','views/ajax','Views','t','',4,'','Ajax callback for view loading.','',0,'profiles/os_demo/modules/contrib/views/includes/ajax.inc'),('blog/archive','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:12:\"blog_archive\";i:1;s:4:\"page\";}',3,2,'','blog/archive','','t','',4,'','','',0,''),('user/password','','','user_is_anonymous','a:0:{}','drupal_get_form','a:1:{i:0;s:9:\"user_pass\";}',3,2,'user','user','Request new password','t','',128,'','','',0,'modules/user/user.pages.inc'),('events/rss.xml','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:10:\"event_list\";i:1;s:6:\"feed_1\";}',3,2,'','events/rss.xml','','t','',4,'','','',0,''),('events/archive','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:10:\"event_list\";i:1;s:6:\"page_2\";}',3,2,'','events/archive','','t','',4,'','','',0,''),('wysiwyg/%','a:1:{i:1;N;}','','user_access','a:1:{i:0;s:14:\"access content\";}','wysiwyg_dialog','a:1:{i:0;i:1;}',2,2,'','wysiwyg/%','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/wysiwyg/wysiwyg.dialog.inc'),('admin/compact','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_admin_compact_page','a:0:{}',3,2,'','admin/compact','Compact mode','t','',4,'','','',0,'modules/system/system.admin.inc'),('devel/queries','','','devel_menu_access_store_queries','a:0:{}','devel_queries','a:0:{}',3,2,'','devel/queries','Database queries','t','',6,'','','',0,''),('devel/reference','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_function_reference','a:0:{}',3,2,'','devel/reference','Function reference','t','',6,'','View a list of currently defined user functions with documentation links.','',0,''),('admin/help','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_main','a:0:{}',3,2,'','admin/help','Help','t','',6,'','','',9,'modules/help/help.admin.inc'),('devel/elements','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_elements_page','a:0:{}',3,2,'','devel/elements','Hook_elements()','t','',6,'','View the active form/render elements for this site.','',0,''),('devel/phpinfo','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_phpinfo','a:0:{}',3,2,'','devel/phpinfo','PHPinfo()','t','',6,'','View your server\'s PHP configuration','',0,''),('devel/session','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_session','a:0:{}',3,2,'','devel/session','Session viewer','t','',6,'','List the contents of $_SESSION.','',0,''),('user/autocomplete','','','user_access','a:1:{i:0;s:20:\"access user profiles\";}','user_autocomplete','a:0:{}',3,2,'','user/autocomplete','User autocomplete','t','',4,'','','',0,'modules/user/user.pages.inc'),('devel/variable','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_variable_page','a:0:{}',3,2,'','devel/variable','Variable editor','t','',6,'','Edit and delete site variables.','',0,''),('devel/php','','','user_access','a:1:{i:0;s:16:\"execute php code\";}','drupal_get_form','a:1:{i:0;s:18:\"devel_execute_form\";}',3,2,'','devel/php','Execute PHP Code','t','',6,'','Execute some PHP code','',0,''),('devel/reinstall','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','drupal_get_form','a:1:{i:0;s:15:\"devel_reinstall\";}',3,2,'','devel/reinstall','Reinstall modules','t','',6,'','Run hook_uninstall() and then hook_install() for a given module.','',0,''),('blog/list','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:4:\"blog\";i:1;s:6:\"page_1\";}',3,2,'blog','blog','Blog','t','',136,'','','',-42,''),('events/calendar','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:14:\"event_calendar\";i:1;s:10:\"calendar_1\";}',3,2,'events','events','Calendar','t','',128,'','','',2,''),('events/view','','','views_access','a:1:{i:0;b:1;}','views_page','a:2:{i:0;s:10:\"event_list\";i:1;s:6:\"page_1\";}',3,2,'events','events','Events','t','',136,'','','',0,''),('blog/admin','','','ctools_access_menu','a:1:{i:0;a:4:{s:7:\"plugins\";a:1:{i:0;a:3:{s:4:\"name\";s:4:\"perm\";s:8:\"settings\";a:1:{s:4:\"perm\";s:16:\"administer nodes\";}s:7:\"context\";s:14:\"logged-in-user\";}}s:5:\"logic\";s:3:\"and\";s:4:\"type\";s:4:\"none\";s:8:\"settings\";N;}}','page_manager_page_execute','a:1:{i:0;s:10:\"blog_admin\";}',3,2,'blog','blog','Administer posts','t','',128,'','','',42,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.inc'),('blog/tags','','','ctools_access_menu','a:1:{i:0;a:4:{s:7:\"plugins\";a:1:{i:0;a:3:{s:4:\"name\";s:4:\"perm\";s:8:\"settings\";a:1:{s:4:\"perm\";s:19:\"administer taxonomy\";}s:7:\"context\";s:14:\"logged-in-user\";}}s:5:\"logic\";s:3:\"and\";s:4:\"type\";s:4:\"none\";s:8:\"settings\";N;}}','page_manager_page_execute','a:1:{i:0;s:15:\"blog_admin_tags\";}',3,2,'blog','blog','Administer tags','t','',128,'','','',77,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.inc'),('blog/add','','','ctools_access_menu','a:1:{i:0;a:4:{s:7:\"plugins\";a:1:{i:0;a:3:{s:4:\"name\";s:4:\"perm\";s:8:\"settings\";a:1:{s:4:\"perm\";s:19:\"create blog content\";}s:7:\"context\";s:14:\"logged-in-user\";}}s:5:\"logic\";s:3:\"and\";s:4:\"type\";s:4:\"none\";s:8:\"settings\";N;}}','page_manager_page_execute','a:1:{i:0;s:8:\"blog_add\";}',3,2,'blog','blog','Add new blog post','t','',128,'','','',27,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.inc'),('events/add','','','ctools_access_menu','a:1:{i:0;a:4:{s:7:\"plugins\";a:1:{i:0;a:3:{s:4:\"name\";s:4:\"perm\";s:8:\"settings\";a:1:{s:4:\"perm\";s:20:\"create event content\";}s:7:\"context\";s:14:\"logged-in-user\";}}s:5:\"logic\";s:3:\"and\";s:4:\"type\";s:4:\"none\";s:8:\"settings\";N;}}','page_manager_page_execute','a:1:{i:0;s:9:\"event_add\";}',3,2,'events','events','Add new event','t','',128,'','','',27,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.inc'),('node/%','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:4:\"view\";i:1;i:1;}','node_page_view','a:1:{i:0;i:1;}',2,2,'','node/%','','node_page_title','a:1:{i:0;i:1;}',4,'','','',0,''),('admin/reports','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/reports','Reports','t','',6,'','View reports from system logs and other status information.','left',5,'modules/system/system.admin.inc'),('events/admin','','','ctools_access_menu','a:1:{i:0;a:4:{s:7:\"plugins\";a:1:{i:0;a:3:{s:4:\"name\";s:4:\"perm\";s:8:\"settings\";a:1:{s:4:\"perm\";s:16:\"administer nodes\";}s:7:\"context\";s:14:\"logged-in-user\";}}s:5:\"logic\";s:3:\"and\";s:4:\"type\";s:4:\"none\";s:8:\"settings\";N;}}','page_manager_page_execute','a:1:{i:0;s:11:\"event_admin\";}',3,2,'events','events','Administer events','t','',128,'','','',42,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.inc'),('admin/content','','','admin_landing_page_access','a:1:{i:0;s:13:\"admin/content\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/content','Content management','t','',6,'','Manage your site\'s content.','left',-10,'modules/system/system.admin.inc'),('admin/build','','','admin_landing_page_access','a:1:{i:0;s:11:\"admin/build\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/build','Site building','t','',6,'','Control how your site looks and feels.','right',-10,'modules/system/system.admin.inc'),('admin/settings','','','admin_landing_page_access','a:1:{i:0;s:14:\"admin/settings\";}','system_settings_overview','a:0:{}',3,2,'','admin/settings','Site configuration','t','',6,'','Adjust basic site configuration options.','right',-5,'modules/system/system.admin.inc'),('user/%','a:1:{i:1;s:22:\"user_uid_optional_load\";}','a:1:{i:1;s:24:\"user_uid_optional_to_arg\";}','user_view_access','a:1:{i:0;i:1;}','user_view','a:1:{i:0;i:1;}',2,2,'','user/%','My account','user_page_title','a:1:{i:0;i:1;}',6,'','','',0,'modules/user/user.pages.inc'),('admin/user','','','admin_landing_page_access','a:1:{i:0;s:10:\"admin/user\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/user','User management','t','',6,'','Manage your site\'s users, groups and access to site features.','left',0,'modules/system/system.admin.inc'),('node/%/view','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:4:\"view\";i:1;i:1;}','node_page_view','a:1:{i:0;i:1;}',5,3,'node/%','node/%','View','t','',136,'','','',-10,''),('user/%/view','a:1:{i:1;s:9:\"user_load\";}','','user_view_access','a:1:{i:0;i:1;}','user_view','a:1:{i:0;i:1;}',5,3,'user/%','user/%','View','t','',136,'','','',-10,'modules/user/user.pages.inc'),('search/advanced_help/%','a:1:{i:2;N;}','a:1:{i:2;s:16:\"menu_tail_to_arg\";}','0','a:1:{i:0;s:24:\"view advanced help index\";}','','a:0:{}',6,3,'','search/advanced_help/%','','t','',6,'','','',0,''),('help/%/%','a:2:{i:1;N;i:2;N;}','','user_access','a:1:{i:0;s:24:\"view advanced help topic\";}','advanced_help_topic_page','a:2:{i:0;i:1;i:1;i:2;}',4,3,'','help/%/%','','t','',4,'','','',0,''),('ctools/autocomplete/node','','','user_access','a:1:{i:0;s:14:\"access content\";}','ctools_content_autocomplete_node','a:0:{}',7,3,'','ctools/autocomplete/node','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/includes/content.menu.inc'),('user/%/roles','a:1:{i:1;s:9:\"user_load\";}','','role_delegation_access','a:0:{}','drupal_get_form','a:2:{i:0;s:26:\"role_delegation_roles_form\";i:1;i:1;}',5,3,'user/%','user/%','Roles','t','',128,'','','',0,''),('advanced_help/search/%','a:1:{i:2;N;}','a:1:{i:2;s:16:\"menu_tail_to_arg\";}','user_access','a:1:{i:0;s:24:\"view advanced help index\";}','advanced_help_search_view','a:1:{i:0;s:13:\"advanced_help\";}',6,3,'','advanced_help/search/%','Search help','t','',6,'','','',0,''),('js/path_redirect/autocomplete_404','','','user_access','a:1:{i:0;s:20:\"administer redirects\";}','path_redirect_js_autocomplete_404','a:0:{}',7,3,'','js/path_redirect/autocomplete_404','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/path_redirect/path_redirect.admin.inc'),('admin/settings/actions','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','system_actions_manage','a:0:{}',7,3,'','admin/settings/actions','Actions','t','',6,'','Manage the actions defined for your site.','',0,''),('node/%/devel','a:1:{i:1;s:9:\"node_load\";}','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_load_object','a:2:{i:0;i:1;i:1;s:4:\"node\";}',5,3,'node/%','node/%','Devel','t','',128,'','','',100,''),('user/%/devel','a:1:{i:1;s:9:\"user_load\";}','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_load_object','a:2:{i:0;i:1;i:1;s:4:\"user\";}',5,3,'user/%','user/%','Devel','t','',128,'','','',100,''),('devel/cache/clear','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_cache_clear','a:0:{}',7,3,'','devel/cache/clear','Empty cache','t','',6,'','Clear the CSS cache and all database cache tables which store page, node, theme and variable caches.','',0,''),('devel/queries/empty','','','devel_menu_access_store_queries','a:0:{}','devel_queries_empty','a:0:{}',7,3,'','devel/queries/empty','Empty database queries','t','',6,'','','',0,''),('admin/content/nodequeue','','','_nodequeue_access_admin_or_manipulate','a:0:{}','nodequeue_view_queues','a:0:{}',7,3,'','admin/content/nodequeue','Nodequeue','t','',6,'','Create and maintain simple nodequeues.','',0,''),('taxonomy/term/%','a:1:{i:2;N;}','','user_access','a:1:{i:0;s:14:\"access content\";}','taxonomy_term_page','a:1:{i:0;i:2;}',6,3,'','taxonomy/term/%','Taxonomy term','t','',4,'','','',0,'modules/taxonomy/taxonomy.pages.inc'),('devel/theme/registry','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_theme_registry','a:0:{}',7,3,'','devel/theme/registry','Theme registry','t','',6,'','View a list of available theme functions across the whole site.','',0,''),('node/%/done','a:1:{i:1;s:17:\"webform_menu_load\";}','','node_access','a:2:{i:0;s:4:\"view\";i:1;i:1;}','_webform_confirmation','a:1:{i:0;i:1;}',5,3,'','node/%/done','Webform confirmation','t','',4,'','','',0,''),('admin/content/node2','','','views_access','a:1:{i:0;a:2:{i:0;s:16:\"views_check_perm\";i:1;a:1:{i:0;s:16:\"administer nodes\";}}}','views_page','a:2:{i:0;s:13:\"admin_content\";i:1;s:4:\"page\";}',7,3,'','admin/content/node2','','t','',4,'','','',0,''),('node/%/nodequeue','a:1:{i:1;s:9:\"node_load\";}','','nodequeue_node_tab_access','a:1:{i:0;i:1;}','nodequeue_node_tab','a:1:{i:0;i:1;}',5,3,'node/%','node/%','@tab','t','a:1:{s:4:\"@tab\";s:9:\"Nodequeue\";}',128,'','','',5,''),('admin/user/rules','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','user_admin_access','a:0:{}',7,3,'','admin/user/rules','Access rules','t','',6,'','List and create rules to disallow usernames, e-mail addresses, and IP addresses.','',0,'modules/user/user.admin.inc'),('admin/reports/updates','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','update_status','a:0:{}',7,3,'','admin/reports/updates','Available updates','t','',6,'','Get a status report about available updates for your installed modules and themes.','',10,'modules/update/update.report.inc'),('admin/build/block','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','block_admin_display','a:0:{}',7,3,'','admin/build/block','Blocks','t','',6,'','Configure what block content appears in your site\'s sidebars and other regions.','',0,'modules/block/block.admin.inc'),('admin/content/comment','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_admin','a:0:{}',7,3,'','admin/content/comment','Comments','t','',6,'','List and edit site comments and the comment moderation queue.','',0,'modules/comment/comment.admin.inc'),('node/%/delete','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:6:\"delete\";i:1;i:1;}','drupal_get_form','a:2:{i:0;s:19:\"node_delete_confirm\";i:1;i:1;}',5,3,'','node/%/delete','Delete','t','',4,'','','',1,'modules/node/node.pages.inc'),('user/%/delete','a:1:{i:1;s:9:\"user_load\";}','','user_access','a:1:{i:0;s:16:\"administer users\";}','drupal_get_form','a:2:{i:0;s:19:\"user_confirm_delete\";i:1;i:1;}',5,3,'','user/%/delete','Delete','t','',4,'','','',0,'modules/user/user.pages.inc'),('admin/settings/devel','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:20:\"devel_admin_settings\";}',7,3,'','admin/settings/devel','Devel settings','t','',6,'','Helper functions, pages, and blocks to assist Drupal developers. The devel blocks can be managed via the <a href=\"/admin/build/block\">block administration</a> page.','',0,''),('node/%/edit','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','node_page_edit','a:1:{i:0;i:1;}',5,3,'node/%','node/%','Edit','t','',128,'','','',1,'modules/node/node.pages.inc'),('admin/settings/logging','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_logging_overview','a:0:{}',7,3,'','admin/settings/logging','Logging and alerts','t','',6,'','Settings for logging and alerts modules. Various modules can route Drupal\'s system events to different destination, such as syslog, database, email, ...etc.','',0,'modules/system/system.admin.inc'),('admin/build/pages','','','user_access','a:1:{i:0;s:16:\"use page manager\";}','page_manager_list_page','a:0:{}',7,3,'','admin/build/pages','Pages','t','',6,'','Add, edit and remove overridden system pages and user defined pages from the system.','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/page_manager.admin.inc'),('devel/menu/reset','','','user_access','a:1:{i:0;s:24:\"access devel information\";}','drupal_get_form','a:1:{i:0;s:18:\"devel_menu_rebuild\";}',7,3,'','devel/menu/reset','Rebuild menus','t','',6,'','Rebuild menu based on hook_menu() and revert any custom changes. All menu items return to their default settings.','',0,''),('admin/reports/dblog','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_overview','a:0:{}',7,3,'','admin/reports/dblog','Recent log entries','t','',6,'','View events that have recently been logged.','',-1,'modules/dblog/dblog.admin.inc'),('comment/reply/%','a:1:{i:2;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:4:\"view\";i:1;i:2;}','comment_reply','a:1:{i:0;i:2;}',6,3,'','comment/reply/%','Reply to comment','t','',4,'','','',0,'modules/comment/comment.pages.inc'),('node/%/webform-results','a:1:{i:1;s:17:\"webform_menu_load\";}','','webform_results_access','a:1:{i:0;i:1;}','webform_results_submissions','a:3:{i:0;i:1;i:1;b:0;i:2;s:2:\"50\";}',5,3,'node/%','node/%','Results','t','',128,'','','',2,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('node/%/revisions','a:1:{i:1;s:9:\"node_load\";}','','_node_revision_access','a:1:{i:0;i:1;}','node_revision_overview','a:1:{i:0;i:1;}',5,3,'node/%','node/%','Revisions','t','',128,'','','',2,'modules/node/node.pages.inc'),('admin/reports/status','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_status','a:0:{}',7,3,'','admin/reports/status','Status report','t','',6,'','Get a status report about your site\'s operation and any detected problems.','',10,'modules/system/system.admin.inc'),('node/%/submissions','a:1:{i:1;s:17:\"webform_menu_load\";}','','webform_submission_access','a:3:{i:0;i:1;i:1;N;i:2;s:4:\"list\";}','webform_results_submissions','a:3:{i:0;i:1;i:1;b:1;i:2;s:2:\"50\";}',5,3,'','node/%/submissions','Submissions','t','',4,'','','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('admin/build/path','','','user_access','a:1:{i:0;s:22:\"administer url aliases\";}','path_admin_overview','a:0:{}',7,3,'','admin/build/path','URL aliases','t','',6,'','Change your site\'s URL paths by aliasing them.','',0,'modules/path/path.admin.inc'),('admin/settings/vertical-tabs','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:27:\"vertical_tabs_settings_form\";}',7,3,'','admin/settings/vertical-tabs','Vertical Tabs','t','',6,'','','',0,'profiles/os_demo/modules/contrib/vertical_tabs/vertical_tabs.admin.inc'),('node/%/webform','a:1:{i:1;s:17:\"webform_menu_load\";}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','webform_components_page','a:1:{i:0;i:1;}',5,3,'node/%','node/%','Webform','t','',128,'','','',1,'profiles/os_demo/modules/contrib/webform/includes/webform.components.inc'),('admin/help/admin_menu','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/admin_menu','admin_menu','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/better_formats','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/better_formats','better_formats','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/block','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/block','block','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/calendar','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/calendar','calendar','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/comment','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/comment','comment','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/content','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/content','content','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/context','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/context','context','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/date','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/date','date','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/dblog','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/dblog','dblog','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/devel','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/devel','devel','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/features','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/features','features','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/filter','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/filter','filter','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/help','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/help','help','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/image_resize_filter','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/image_resize_filter','image_resize_filter','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/menu','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/menu','menu','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/node','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/node','node','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/path','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/path','path','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/path_redirect','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/path_redirect','path_redirect','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/pathauto','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/pathauto','pathauto','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/role_delegation','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/role_delegation','role_delegation','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/strongarm','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/strongarm','strongarm','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/system','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/system','system','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/taxonomy','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/taxonomy','taxonomy','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/token','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/token','token','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/update','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/update','update','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/user','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/user','user','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/webform','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/webform','webform','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/help/wysiwyg','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/wysiwyg','wysiwyg','t','',4,'','','',0,'modules/help/help.admin.inc'),('admin/settings/admin_menu','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"admin_menu_theme_settings\";}',7,3,'','admin/settings/admin_menu','Administration menu','t','',6,'','Adjust administration menu settings.','',0,'profiles/os_demo/modules/development/admin_menu/admin_menu.inc'),('admin/settings/clean-urls','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"system_clean_url_settings\";}',7,3,'','admin/settings/clean-urls','Clean URLs','t','',6,'','Enable or disable clean URLs for your site.','',0,'modules/system/system.admin.inc'),('admin/content/node','','','user_access','a:1:{i:0;s:16:\"administer nodes\";}','drupal_get_form','a:1:{i:0;s:18:\"node_admin_content\";}',7,3,'','admin/content/node','Content','t','',6,'','View, edit, and delete your site\'s content.','',0,'modules/node/node.admin.inc'),('admin/content/types','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','content_types_overview','a:0:{}',7,3,'','admin/content/types','Content types','t','',6,'','Manage posts by content type, including default status, front page promotion, etc.','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/settings/date-time','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"system_date_time_settings\";}',7,3,'','admin/settings/date-time','Date and time','t','',6,'','Settings for how Drupal displays date and time, as well as the system\'s default timezone.','',0,'modules/system/system.admin.inc'),('user/%/edit','a:1:{i:1;a:1:{s:18:\"user_category_load\";a:2:{i:0;s:4:\"%map\";i:1;s:6:\"%index\";}}}','','user_edit_access','a:1:{i:0;i:1;}','user_edit','a:1:{i:0;i:1;}',5,3,'user/%','user/%','Edit','t','',128,'','','',0,'modules/user/user.pages.inc'),('admin/settings/error-reporting','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:31:\"system_error_reporting_settings\";}',7,3,'','admin/settings/error-reporting','Error reporting','t','',6,'','Control how Drupal deals with errors including 403/404 errors as well as PHP error reporting.','',0,'modules/system/system.admin.inc'),('admin/settings/file-system','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:27:\"system_file_system_settings\";}',7,3,'','admin/settings/file-system','File system','t','',6,'','Tell Drupal where to store uploaded files and how they are accessed.','',0,'modules/system/system.admin.inc'),('admin/settings/image-toolkit','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:29:\"system_image_toolkit_settings\";}',7,3,'','admin/settings/image-toolkit','Image toolkit','t','',6,'','Choose which image toolkit to use if you have installed optional toolkits.','',0,'modules/system/system.admin.inc'),('admin/settings/filters','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:21:\"filter_admin_overview\";}',7,3,'','admin/settings/filters','Input formats','t','',6,'','Configure how content input by users is filtered, including allowed HTML tags. Also allows enabling of module-provided filters.','',0,'modules/filter/filter.admin.inc'),('node/%/add-sub-page','a:1:{i:1;a:1:{s:11:\"pm_arg_load\";a:3:{i:0;s:8:\"sub_page\";i:1;s:6:\"%index\";i:2;s:4:\"%map\";}}}','','ctools_access_menu','a:2:{i:0;a:4:{s:7:\"plugins\";a:3:{i:0;a:3:{s:4:\"name\";s:9:\"node_type\";s:8:\"settings\";a:1:{s:4:\"type\";a:1:{s:4:\"page\";s:4:\"page\";}}s:7:\"context\";s:14:\"argument_nid_1\";}i:1;a:3:{s:4:\"name\";s:4:\"perm\";s:8:\"settings\";a:1:{s:4:\"perm\";s:19:\"create page content\";}s:7:\"context\";s:14:\"logged-in-user\";}i:2;a:4:{s:4:\"name\";s:15:\"node_menu_depth\";s:8:\"settings\";a:2:{s:4:\"menu\";s:13:\"primary-links\";s:10:\"menu_depth\";s:2:\"p3\";}s:7:\"context\";s:14:\"argument_nid_1\";s:3:\"not\";b:0;}}s:5:\"logic\";s:3:\"and\";s:4:\"type\";s:4:\"none\";s:8:\"settings\";N;}i:1;i:1;}','page_manager_page_execute','a:2:{i:0;s:8:\"sub_page\";i:1;i:1;}',5,3,'node/%','node/%','Add Sub Page','t','',128,'','','',10,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.inc'),('admin/build/menu','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_overview_page','a:0:{}',7,3,'','admin/build/menu','Menus','t','',6,'','Control your site\'s navigation menu, primary links and secondary links. as well as rename and reorganize menu items.','',0,'modules/menu/menu.admin.inc'),('admin/build/modules','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:14:\"system_modules\";}',7,3,'','admin/build/modules','Modules','t','',6,'','Enable or disable add-on modules for your site.','',0,'modules/system/system.admin.inc'),('admin/settings/performance','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:27:\"system_performance_settings\";}',7,3,'','admin/settings/performance','Performance','t','',6,'','Enable or disable page caching for anonymous users and set CSS and JS bandwidth optimization options.','',0,'modules/system/system.admin.inc'),('admin/user/permissions','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','drupal_get_form','a:1:{i:0;s:15:\"user_admin_perm\";}',7,3,'','admin/user/permissions','Permissions','t','',6,'','Determine access to features by selecting permissions for roles.','',0,'modules/user/user.admin.inc'),('admin/content/node-settings','','','user_access','a:1:{i:0;s:16:\"administer nodes\";}','drupal_get_form','a:1:{i:0;s:14:\"node_configure\";}',7,3,'','admin/content/node-settings','Post settings','t','',6,'','Control posting behavior, such as teaser length, requiring previews before posting, and the number of posts on the front page.','',0,'modules/node/node.admin.inc'),('admin/content/rss-publishing','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"system_rss_feeds_settings\";}',7,3,'','admin/content/rss-publishing','RSS publishing','t','',6,'','Configure the number of items per feed and whether feeds should be titles/teasers/full-text.','',0,'modules/system/system.admin.inc'),('admin/user/roles','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','drupal_get_form','a:1:{i:0;s:19:\"user_admin_new_role\";}',7,3,'','admin/user/roles','Roles','t','',6,'','List, edit, or add user roles.','',0,'modules/user/user.admin.inc'),('admin/settings/site-information','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:32:\"system_site_information_settings\";}',7,3,'','admin/settings/site-information','Site information','t','',6,'','Change basic site information, such as the site name, slogan, e-mail address, mission, front page and more.','',0,'modules/system/system.admin.inc'),('admin/settings/site-maintenance','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:32:\"system_site_maintenance_settings\";}',7,3,'','admin/settings/site-maintenance','Site maintenance','t','',6,'','Take the site off-line for maintenance or bring it back online.','',0,'modules/system/system.admin.inc'),('admin/content/taxonomy','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:1:{i:0;s:30:\"taxonomy_overview_vocabularies\";}',7,3,'','admin/content/taxonomy','Taxonomy','t','',6,'','Manage tagging, categorization, and classification of your content.','',0,'modules/taxonomy/taxonomy.admin.inc'),('admin/build/themes','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:2:{i:0;s:18:\"system_themes_form\";i:1;N;}',7,3,'','admin/build/themes','Themes','t','',6,'','Change which theme your site uses or allows users to set.','',0,'modules/system/system.admin.inc'),('admin/reports/access-denied','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_top','a:1:{i:0;s:13:\"access denied\";}',7,3,'','admin/reports/access-denied','Top \'access denied\' errors','t','',6,'','View \'access denied\' errors (403s).','',0,'modules/dblog/dblog.admin.inc'),('admin/reports/page-not-found','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_top','a:1:{i:0;s:14:\"page not found\";}',7,3,'','admin/reports/page-not-found','Top \'page not found\' errors','t','',6,'','View \'page not found\' errors (404s).','',0,'modules/dblog/dblog.admin.inc'),('admin/build/path-redirect','','','user_access','a:1:{i:0;s:20:\"administer redirects\";}','drupal_get_form','a:1:{i:0;s:29:\"path_redirect_admin_redirects\";}',7,3,'','admin/build/path-redirect','URL redirects','t','',6,'','Redirect users from one URL to another.','',0,'profiles/os_demo/modules/contrib/path_redirect/path_redirect.admin.inc'),('admin/user/settings','','','user_access','a:1:{i:0;s:16:\"administer users\";}','drupal_get_form','a:1:{i:0;s:19:\"user_admin_settings\";}',7,3,'','admin/user/settings','User settings','t','',6,'','Configure default behavior of users, including registration requirements, e-mails, and user pictures.','',0,'modules/user/user.admin.inc'),('admin/user/user','','','user_access','a:1:{i:0;s:16:\"administer users\";}','user_admin','a:1:{i:0;s:4:\"list\";}',7,3,'','admin/user/user','Users','t','',6,'','List, add, and edit users.','',0,'modules/user/user.admin.inc'),('admin/content/webform','','','user_access','a:1:{i:0;s:26:\"access all webform results\";}','webform_admin_content','a:0:{}',7,3,'','admin/content/webform','Webforms','t','',6,'','View and edit all the available webforms on your site.','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.admin.inc'),('admin/settings/wysiwyg','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:24:\"wysiwyg_profile_overview\";}',7,3,'','admin/settings/wysiwyg','Wysiwyg','t','',6,'','Configure client-side editors.','',0,'profiles/os_demo/modules/contrib/wysiwyg/wysiwyg.admin.inc'),('admin/settings/admin','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:19:\"admin_settings_form\";}',7,3,'','admin/settings/admin','Administration tools','t','',6,'','Settings for site administration tools.','',0,'profiles/os_demo/modules/contrib/admin/admin.admin.inc'),('node/add/blog','','','node_access','a:2:{i:0;s:6:\"create\";i:1;s:4:\"blog\";}','node_add','a:1:{i:0;i:2;}',7,3,'','node/add/blog','Blog post','check_plain','',6,'','','',0,'modules/node/node.pages.inc'),('node/add/event','','','node_access','a:2:{i:0;s:6:\"create\";i:1;s:5:\"event\";}','node_add','a:1:{i:0;i:2;}',7,3,'','node/add/event','Event','check_plain','',6,'','','',0,'modules/node/node.pages.inc'),('admin/build/features','','','user_access','a:1:{i:0;s:15:\"manage features\";}','drupal_get_form','a:1:{i:0;s:19:\"features_admin_form\";}',7,3,'','admin/build/features','Features','t','',6,'','Manage features.','',0,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('node/add/page','','','node_access','a:2:{i:0;s:6:\"create\";i:1;s:4:\"page\";}','node_add','a:1:{i:0;i:2;}',7,3,'','node/add/page','Page','check_plain','',6,'','A <em>page</em> is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.','',0,'modules/node/node.pages.inc'),('node/add/slide','','','node_access','a:2:{i:0;s:6:\"create\";i:1;s:5:\"slide\";}','node_add','a:1:{i:0;i:2;}',7,3,'','node/add/slide','Slide','check_plain','',6,'','An image to be used in the homepage slideshow.','',0,'modules/node/node.pages.inc'),('admin/settings/strongarm','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:20:\"strongarm_admin_form\";}',7,3,'','admin/settings/strongarm','Strongarm','t','',6,'','Manage Drupal variable settings that have been strongarmed.','',0,'profiles/os_demo/modules/contrib/strongarm/strongarm.admin.inc'),('node/add/webform','','','node_access','a:2:{i:0;s:6:\"create\";i:1;s:7:\"webform\";}','node_add','a:1:{i:0;i:2;}',7,3,'','node/add/webform','Webform','check_plain','',6,'','Create a new form or questionnaire accessible to users. Submission results and statistics are recorded and accessible to privileged users.','',0,'modules/node/node.pages.inc'),('admin/settings/webform','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:22:\"webform_admin_settings\";}',7,3,'','admin/settings/webform','Webform settings','t','',6,'','Global configuration of webform functionality.','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.admin.inc'),('admin/build/block/list','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','block_admin_display','a:0:{}',15,4,'admin/build/block','admin/build/block','List','t','',136,'','','',-10,'modules/block/block.admin.inc'),('admin/content/node/overview','','','user_access','a:1:{i:0;s:16:\"administer nodes\";}','drupal_get_form','a:1:{i:0;s:18:\"node_admin_content\";}',15,4,'admin/content/node','admin/content/node','List','t','',136,'','','',-10,'modules/node/node.admin.inc'),('admin/content/types/list','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','content_types_overview','a:0:{}',15,4,'admin/content/types','admin/content/types','List','t','',136,'','','',-10,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/build/path/list','','','user_access','a:1:{i:0;s:22:\"administer url aliases\";}','path_admin_overview','a:0:{}',15,4,'admin/build/path','admin/build/path','List','t','',136,'','','',-10,'modules/path/path.admin.inc'),('admin/build/path-redirect/list','','','user_access','a:1:{i:0;s:20:\"administer redirects\";}','drupal_get_form','a:1:{i:0;s:29:\"path_redirect_admin_redirects\";}',15,4,'admin/build/path-redirect','admin/build/path-redirect','List','t','',136,'','','',-10,'profiles/os_demo/modules/contrib/path_redirect/path_redirect.admin.inc'),('admin/content/taxonomy/list','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:1:{i:0;s:30:\"taxonomy_overview_vocabularies\";}',15,4,'admin/content/taxonomy','admin/content/taxonomy','List','t','',136,'','','',-10,'modules/taxonomy/taxonomy.admin.inc'),('admin/settings/filters/list','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:21:\"filter_admin_overview\";}',15,4,'admin/settings/filters','admin/settings/filters','List','t','',136,'','','',0,'modules/filter/filter.admin.inc'),('admin/user/user/list','','','user_access','a:1:{i:0;s:16:\"administer users\";}','user_admin','a:1:{i:0;s:4:\"list\";}',15,4,'admin/user/user','admin/user/user','List','t','',136,'','','',-10,'modules/user/user.admin.inc'),('admin/build/modules/list','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:14:\"system_modules\";}',15,4,'admin/build/modules','admin/build/modules','List','t','',136,'','','',0,'modules/system/system.admin.inc'),('admin/user/rules/list','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','user_admin_access','a:0:{}',15,4,'admin/user/rules','admin/user/rules','List','t','',136,'','','',-10,'modules/user/user.admin.inc'),('admin/settings/wysiwyg/profile','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:24:\"wysiwyg_profile_overview\";}',15,4,'admin/settings/wysiwyg','admin/settings/wysiwyg','Profiles','t','',136,'','','',0,'profiles/os_demo/modules/contrib/wysiwyg/wysiwyg.admin.inc'),('admin/content/comment/new','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_admin','a:0:{}',15,4,'admin/content/comment','admin/content/comment','Published comments','t','',136,'','','',-10,'modules/comment/comment.admin.inc'),('user/%/edit/account','a:1:{i:1;a:1:{s:18:\"user_category_load\";a:2:{i:0;s:4:\"%map\";i:1;s:6:\"%index\";}}}','','user_edit_access','a:1:{i:0;i:1;}','user_edit','a:1:{i:0;i:1;}',11,4,'user/%/edit','user/%','Account','t','',136,'','','',0,'modules/user/user.pages.inc'),('admin/build/themes/select','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:2:{i:0;s:18:\"system_themes_form\";i:1;N;}',15,4,'admin/build/themes','admin/build/themes','List','t','',136,'','Select the default theme.','',-1,'modules/system/system.admin.inc'),('admin/build/menu/list','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_overview_page','a:0:{}',15,4,'admin/build/menu','admin/build/menu','List menus','t','',136,'','','',-10,'modules/menu/menu.admin.inc'),('admin/build/themes/settings','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:21:\"system_theme_settings\";}',15,4,'admin/build/themes','admin/build/themes','Configure','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/content/nodequeue/list','','','_nodequeue_access_admin_or_manipulate','a:0:{}','nodequeue_view_queues','a:0:{}',15,4,'admin/content/nodequeue','admin/content/nodequeue','List','t','',136,'','','',-1,''),('admin/settings/actions/manage','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','system_actions_manage','a:0:{}',15,4,'admin/settings/actions','admin/settings/actions','Manage actions','t','',136,'','Manage the actions defined for your site.','',-2,''),('admin/build/modules/uninstall','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:24:\"system_modules_uninstall\";}',15,4,'admin/build/modules','admin/build/modules','Uninstall','t','',128,'','','',0,'modules/system/system.admin.inc'),('ctools/context/ajax/add','','','user_access','a:1:{i:0;s:14:\"access content\";}','ctools_context_ajax_item_add','a:0:{}',15,4,'','ctools/context/ajax/add','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/includes/context-admin.inc'),('ctools/context/ajax/delete','','','user_access','a:1:{i:0;s:14:\"access content\";}','ctools_context_ajax_item_delete','a:0:{}',15,4,'','ctools/context/ajax/delete','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/includes/context-admin.inc'),('ctools/context/ajax/configure','','','user_access','a:1:{i:0;s:14:\"access content\";}','ctools_context_ajax_item_edit','a:0:{}',15,4,'','ctools/context/ajax/configure','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/includes/context-admin.inc'),('admin/build/path/add','','','user_access','a:1:{i:0;s:22:\"administer url aliases\";}','path_admin_edit','a:0:{}',15,4,'admin/build/path','admin/build/path','Add alias','t','',128,'','','',0,'modules/path/path.admin.inc'),('admin/settings/filters/add','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_format_page','a:0:{}',15,4,'admin/settings/filters','admin/settings/filters','Add input format','t','',128,'','','',1,'modules/filter/filter.admin.inc'),('admin/user/rules/add','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','user_admin_access_add','a:0:{}',15,4,'admin/user/rules','admin/user/rules','Add rule','t','',128,'','','',0,'modules/user/user.admin.inc'),('admin/user/user/create','','','user_access','a:1:{i:0;s:16:\"administer users\";}','user_admin','a:1:{i:0;s:6:\"create\";}',15,4,'admin/user/user','admin/user/user','Add user','t','',128,'','','',0,'modules/user/user.admin.inc'),('admin/content/comment/approval','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_admin','a:1:{i:0;s:8:\"approval\";}',15,4,'admin/content/comment','admin/content/comment','Approval queue','t','',128,'','','',0,'modules/comment/comment.admin.inc'),('admin/user/rules/check','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','user_admin_access_check','a:0:{}',15,4,'admin/user/rules','admin/user/rules','Check rules','t','',128,'','','',0,'modules/user/user.admin.inc'),('admin/content/types/fields','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','content_fields_list','a:0:{}',15,4,'admin/content/types','admin/content/types','Fields','t','',128,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/build/pages/list','','','user_access','a:1:{i:0;s:16:\"use page manager\";}','page_manager_list_page','a:0:{}',15,4,'admin/build/pages','admin/build/pages','List','t','',136,'','','',-10,'profiles/os_demo/modules/contrib/ctools/page_manager/page_manager.admin.inc'),('admin/reports/updates/list','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','update_status','a:0:{}',15,4,'admin/reports/updates','admin/reports/updates','List','t','',136,'','','',0,'modules/update/update.report.inc'),('admin/settings/actions/orphan','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','system_actions_remove_orphans','a:0:{}',15,4,'','admin/settings/actions/orphan','Remove orphans','t','',4,'','','',0,''),('admin/content/nodequeue/settings','','','user_access','a:1:{i:0;s:20:\"administer nodequeue\";}','drupal_get_form','a:1:{i:0;s:24:\"nodequeue_admin_settings\";}',15,4,'admin/content/nodequeue','admin/content/nodequeue','Settings','t','',128,'','','',0,''),('admin/build/block/add','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','drupal_get_form','a:1:{i:0;s:20:\"block_add_block_form\";}',15,4,'admin/build/block','admin/build/block','Add block','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/content/types/add','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:1:{i:0;s:14:\"node_type_form\";}',15,4,'admin/content/types','admin/content/types','Add content type','t','',128,'','','',0,'modules/node/content_types.inc'),('admin/build/menu/add','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:14:\"menu_edit_menu\";i:1;s:3:\"add\";}',15,4,'admin/build/menu','admin/build/menu','Add menu','t','',128,'','','',0,'modules/menu/menu.admin.inc'),('admin/build/path/pathauto','','','user_access','a:1:{i:0;s:19:\"administer pathauto\";}','drupal_get_form','a:1:{i:0;s:23:\"pathauto_admin_settings\";}',15,4,'admin/build/path','admin/build/path','Automated alias settings','t','',128,'','','',10,'profiles/os_demo/modules/contrib/pathauto/pathauto.admin.inc'),('admin/settings/clean-urls/check','','','1','a:0:{}','drupal_json','a:1:{i:0;a:1:{s:6:\"status\";b:1;}}',15,4,'','admin/settings/clean-urls/check','Clean URL check','t','',4,'','','',0,''),('admin/settings/actions/configure','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','drupal_get_form','a:1:{i:0;s:24:\"system_actions_configure\";}',15,4,'','admin/settings/actions/configure','Configure an advanced action','t','',4,'','','',0,''),('admin/settings/date-time/lookup','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_date_time_lookup','a:0:{}',15,4,'','admin/settings/date-time/lookup','Date and time lookup','t','',4,'','','',0,'modules/system/system.admin.inc'),('admin/build/path/delete_bulk','','','user_access','a:1:{i:0;s:22:\"administer url aliases\";}','drupal_get_form','a:1:{i:0;s:21:\"pathauto_admin_delete\";}',15,4,'admin/build/path','admin/build/path','Delete aliases','t','',128,'','','',30,'profiles/os_demo/modules/contrib/pathauto/pathauto.admin.inc'),('node/%/devel/load','a:1:{i:1;s:9:\"node_load\";}','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_load_object','a:2:{i:0;i:1;i:1;s:4:\"node\";}',11,4,'node/%/devel','node/%','Dev load','t','',136,'','','',0,''),('user/%/devel/load','a:1:{i:1;s:9:\"user_load\";}','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_load_object','a:2:{i:0;i:1;i:1;s:4:\"user\";}',11,4,'user/%/devel','user/%','Dev load','t','',136,'','','',0,''),('node/%/devel/render','a:1:{i:1;s:9:\"node_load\";}','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_render_object','a:2:{i:0;s:4:\"node\";i:1;i:1;}',11,4,'node/%/devel','node/%','Dev render','t','',128,'','','',10,''),('user/%/devel/render','a:1:{i:1;s:9:\"user_load\";}','','user_access','a:1:{i:0;s:24:\"access devel information\";}','devel_render_object','a:2:{i:0;s:4:\"user\";i:1;i:1;}',11,4,'user/%/devel','user/%','Dev render','t','',128,'','','',10,''),('admin/build/path/edit','','','user_access','a:1:{i:0;s:22:\"administer url aliases\";}','path_admin_edit','a:0:{}',15,4,'','admin/build/path/edit','Edit alias','t','',4,'','','',0,'modules/path/path.admin.inc'),('admin/user/roles/edit','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','drupal_get_form','a:1:{i:0;s:15:\"user_admin_role\";}',15,4,'','admin/user/roles/edit','Edit role','t','',4,'','','',0,'modules/user/user.admin.inc'),('admin/user/rules/edit','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','user_admin_access_edit','a:0:{}',15,4,'','admin/user/rules/edit','Edit rule','t','',4,'','','',0,'modules/user/user.admin.inc'),('admin/reports/updates/check','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','update_manual_status','a:0:{}',15,4,'','admin/reports/updates/check','Manual update check','t','',4,'','','',0,'modules/update/update.fetch.inc'),('admin/reports/status/php','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_php','a:0:{}',15,4,'','admin/reports/status/php','PHP','t','',4,'','','',0,'modules/system/system.admin.inc'),('admin/content/node-settings/rebuild','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','drupal_get_form','a:1:{i:0;s:30:\"node_configure_rebuild_confirm\";}',15,4,'','admin/content/node-settings/rebuild','Rebuild permissions','t','',4,'','','',0,'modules/node/node.admin.inc'),('admin/reports/status/run-cron','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_run_cron','a:0:{}',15,4,'','admin/reports/status/run-cron','Run cron','t','',4,'','','',0,'modules/system/system.admin.inc'),('admin/reports/status/sql','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_sql','a:0:{}',15,4,'','admin/reports/status/sql','SQL','t','',4,'','','',0,'modules/system/system.admin.inc'),('admin/build/menu/settings','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:1:{i:0;s:14:\"menu_configure\";}',15,4,'admin/build/menu','admin/build/menu','Settings','t','',128,'','','',5,'modules/menu/menu.admin.inc'),('admin/reports/updates/settings','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:15:\"update_settings\";}',15,4,'admin/reports/updates','admin/reports/updates','Settings','t','',128,'','','',0,'modules/update/update.settings.inc'),('devel/variable/edit/%','a:1:{i:3;N;}','','user_access','a:1:{i:0;s:24:\"access devel information\";}','drupal_get_form','a:2:{i:0;s:19:\"devel_variable_edit\";i:1;i:3;}',14,4,'','devel/variable/edit/%','Variable editor','t','',4,'','','',0,''),('admin/build/pages/add','','','user_access','a:1:{i:0;s:23:\"administer page manager\";}','page_manager_page_add_subtask','a:0:{}',15,4,'admin/build/pages','admin/build/pages','Add custom page','t','',128,'','','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.admin.inc'),('admin/build/path-redirect/add','','','user_access','a:1:{i:0;s:20:\"administer redirects\";}','drupal_get_form','a:1:{i:0;s:23:\"path_redirect_edit_form\";}',15,4,'admin/build/path-redirect','admin/build/path-redirect','Add redirect','t','',128,'','Add a new URL redirect.','',0,'profiles/os_demo/modules/contrib/path_redirect/path_redirect.admin.inc'),('node/%/webform-results/analysis','a:1:{i:1;s:17:\"webform_menu_load\";}','','webform_results_access','a:1:{i:0;i:1;}','webform_results_analysis','a:1:{i:0;i:1;}',11,4,'node/%/webform-results','node/%','Analysis','t','',128,'','','',5,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('admin/content/node-type/blog','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:9:\"Blog post\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:4:\"blog\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:4:\"blog\";s:6:\"is_new\";b:1;}}',15,4,'','admin/content/node-type/blog','Blog post','t','',4,'','','',0,'modules/node/content_types.inc'),('node/%/webform-results/clear','a:1:{i:1;s:17:\"webform_menu_load\";}','','webform_results_clear_access','a:1:{i:0;i:1;}','drupal_get_form','a:2:{i:0;s:26:\"webform_results_clear_form\";i:1;i:1;}',11,4,'node/%/webform-results','node/%','Clear','t','',128,'','','',8,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('admin/build/block/configure','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','drupal_get_form','a:1:{i:0;s:21:\"block_admin_configure\";}',15,4,'','admin/build/block/configure','Configure block','t','',4,'','','',0,'modules/block/block.admin.inc'),('admin/settings/date-time/configure','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"system_date_time_settings\";}',15,4,'admin/settings/date-time','admin/settings/date-time','Date and time','t','',136,'','Settings for how Drupal displays date and time, as well as the system\'s default timezone.','',0,'modules/system/system.admin.inc'),('admin/settings/filters/defaults','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:34:\"better_formats_defaults_admin_form\";}',15,4,'admin/settings/filters','admin/settings/filters','Defaults','t','',128,'','Manage input formats','',2,'profiles/os_demo/modules/contrib/better_formats/better_formats_defaults.admin.inc'),('admin/build/path/delete','','','user_access','a:1:{i:0;s:22:\"administer url aliases\";}','drupal_get_form','a:1:{i:0;s:25:\"path_admin_delete_confirm\";}',15,4,'','admin/build/path/delete','Delete alias','t','',4,'','','',0,'modules/path/path.admin.inc'),('admin/build/block/delete','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','drupal_get_form','a:1:{i:0;s:16:\"block_box_delete\";}',15,4,'','admin/build/block/delete','Delete block','t','',4,'','','',0,'modules/block/block.admin.inc'),('admin/settings/filters/delete','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:19:\"filter_admin_delete\";}',15,4,'','admin/settings/filters/delete','Delete input format','t','',4,'','','',0,'modules/filter/filter.admin.inc'),('admin/user/rules/delete','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','drupal_get_form','a:1:{i:0;s:32:\"user_admin_access_delete_confirm\";}',15,4,'','admin/user/rules/delete','Delete rule','t','',4,'','','',0,'modules/user/user.admin.inc'),('admin/reports/event/%','a:1:{i:3;N;}','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_event','a:1:{i:0;i:3;}',14,4,'','admin/reports/event/%','Details','t','',4,'','','',0,'modules/dblog/dblog.admin.inc'),('node/%/webform-results/download','a:1:{i:1;s:17:\"webform_menu_load\";}','','webform_results_access','a:1:{i:0;i:1;}','drupal_get_form','a:2:{i:0;s:29:\"webform_results_download_form\";i:1;i:1;}',11,4,'node/%/webform-results','node/%','Download','t','',128,'','','',7,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('admin/content/nodequeue/%','a:1:{i:3;s:14:\"nodequeue_load\";}','','nodequeue_queue_access','a:1:{i:0;i:3;}','nodequeue_admin_view','a:1:{i:0;i:3;}',14,4,'','admin/content/nodequeue/%','','t','',4,'','','',0,''),('node/%/webform/emails','a:1:{i:1;s:17:\"webform_menu_load\";}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','drupal_get_form','a:2:{i:0;s:19:\"webform_emails_form\";i:1;i:1;}',11,4,'node/%/webform','node/%','E-mails','t','',128,'','','',1,'profiles/os_demo/modules/contrib/webform/includes/webform.emails.inc'),('admin/content/node-type/event','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:5:\"Event\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:7:\"Details\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:5:\"event\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:5:\"event\";s:6:\"is_new\";b:1;}}',15,4,'','admin/content/node-type/event','Event','t','',4,'','','',0,'modules/node/content_types.inc'),('node/%/webform/components','a:1:{i:1;s:17:\"webform_menu_load\";}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','webform_components_page','a:1:{i:0;i:1;}',11,4,'node/%/webform','node/%','Form components','t','',136,'','','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.components.inc'),('node/%/webform/configure','a:1:{i:1;s:17:\"webform_menu_load\";}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','drupal_get_form','a:2:{i:0;s:22:\"webform_configure_form\";i:1;i:1;}',11,4,'node/%/webform','node/%','Form settings','t','',128,'','','',2,'profiles/os_demo/modules/contrib/webform/includes/webform.pages.inc'),('admin/settings/date-time/formats','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:26:\"date_api_date_formats_form\";}',15,4,'admin/settings/date-time','admin/settings/date-time','Formats','t','',128,'','Allow users to configure date formats','',1,'profiles/os_demo/modules/contrib/date/date_api.admin.inc'),('admin/build/pages/import','','','ctools_access_multiperm','a:2:{i:0;s:23:\"administer page manager\";i:1;s:28:\"use PHP for block visibility\";}','drupal_get_form','a:2:{i:0;s:32:\"page_manager_page_import_subtask\";i:1;s:4:\"page\";}',15,4,'admin/build/pages','admin/build/pages','Import page','t','',128,'','','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.admin.inc'),('admin/build/pages/argument','','','user_access','a:1:{i:0;s:23:\"administer page manager\";}','page_manager_page_subtask_argument_ajax','a:0:{}',15,4,'','admin/build/pages/argument','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/plugins/tasks/page.admin.inc'),('admin/content/taxonomy/%','a:1:{i:3;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:2:{i:0;s:23:\"taxonomy_overview_terms\";i:1;i:3;}',14,4,'','admin/content/taxonomy/%','List terms','t','',4,'','','',0,'modules/taxonomy/taxonomy.admin.inc'),('admin/content/node-type/page','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:4:\"Page\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:258:\"A <em>page</em> is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:4:\"page\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:4:\"page\";s:6:\"is_new\";b:1;}}',15,4,'','admin/content/node-type/page','Page','t','',4,'','','',0,'modules/node/content_types.inc'),('admin/build/path-redirect/settings','','','user_access','a:1:{i:0;s:20:\"administer redirects\";}','drupal_get_form','a:1:{i:0;s:27:\"path_redirect_settings_form\";}',15,4,'admin/build/path-redirect','admin/build/path-redirect','Settings','t','',128,'','Configure behavior for URL redirects.','',10,'profiles/os_demo/modules/contrib/path_redirect/path_redirect.admin.inc'),('admin/settings/filters/settings','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:34:\"better_formats_settings_admin_form\";}',15,4,'admin/settings/filters','admin/settings/filters','Settings','t','',128,'','Manage input formats','',3,'profiles/os_demo/modules/contrib/better_formats/better_formats_settings.admin.inc'),('admin/content/node-type/slide','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:5:\"Slide\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:46:\"An image to be used in the homepage slideshow.\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:8:\"Headline\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:11:\"Description\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:5:\"slide\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:5:\"slide\";s:6:\"is_new\";b:1;}}',15,4,'','admin/content/node-type/slide','Slide','t','',4,'','','',0,'modules/node/content_types.inc'),('webform/ajax/options/%','a:1:{i:3;a:1:{s:17:\"webform_menu_load\";a:1:{i:0;i:3;}}}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:3;}','webform_select_options_ajax','a:0:{}',14,4,'','webform/ajax/options/%','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/webform/components/select.inc'),('node/%/webform-results/submissions','a:1:{i:1;s:17:\"webform_menu_load\";}','','webform_results_access','a:1:{i:0;i:1;}','webform_results_submissions','a:3:{i:0;i:1;i:1;b:0;i:2;s:2:\"50\";}',11,4,'node/%/webform-results','node/%','Submissions','t','',136,'','','',4,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('node/%/webform-results/table','a:1:{i:1;s:17:\"webform_menu_load\";}','','webform_results_access','a:1:{i:0;i:1;}','webform_results_table','a:2:{i:0;i:1;i:1;s:2:\"50\";}',11,4,'node/%/webform-results','node/%','Table','t','',128,'','','',6,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('admin/content/node-type/webform','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:7:\"webform\";s:4:\"name\";s:7:\"Webform\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:138:\"Create a new form or questionnaire accessible to users. Submission results and statistics are recorded and accessible to privileged users.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:7:\"webform\";}}',15,4,'','admin/content/node-type/webform','Webform','t','',4,'','','',0,'modules/node/content_types.inc'),('admin/build/features/create','','','user_access','a:1:{i:0;s:19:\"administer features\";}','drupal_get_form','a:1:{i:0;s:20:\"features_export_form\";}',15,4,'admin/build/features','admin/build/features','Create feature','t','',128,'','Create a new feature.','',10,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('admin/settings/logging/dblog','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:20:\"dblog_admin_settings\";}',15,4,'','admin/settings/logging/dblog','Database logging','t','',6,'','Settings for logging to the Drupal database logs. This is the most common method for small to medium sites on shared hosting. The logs are viewable from the admin pages.','',0,'modules/dblog/dblog.admin.inc'),('admin/build/features/manage','','','user_access','a:1:{i:0;s:15:\"manage features\";}','drupal_get_form','a:1:{i:0;s:19:\"features_admin_form\";}',15,4,'admin/build/features','admin/build/features','Manage','t','',136,'','Enable and disable features.','',0,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('admin/settings/admin/rebuild','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:22:\"admin_settings_rebuild\";}',15,4,'admin/settings/admin','admin/settings/admin','Rebuild','t','',128,'','Wipe and rebuild the administrative menu.','',10,'profiles/os_demo/modules/contrib/admin/admin.admin.inc'),('admin/settings/admin/settings','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:19:\"admin_settings_form\";}',15,4,'admin/settings/admin','admin/settings/admin','Settings','t','',136,'','Settings for site administration tools.','',0,'profiles/os_demo/modules/contrib/admin/admin.admin.inc'),('admin/settings/filters/%','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_format_page','a:1:{i:0;i:3;}',14,4,'','admin/settings/filters/%','','filter_admin_format_title','a:1:{i:0;i:3;}',4,'','','',0,'modules/filter/filter.admin.inc'),('admin/settings/admin/theme','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:27:\"system_admin_theme_settings\";}',15,4,'admin/settings/admin','admin/settings/admin','Administration theme','t','',128,'system_admin_theme_settings','Settings for how your administrative pages should look.','left',10,'modules/system/system.admin.inc'),('admin/build/features/cleanup','','','user_access','a:1:{i:0;s:15:\"manage features\";}','drupal_get_form','a:2:{i:0;s:21:\"features_cleanup_form\";i:1;i:4;}',15,4,'','admin/build/features/cleanup','Cleanup','t','',4,'','Detect and disable any orphaned feature dependencies.','',1,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('admin/build/menu-customize/%','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:18:\"menu_overview_form\";i:1;i:3;}',14,4,'','admin/build/menu-customize/%','Customize menu','menu_overview_title','a:1:{i:0;i:3;}',4,'','','',0,'modules/menu/menu.admin.inc'),('node/%/submission/%','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:1:{i:0;i:1;}}i:3;a:1:{s:28:\"webform_menu_submission_load\";a:1:{i:0;i:1;}}}','','webform_submission_access','a:3:{i:0;i:1;i:1;i:3;i:2;s:4:\"view\";}','webform_submission_page','a:3:{i:0;i:1;i:1;i:3;i:2;s:4:\"html\";}',10,4,'','node/%/submission/%','Webform submission','webform_submission_title','a:2:{i:0;i:1;i:1;i:3;}',4,'','','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.submissions.inc'),('admin/build/features/%','a:1:{i:3;s:12:\"feature_load\";}','','user_access','a:1:{i:0;s:19:\"administer features\";}','drupal_get_form','a:2:{i:0;s:25:\"features_admin_components\";i:1;i:3;}',14,4,'','admin/build/features/%','','features_get_feature_title','a:1:{i:0;i:3;}',4,'','Display components of a feature.','',0,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('admin/content/node-type/blog/edit','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:9:\"Blog post\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:4:\"blog\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:4:\"blog\";s:6:\"is_new\";b:1;}}',31,5,'admin/content/node-type/blog','admin/content/node-type/blog','Edit','t','',136,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/event/edit','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:5:\"Event\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:7:\"Details\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:5:\"event\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:5:\"event\";s:6:\"is_new\";b:1;}}',31,5,'admin/content/node-type/event','admin/content/node-type/event','Edit','t','',136,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/page/edit','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:4:\"Page\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:258:\"A <em>page</em> is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:4:\"page\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:4:\"page\";s:6:\"is_new\";b:1;}}',31,5,'admin/content/node-type/page','admin/content/node-type/page','Edit','t','',136,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/slide/edit','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:5:\"Slide\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:46:\"An image to be used in the homepage slideshow.\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:8:\"Headline\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:11:\"Description\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:5:\"slide\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:5:\"slide\";s:6:\"is_new\";b:1;}}',31,5,'admin/content/node-type/slide','admin/content/node-type/slide','Edit','t','',136,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/webform/edit','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:7:\"webform\";s:4:\"name\";s:7:\"Webform\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:138:\"Create a new form or questionnaire accessible to users. Submission results and statistics are recorded and accessible to privileged users.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:7:\"webform\";}}',31,5,'admin/content/node-type/webform','admin/content/node-type/webform','Edit','t','',136,'','','',0,'modules/node/content_types.inc'),('admin/build/themes/settings/global','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:21:\"system_theme_settings\";}',31,5,'admin/build/themes/settings','admin/build/themes','Global settings','t','',136,'','','',-1,'modules/system/system.admin.inc'),('admin/content/taxonomy/%/list','a:1:{i:3;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:2:{i:0;s:23:\"taxonomy_overview_terms\";i:1;i:3;}',29,5,'admin/content/taxonomy/%','admin/content/taxonomy/%','List','t','',136,'','','',-10,'modules/taxonomy/taxonomy.admin.inc'),('admin/settings/filters/%/edit','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_format_page','a:1:{i:0;i:3;}',29,5,'admin/settings/filters/%','admin/settings/filters/%','Edit','t','',136,'','','',0,'modules/filter/filter.admin.inc'),('admin/build/menu-customize/%/list','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:18:\"menu_overview_form\";i:1;i:3;}',29,5,'admin/build/menu-customize/%','admin/build/menu-customize/%','List items','t','',136,'','','',-10,'modules/menu/menu.admin.inc'),('admin/build/modules/list/confirm','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:14:\"system_modules\";}',31,5,'','admin/build/modules/list/confirm','List','t','',4,'','','',0,'modules/system/system.admin.inc'),('admin/build/modules/uninstall/confirm','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:24:\"system_modules_uninstall\";}',31,5,'','admin/build/modules/uninstall/confirm','Uninstall','t','',4,'','','',0,'modules/system/system.admin.inc'),('ctools/context/ajax/access/add','','','user_access','a:1:{i:0;s:14:\"access content\";}','ctools_access_ajax_add','a:0:{}',31,5,'','ctools/context/ajax/access/add','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/includes/context-access-admin.inc'),('admin/build/themes/settings/chameleon','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":11:{s:8:\"filename\";s:31:\"themes/chameleon/chameleon.info\";s:4:\"name\";s:9:\"chameleon\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:32:\"themes/chameleon/chameleon.theme\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:12:{s:4:\"name\";s:9:\"Chameleon\";s:11:\"description\";s:42:\"Minimalist tabled theme with light colors.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:8:\"features\";a:4:{i:0;s:4:\"logo\";i:1;s:7:\"favicon\";i:2;s:4:\"name\";i:3;s:6:\"slogan\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"scripts\";a:1:{s:9:\"script.js\";s:26:\"themes/chameleon/script.js\";}s:10:\"screenshot\";s:31:\"themes/chameleon/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:9:\"chameleon\";}',31,5,'admin/build/themes/settings','admin/build/themes','Chameleon','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/build/themes/settings/cube','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:44:\"profiles/os_demo/themes/rubik/cube/cube.info\";s:4:\"name\";s:4:\"cube\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:16:{s:4:\"name\";s:4:\"Cube\";s:11:\"description\";s:44:\"Spaces-aware front-end theme based on Rubik.\";s:10:\"base theme\";s:5:\"rubik\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:1:{s:9:\"style.css\";s:44:\"profiles/os_demo/themes/rubik/cube/style.css\";}}s:7:\"regions\";a:4:{s:6:\"header\";s:6:\"Header\";s:7:\"content\";s:7:\"Content\";s:4:\"left\";s:4:\"Left\";s:5:\"right\";s:5:\"Right\";}s:9:\"designkit\";a:2:{s:5:\"color\";a:1:{s:10:\"background\";s:7:\"#0088cc\";}s:4:\"logo\";a:2:{s:4:\"logo\";s:23:\"imagecache_scale:200x50\";s:5:\"print\";s:24:\"imagecache_scale:600x150\";}}s:7:\"layouts\";a:5:{s:7:\"default\";a:3:{s:4:\"name\";s:7:\"Default\";s:11:\"description\";s:23:\"Simple one column page.\";s:8:\"template\";s:4:\"page\";}s:7:\"sidebar\";a:5:{s:4:\"name\";s:7:\"Sidebar\";s:11:\"description\";s:26:\"Main content with sidebar.\";s:10:\"stylesheet\";s:18:\"layout-sidebar.css\";s:8:\"template\";s:14:\"layout-sidebar\";s:7:\"regions\";a:2:{i:0;s:7:\"content\";i:1;s:5:\"right\";}}s:5:\"split\";a:5:{s:4:\"name\";s:5:\"Split\";s:11:\"description\";s:12:\"50/50 split.\";s:10:\"stylesheet\";s:16:\"layout-split.css\";s:8:\"template\";s:14:\"layout-sidebar\";s:7:\"regions\";a:2:{i:0;s:7:\"content\";i:1;s:5:\"right\";}}s:7:\"columns\";a:5:{s:4:\"name\";s:7:\"Columns\";s:11:\"description\";s:20:\"Three column layout.\";s:10:\"stylesheet\";s:18:\"layout-columns.css\";s:8:\"template\";s:14:\"layout-columns\";s:7:\"regions\";a:4:{i:0;s:6:\"header\";i:1;s:7:\"content\";i:2;s:4:\"left\";i:3;s:5:\"right\";}}s:6:\"offset\";a:5:{s:4:\"name\";s:15:\"Offset sidebars\";s:11:\"description\";s:38:\"Main content with two offset sidebars.\";s:10:\"stylesheet\";s:17:\"layout-offset.css\";s:8:\"template\";s:13:\"layout-offset\";s:7:\"regions\";a:4:{i:0;s:6:\"header\";i:1;s:7:\"content\";i:2;s:4:\"left\";i:3;s:5:\"right\";}}}s:7:\"version\";s:13:\"6.x-3.0-beta2\";s:7:\"project\";s:5:\"rubik\";s:9:\"datestamp\";s:10:\"1285709466\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:44:\"profiles/os_demo/themes/rubik/cube/script.js\";}s:10:\"screenshot\";s:49:\"profiles/os_demo/themes/rubik/cube/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:1:{s:9:\"style.css\";s:44:\"profiles/os_demo/themes/rubik/cube/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:5:\"rubik\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:4:\"cube\";}',31,5,'admin/build/themes/settings','admin/build/themes','Cube','t','',128,'','','',0,'modules/system/system.admin.inc'),('ctools/context/ajax/access/delete','','','user_access','a:1:{i:0;s:14:\"access content\";}','ctools_access_ajax_delete','a:0:{}',31,5,'','ctools/context/ajax/access/delete','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/includes/context-access-admin.inc'),('admin/build/themes/settings/bluemarine','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/bluemarine/bluemarine.info\";s:4:\"name\";s:10:\"bluemarine\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:10:\"Bluemarine\";s:11:\"description\";s:66:\"Table-based multi-column theme with a marine and ash color scheme.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/bluemarine/script.js\";}s:10:\"screenshot\";s:32:\"themes/bluemarine/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:10:\"bluemarine\";}',31,5,'admin/build/themes/settings','admin/build/themes','Bluemarine','t','',128,'','','',0,'modules/system/system.admin.inc'),('ctools/context/ajax/access/configure','','','user_access','a:1:{i:0;s:14:\"access content\";}','ctools_access_ajax_edit','a:0:{}',31,5,'','ctools/context/ajax/access/configure','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/includes/context-access-admin.inc'),('admin/settings/date-time/formats/lookup','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','date_api_date_time_lookup','a:0:{}',31,5,'','admin/settings/date-time/formats/lookup','Date and time lookup','t','',4,'','','',0,''),('admin/build/themes/settings/doune','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":15:{s:8:\"filename\";s:40:\"profiles/os_demo/themes/doune/doune.info\";s:4:\"name\";s:5:\"doune\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:14:{s:4:\"name\";s:5:\"Doune\";s:11:\"description\";s:24:\"OpenSourcery base theme.\";s:10:\"screenshot\";s:44:\"profiles/os_demo/themes/doune/screenshot.png\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:3:\"zen\";s:7:\"version\";s:7:\"6.x-0.2\";s:11:\"stylesheets\";a:3:{s:3:\"all\";a:37:{s:9:\"admin.css\";s:39:\"profiles/os_demo/themes/doune/admin.css\";s:9:\"block.css\";s:39:\"profiles/os_demo/themes/doune/block.css\";s:8:\"book.css\";s:38:\"profiles/os_demo/themes/doune/book.css\";s:11:\"comment.css\";s:41:\"profiles/os_demo/themes/doune/comment.css\";s:9:\"dblog.css\";s:39:\"profiles/os_demo/themes/doune/dblog.css\";s:12:\"defaults.css\";s:42:\"profiles/os_demo/themes/doune/defaults.css\";s:9:\"forum.css\";s:39:\"profiles/os_demo/themes/doune/forum.css\";s:8:\"help.css\";s:38:\"profiles/os_demo/themes/doune/help.css\";s:15:\"maintenance.css\";s:45:\"profiles/os_demo/themes/doune/maintenance.css\";s:8:\"node.css\";s:38:\"profiles/os_demo/themes/doune/node.css\";s:10:\"openid.css\";s:40:\"profiles/os_demo/themes/doune/openid.css\";s:8:\"poll.css\";s:38:\"profiles/os_demo/themes/doune/poll.css\";s:11:\"profile.css\";s:41:\"profiles/os_demo/themes/doune/profile.css\";s:10:\"search.css\";s:40:\"profiles/os_demo/themes/doune/search.css\";s:10:\"system.css\";s:40:\"profiles/os_demo/themes/doune/system.css\";s:16:\"system-menus.css\";s:46:\"profiles/os_demo/themes/doune/system-menus.css\";s:12:\"taxonomy.css\";s:42:\"profiles/os_demo/themes/doune/taxonomy.css\";s:11:\"tracker.css\";s:41:\"profiles/os_demo/themes/doune/tracker.css\";s:10:\"update.css\";s:40:\"profiles/os_demo/themes/doune/update.css\";s:8:\"user.css\";s:38:\"profiles/os_demo/themes/doune/user.css\";s:18:\"css/html-reset.css\";s:48:\"profiles/os_demo/themes/doune/css/html-reset.css\";s:18:\"css/wireframes.css\";s:48:\"profiles/os_demo/themes/doune/css/wireframes.css\";s:20:\"css/layout-fixed.css\";s:50:\"profiles/os_demo/themes/doune/css/layout-fixed.css\";s:24:\"css/page-backgrounds.css\";s:54:\"profiles/os_demo/themes/doune/css/page-backgrounds.css\";s:12:\"css/tabs.css\";s:42:\"profiles/os_demo/themes/doune/css/tabs.css\";s:16:\"css/messages.css\";s:46:\"profiles/os_demo/themes/doune/css/messages.css\";s:13:\"css/pages.css\";s:43:\"profiles/os_demo/themes/doune/css/pages.css\";s:21:\"css/block-editing.css\";s:51:\"profiles/os_demo/themes/doune/css/block-editing.css\";s:14:\"css/blocks.css\";s:44:\"profiles/os_demo/themes/doune/css/blocks.css\";s:18:\"css/navigation.css\";s:48:\"profiles/os_demo/themes/doune/css/navigation.css\";s:21:\"css/panels-styles.css\";s:51:\"profiles/os_demo/themes/doune/css/panels-styles.css\";s:20:\"css/views-styles.css\";s:50:\"profiles/os_demo/themes/doune/css/views-styles.css\";s:13:\"css/nodes.css\";s:43:\"profiles/os_demo/themes/doune/css/nodes.css\";s:16:\"css/comments.css\";s:46:\"profiles/os_demo/themes/doune/css/comments.css\";s:13:\"css/forms.css\";s:43:\"profiles/os_demo/themes/doune/css/forms.css\";s:14:\"css/fields.css\";s:44:\"profiles/os_demo/themes/doune/css/fields.css\";s:12:\"css/type.css\";s:42:\"profiles/os_demo/themes/doune/css/type.css\";}s:6:\"screen\";a:1:{s:14:\"css/drupal.css\";s:44:\"profiles/os_demo/themes/doune/css/drupal.css\";}s:5:\"print\";a:1:{s:13:\"css/print.css\";s:43:\"profiles/os_demo/themes/doune/css/print.css\";}}s:23:\"conditional-stylesheets\";a:2:{s:5:\"if IE\";a:1:{s:3:\"all\";a:1:{i:0;s:10:\"css/ie.css\";}}s:11:\"if lte IE 6\";a:1:{s:3:\"all\";a:1:{i:0;s:11:\"css/ie6.css\";}}}s:7:\"scripts\";a:1:{s:21:\"js/search-box-text.js\";s:51:\"profiles/os_demo/themes/doune/js/search-box-text.js\";}s:7:\"regions\";a:10:{s:13:\"sidebar_first\";s:13:\"First sidebar\";s:14:\"sidebar_second\";s:14:\"Second sidebar\";s:10:\"navigation\";s:14:\"Navigation bar\";s:9:\"highlight\";s:19:\"Highlighted content\";s:11:\"content_top\";s:11:\"Content top\";s:14:\"content_bottom\";s:14:\"Content bottom\";s:6:\"header\";s:6:\"Header\";s:10:\"postscript\";s:10:\"Postscript\";s:6:\"footer\";s:6:\"Footer\";s:12:\"page_closure\";s:12:\"Page closure\";}s:8:\"features\";a:10:{i:0;s:4:\"logo\";i:1;s:4:\"name\";i:2;s:6:\"slogan\";i:3;s:7:\"mission\";i:4;s:17:\"node_user_picture\";i:5;s:20:\"comment_user_picture\";i:6;s:6:\"search\";i:7;s:7:\"favicon\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:8:\"settings\";a:8:{s:17:\"zen_block_editing\";s:1:\"1\";s:14:\"zen_breadcrumb\";s:3:\"yes\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";s:1:\"1\";s:23:\"zen_breadcrumb_trailing\";s:1:\"1\";s:20:\"zen_breadcrumb_title\";s:1:\"0\";s:20:\"zen_rebuild_registry\";s:1:\"1\";s:14:\"zen_wireframes\";s:1:\"0\";}s:3:\"php\";s:5:\"4.3.5\";s:6:\"engine\";s:11:\"phptemplate\";}s:11:\"stylesheets\";a:3:{s:3:\"all\";a:37:{s:9:\"admin.css\";s:39:\"profiles/os_demo/themes/doune/admin.css\";s:9:\"block.css\";s:39:\"profiles/os_demo/themes/doune/block.css\";s:8:\"book.css\";s:38:\"profiles/os_demo/themes/doune/book.css\";s:11:\"comment.css\";s:41:\"profiles/os_demo/themes/doune/comment.css\";s:9:\"dblog.css\";s:39:\"profiles/os_demo/themes/doune/dblog.css\";s:12:\"defaults.css\";s:42:\"profiles/os_demo/themes/doune/defaults.css\";s:9:\"forum.css\";s:39:\"profiles/os_demo/themes/doune/forum.css\";s:8:\"help.css\";s:38:\"profiles/os_demo/themes/doune/help.css\";s:15:\"maintenance.css\";s:45:\"profiles/os_demo/themes/doune/maintenance.css\";s:8:\"node.css\";s:38:\"profiles/os_demo/themes/doune/node.css\";s:10:\"openid.css\";s:40:\"profiles/os_demo/themes/doune/openid.css\";s:8:\"poll.css\";s:38:\"profiles/os_demo/themes/doune/poll.css\";s:11:\"profile.css\";s:41:\"profiles/os_demo/themes/doune/profile.css\";s:10:\"search.css\";s:40:\"profiles/os_demo/themes/doune/search.css\";s:10:\"system.css\";s:40:\"profiles/os_demo/themes/doune/system.css\";s:16:\"system-menus.css\";s:46:\"profiles/os_demo/themes/doune/system-menus.css\";s:12:\"taxonomy.css\";s:42:\"profiles/os_demo/themes/doune/taxonomy.css\";s:11:\"tracker.css\";s:41:\"profiles/os_demo/themes/doune/tracker.css\";s:10:\"update.css\";s:40:\"profiles/os_demo/themes/doune/update.css\";s:8:\"user.css\";s:38:\"profiles/os_demo/themes/doune/user.css\";s:18:\"css/html-reset.css\";s:48:\"profiles/os_demo/themes/doune/css/html-reset.css\";s:18:\"css/wireframes.css\";s:48:\"profiles/os_demo/themes/doune/css/wireframes.css\";s:20:\"css/layout-fixed.css\";s:50:\"profiles/os_demo/themes/doune/css/layout-fixed.css\";s:24:\"css/page-backgrounds.css\";s:54:\"profiles/os_demo/themes/doune/css/page-backgrounds.css\";s:12:\"css/tabs.css\";s:42:\"profiles/os_demo/themes/doune/css/tabs.css\";s:16:\"css/messages.css\";s:46:\"profiles/os_demo/themes/doune/css/messages.css\";s:13:\"css/pages.css\";s:43:\"profiles/os_demo/themes/doune/css/pages.css\";s:21:\"css/block-editing.css\";s:51:\"profiles/os_demo/themes/doune/css/block-editing.css\";s:14:\"css/blocks.css\";s:44:\"profiles/os_demo/themes/doune/css/blocks.css\";s:18:\"css/navigation.css\";s:48:\"profiles/os_demo/themes/doune/css/navigation.css\";s:21:\"css/panels-styles.css\";s:51:\"profiles/os_demo/themes/doune/css/panels-styles.css\";s:20:\"css/views-styles.css\";s:50:\"profiles/os_demo/themes/doune/css/views-styles.css\";s:13:\"css/nodes.css\";s:43:\"profiles/os_demo/themes/doune/css/nodes.css\";s:16:\"css/comments.css\";s:46:\"profiles/os_demo/themes/doune/css/comments.css\";s:13:\"css/forms.css\";s:43:\"profiles/os_demo/themes/doune/css/forms.css\";s:14:\"css/fields.css\";s:44:\"profiles/os_demo/themes/doune/css/fields.css\";s:12:\"css/type.css\";s:42:\"profiles/os_demo/themes/doune/css/type.css\";}s:6:\"screen\";a:1:{s:14:\"css/drupal.css\";s:44:\"profiles/os_demo/themes/doune/css/drupal.css\";}s:5:\"print\";a:1:{s:13:\"css/print.css\";s:43:\"profiles/os_demo/themes/doune/css/print.css\";}}s:7:\"scripts\";a:1:{s:21:\"js/search-box-text.js\";s:51:\"profiles/os_demo/themes/doune/js/search-box-text.js\";}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:3:\"zen\";s:11:\"base_themes\";a:1:{s:3:\"zen\";s:3:\"Zen\";}}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:5:\"doune\";}',31,5,'admin/build/themes/settings','admin/build/themes','Doune','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/content/nodequeue/%/edit','a:1:{i:3;s:14:\"nodequeue_load\";}','','user_access','a:1:{i:0;s:20:\"administer nodequeue\";}','drupal_get_form','a:2:{i:0;s:25:\"nodequeue_edit_queue_form\";i:1;i:3;}',29,5,'admin/content/nodequeue/%','admin/content/nodequeue/%','Edit','t','',128,'','','',0,''),('admin/build/themes/settings/garland','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:27:\"themes/garland/garland.info\";s:4:\"name\";s:7:\"garland\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:7:\"Garland\";s:11:\"description\";s:66:\"Tableless, recolorable, multi-column, fluid width theme (default).\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:24:\"themes/garland/script.js\";}s:10:\"screenshot\";s:29:\"themes/garland/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:7:\"garland\";}',31,5,'admin/build/themes/settings','admin/build/themes','Garland','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/build/themes/settings/marvin','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:35:\"themes/chameleon/marvin/marvin.info\";s:4:\"name\";s:6:\"marvin\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:0:\"\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:6:\"Marvin\";s:11:\"description\";s:31:\"Boxy tabled theme in all grays.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:9:\"chameleon\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/chameleon/marvin/script.js\";}s:10:\"screenshot\";s:38:\"themes/chameleon/marvin/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:10:\"base_theme\";s:9:\"chameleon\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:6:\"marvin\";}',31,5,'admin/build/themes/settings','admin/build/themes','Marvin','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/build/themes/settings/minnelli','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:37:\"themes/garland/minnelli/minnelli.info\";s:4:\"name\";s:8:\"minnelli\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:14:{s:4:\"name\";s:8:\"Minnelli\";s:11:\"description\";s:56:\"Tableless, recolorable, multi-column, fixed width theme.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:7:\"garland\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/garland/minnelli/script.js\";}s:10:\"screenshot\";s:38:\"themes/garland/minnelli/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";s:6:\"engine\";s:11:\"phptemplate\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:7:\"garland\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:8:\"minnelli\";}',31,5,'admin/build/themes/settings','admin/build/themes','Minnelli','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/build/themes/settings/pushbutton','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/pushbutton/pushbutton.info\";s:4:\"name\";s:10:\"pushbutton\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:10:\"Pushbutton\";s:11:\"description\";s:52:\"Tabled, multi-column theme in blue and orange tones.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/pushbutton/script.js\";}s:10:\"screenshot\";s:32:\"themes/pushbutton/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:10:\"pushbutton\";}',31,5,'admin/build/themes/settings','admin/build/themes','Pushbutton','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/build/themes/settings/rubik','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":14:{s:8:\"filename\";s:40:\"profiles/os_demo/themes/rubik/rubik.info\";s:4:\"name\";s:5:\"rubik\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:14:{s:4:\"name\";s:5:\"Rubik\";s:11:\"description\";s:18:\"Clean admin theme.\";s:10:\"base theme\";s:3:\"tao\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"scripts\";a:1:{s:11:\"js/rubik.js\";s:41:\"profiles/os_demo/themes/rubik/js/rubik.js\";}s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:3:{s:8:\"core.css\";s:38:\"profiles/os_demo/themes/rubik/core.css\";s:9:\"icons.css\";s:39:\"profiles/os_demo/themes/rubik/icons.css\";s:9:\"style.css\";s:39:\"profiles/os_demo/themes/rubik/style.css\";}}s:7:\"version\";s:13:\"6.x-3.0-beta2\";s:7:\"project\";s:5:\"rubik\";s:9:\"datestamp\";s:10:\"1285709466\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:10:\"screenshot\";s:44:\"profiles/os_demo/themes/rubik/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:3:{s:8:\"core.css\";s:38:\"profiles/os_demo/themes/rubik/core.css\";s:9:\"icons.css\";s:39:\"profiles/os_demo/themes/rubik/icons.css\";s:9:\"style.css\";s:39:\"profiles/os_demo/themes/rubik/style.css\";}}s:7:\"scripts\";a:1:{s:11:\"js/rubik.js\";s:41:\"profiles/os_demo/themes/rubik/js/rubik.js\";}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:3:\"tao\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:5:\"rubik\";}',31,5,'admin/build/themes/settings','admin/build/themes','Rubik','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/build/themes/settings/tao','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:36:\"profiles/os_demo/themes/tao/tao.info\";s:4:\"name\";s:3:\"tao\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"core\";s:3:\"6.x\";s:11:\"description\";s:149:\"Tao is a base theme that is all about going with the flow. It takes care of key reset and utility tasks so that sub-themes can get on with their job.\";s:6:\"engine\";s:11:\"phptemplate\";s:4:\"name\";s:3:\"Tao\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:7:\"scripts\";a:1:{s:9:\"js/tao.js\";s:37:\"profiles/os_demo/themes/tao/js/tao.js\";}s:11:\"stylesheets\";a:3:{s:6:\"screen\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:10:\"drupal.css\";s:38:\"profiles/os_demo/themes/tao/drupal.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";}s:5:\"print\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";s:9:\"print.css\";s:37:\"profiles/os_demo/themes/tao/print.css\";}s:3:\"all\";a:20:{s:9:\"admin.css\";s:37:\"profiles/os_demo/themes/tao/admin.css\";s:9:\"block.css\";s:37:\"profiles/os_demo/themes/tao/block.css\";s:8:\"book.css\";s:36:\"profiles/os_demo/themes/tao/book.css\";s:11:\"comment.css\";s:39:\"profiles/os_demo/themes/tao/comment.css\";s:9:\"dblog.css\";s:37:\"profiles/os_demo/themes/tao/dblog.css\";s:12:\"defaults.css\";s:40:\"profiles/os_demo/themes/tao/defaults.css\";s:9:\"forum.css\";s:37:\"profiles/os_demo/themes/tao/forum.css\";s:8:\"help.css\";s:36:\"profiles/os_demo/themes/tao/help.css\";s:15:\"maintenance.css\";s:43:\"profiles/os_demo/themes/tao/maintenance.css\";s:8:\"node.css\";s:36:\"profiles/os_demo/themes/tao/node.css\";s:10:\"openid.css\";s:38:\"profiles/os_demo/themes/tao/openid.css\";s:8:\"poll.css\";s:36:\"profiles/os_demo/themes/tao/poll.css\";s:11:\"profile.css\";s:39:\"profiles/os_demo/themes/tao/profile.css\";s:10:\"search.css\";s:38:\"profiles/os_demo/themes/tao/search.css\";s:10:\"system.css\";s:38:\"profiles/os_demo/themes/tao/system.css\";s:16:\"system-menus.css\";s:44:\"profiles/os_demo/themes/tao/system-menus.css\";s:12:\"taxonomy.css\";s:40:\"profiles/os_demo/themes/tao/taxonomy.css\";s:11:\"tracker.css\";s:39:\"profiles/os_demo/themes/tao/tracker.css\";s:10:\"update.css\";s:38:\"profiles/os_demo/themes/tao/update.css\";s:8:\"user.css\";s:36:\"profiles/os_demo/themes/tao/user.css\";}}s:7:\"version\";s:7:\"6.x-3.1\";s:7:\"project\";s:3:\"tao\";s:9:\"datestamp\";s:10:\"1285704363\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:10:\"screenshot\";s:42:\"profiles/os_demo/themes/tao/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:3:{s:6:\"screen\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:10:\"drupal.css\";s:38:\"profiles/os_demo/themes/tao/drupal.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";}s:5:\"print\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";s:9:\"print.css\";s:37:\"profiles/os_demo/themes/tao/print.css\";}s:3:\"all\";a:20:{s:9:\"admin.css\";s:37:\"profiles/os_demo/themes/tao/admin.css\";s:9:\"block.css\";s:37:\"profiles/os_demo/themes/tao/block.css\";s:8:\"book.css\";s:36:\"profiles/os_demo/themes/tao/book.css\";s:11:\"comment.css\";s:39:\"profiles/os_demo/themes/tao/comment.css\";s:9:\"dblog.css\";s:37:\"profiles/os_demo/themes/tao/dblog.css\";s:12:\"defaults.css\";s:40:\"profiles/os_demo/themes/tao/defaults.css\";s:9:\"forum.css\";s:37:\"profiles/os_demo/themes/tao/forum.css\";s:8:\"help.css\";s:36:\"profiles/os_demo/themes/tao/help.css\";s:15:\"maintenance.css\";s:43:\"profiles/os_demo/themes/tao/maintenance.css\";s:8:\"node.css\";s:36:\"profiles/os_demo/themes/tao/node.css\";s:10:\"openid.css\";s:38:\"profiles/os_demo/themes/tao/openid.css\";s:8:\"poll.css\";s:36:\"profiles/os_demo/themes/tao/poll.css\";s:11:\"profile.css\";s:39:\"profiles/os_demo/themes/tao/profile.css\";s:10:\"search.css\";s:38:\"profiles/os_demo/themes/tao/search.css\";s:10:\"system.css\";s:38:\"profiles/os_demo/themes/tao/system.css\";s:16:\"system-menus.css\";s:44:\"profiles/os_demo/themes/tao/system-menus.css\";s:12:\"taxonomy.css\";s:40:\"profiles/os_demo/themes/tao/taxonomy.css\";s:11:\"tracker.css\";s:39:\"profiles/os_demo/themes/tao/tracker.css\";s:10:\"update.css\";s:38:\"profiles/os_demo/themes/tao/update.css\";s:8:\"user.css\";s:36:\"profiles/os_demo/themes/tao/user.css\";}}s:7:\"scripts\";a:1:{s:9:\"js/tao.js\";s:37:\"profiles/os_demo/themes/tao/js/tao.js\";}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:3:\"tao\";}',31,5,'admin/build/themes/settings','admin/build/themes','Tao','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/build/features/%/view','a:1:{i:3;s:12:\"feature_load\";}','','user_access','a:1:{i:0;s:19:\"administer features\";}','drupal_get_form','a:2:{i:0;s:25:\"features_admin_components\";i:1;i:3;}',29,5,'admin/build/features/%','admin/build/features/%','View','t','',136,'','Display components of a feature.','',-10,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('admin/build/themes/settings/zen','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:36:\"profiles/os_demo/themes/zen/zen.info\";s:4:\"name\";s:3:\"zen\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:15:{s:4:\"name\";s:3:\"Zen\";s:11:\"description\";s:189:\"Zen sub-themes are the ultimate starting themes for Drupal 6. Read the <a href=\"http://drupal.org/node/226507\">online docs</a> or the included README-FIRST.txt on how to create a sub-theme.\";s:10:\"screenshot\";s:56:\"profiles/os_demo/themes/zen/zen-internals/screenshot.png\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:9:{s:13:\"sidebar_first\";s:13:\"First sidebar\";s:14:\"sidebar_second\";s:14:\"Second sidebar\";s:10:\"navigation\";s:14:\"Navigation bar\";s:9:\"highlight\";s:19:\"Highlighted content\";s:11:\"content_top\";s:11:\"Content top\";s:14:\"content_bottom\";s:14:\"Content bottom\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";s:12:\"page_closure\";s:12:\"Page closure\";}s:8:\"features\";a:10:{i:0;s:4:\"logo\";i:1;s:4:\"name\";i:2;s:6:\"slogan\";i:3;s:7:\"mission\";i:4;s:17:\"node_user_picture\";i:5;s:20:\"comment_user_picture\";i:6;s:6:\"search\";i:7;s:7:\"favicon\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:8:\"settings\";a:9:{s:17:\"zen_block_editing\";s:1:\"1\";s:14:\"zen_breadcrumb\";s:3:\"yes\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";s:1:\"1\";s:23:\"zen_breadcrumb_trailing\";s:1:\"1\";s:20:\"zen_breadcrumb_title\";s:1:\"0\";s:10:\"zen_layout\";s:18:\"zen-columns-liquid\";s:20:\"zen_rebuild_registry\";s:1:\"0\";s:14:\"zen_wireframes\";s:1:\"0\";}s:7:\"plugins\";a:1:{s:6:\"panels\";a:1:{s:7:\"layouts\";s:7:\"layouts\";}}s:7:\"version\";s:7:\"6.x-2.0\";s:7:\"project\";s:3:\"zen\";s:9:\"datestamp\";s:10:\"1277583313\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:37:\"profiles/os_demo/themes/zen/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:37:\"profiles/os_demo/themes/zen/script.js\";}s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:37:\"profiles/os_demo/themes/zen/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:3:\"zen\";}',31,5,'admin/build/themes/settings','admin/build/themes','Zen','t','',128,'','','',0,'modules/system/system.admin.inc'),('admin/content/nodequeue/add/nodequeue','','','user_access','a:1:{i:0;s:20:\"administer nodequeue\";}','drupal_get_form','a:2:{i:0;s:25:\"nodequeue_edit_queue_form\";i:1;s:9:\"nodequeue\";}',31,5,'admin/content/nodequeue','admin/content/nodequeue','Add @type','t','a:1:{s:5:\"@type\";s:9:\"nodequeue\";}',128,'','','',0,''),('admin/build/menu-customize/%/add','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:4:{i:0;s:14:\"menu_edit_item\";i:1;s:3:\"add\";i:2;N;i:3;i:3;}',29,5,'admin/build/menu-customize/%','admin/build/menu-customize/%','Add item','t','',128,'','','',0,'modules/menu/menu.admin.inc'),('admin/build/block/list/bluemarine','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/bluemarine/bluemarine.info\";s:4:\"name\";s:10:\"bluemarine\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:10:\"Bluemarine\";s:11:\"description\";s:66:\"Table-based multi-column theme with a marine and ash color scheme.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/bluemarine/script.js\";}s:10:\"screenshot\";s:32:\"themes/bluemarine/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:10:\"bluemarine\";}',31,5,'admin/build/block/list','admin/build/block','Bluemarine','t','',128,'','','',0,'modules/block/block.admin.inc'),('filefield/ahah/%/%/%','a:3:{i:2;N;i:3;N;i:4;N;}','','filefield_edit_access','a:2:{i:0;i:2;i:1;i:3;}','filefield_js','a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}',24,5,'','filefield/ahah/%/%/%','','t','',4,'','','',0,''),('admin/build/block/list/chameleon','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":11:{s:8:\"filename\";s:31:\"themes/chameleon/chameleon.info\";s:4:\"name\";s:9:\"chameleon\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:32:\"themes/chameleon/chameleon.theme\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:12:{s:4:\"name\";s:9:\"Chameleon\";s:11:\"description\";s:42:\"Minimalist tabled theme with light colors.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:8:\"features\";a:4:{i:0;s:4:\"logo\";i:1;s:7:\"favicon\";i:2;s:4:\"name\";i:3;s:6:\"slogan\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"scripts\";a:1:{s:9:\"script.js\";s:26:\"themes/chameleon/script.js\";}s:10:\"screenshot\";s:31:\"themes/chameleon/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}}}','block_admin_display','a:1:{i:0;s:9:\"chameleon\";}',31,5,'admin/build/block/list','admin/build/block','Chameleon','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/settings/filters/%/configure','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_configure_page','a:1:{i:0;i:3;}',29,5,'admin/settings/filters/%','admin/settings/filters/%','Configure','t','',128,'','','',1,'modules/filter/filter.admin.inc'),('admin/build/block/list/cube','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:44:\"profiles/os_demo/themes/rubik/cube/cube.info\";s:4:\"name\";s:4:\"cube\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:16:{s:4:\"name\";s:4:\"Cube\";s:11:\"description\";s:44:\"Spaces-aware front-end theme based on Rubik.\";s:10:\"base theme\";s:5:\"rubik\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:1:{s:9:\"style.css\";s:44:\"profiles/os_demo/themes/rubik/cube/style.css\";}}s:7:\"regions\";a:4:{s:6:\"header\";s:6:\"Header\";s:7:\"content\";s:7:\"Content\";s:4:\"left\";s:4:\"Left\";s:5:\"right\";s:5:\"Right\";}s:9:\"designkit\";a:2:{s:5:\"color\";a:1:{s:10:\"background\";s:7:\"#0088cc\";}s:4:\"logo\";a:2:{s:4:\"logo\";s:23:\"imagecache_scale:200x50\";s:5:\"print\";s:24:\"imagecache_scale:600x150\";}}s:7:\"layouts\";a:5:{s:7:\"default\";a:3:{s:4:\"name\";s:7:\"Default\";s:11:\"description\";s:23:\"Simple one column page.\";s:8:\"template\";s:4:\"page\";}s:7:\"sidebar\";a:5:{s:4:\"name\";s:7:\"Sidebar\";s:11:\"description\";s:26:\"Main content with sidebar.\";s:10:\"stylesheet\";s:18:\"layout-sidebar.css\";s:8:\"template\";s:14:\"layout-sidebar\";s:7:\"regions\";a:2:{i:0;s:7:\"content\";i:1;s:5:\"right\";}}s:5:\"split\";a:5:{s:4:\"name\";s:5:\"Split\";s:11:\"description\";s:12:\"50/50 split.\";s:10:\"stylesheet\";s:16:\"layout-split.css\";s:8:\"template\";s:14:\"layout-sidebar\";s:7:\"regions\";a:2:{i:0;s:7:\"content\";i:1;s:5:\"right\";}}s:7:\"columns\";a:5:{s:4:\"name\";s:7:\"Columns\";s:11:\"description\";s:20:\"Three column layout.\";s:10:\"stylesheet\";s:18:\"layout-columns.css\";s:8:\"template\";s:14:\"layout-columns\";s:7:\"regions\";a:4:{i:0;s:6:\"header\";i:1;s:7:\"content\";i:2;s:4:\"left\";i:3;s:5:\"right\";}}s:6:\"offset\";a:5:{s:4:\"name\";s:15:\"Offset sidebars\";s:11:\"description\";s:38:\"Main content with two offset sidebars.\";s:10:\"stylesheet\";s:17:\"layout-offset.css\";s:8:\"template\";s:13:\"layout-offset\";s:7:\"regions\";a:4:{i:0;s:6:\"header\";i:1;s:7:\"content\";i:2;s:4:\"left\";i:3;s:5:\"right\";}}}s:7:\"version\";s:13:\"6.x-3.0-beta2\";s:7:\"project\";s:5:\"rubik\";s:9:\"datestamp\";s:10:\"1285709466\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:44:\"profiles/os_demo/themes/rubik/cube/script.js\";}s:10:\"screenshot\";s:49:\"profiles/os_demo/themes/rubik/cube/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:1:{s:9:\"style.css\";s:44:\"profiles/os_demo/themes/rubik/cube/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:5:\"rubik\";}}','block_admin_display','a:1:{i:0;s:4:\"cube\";}',31,5,'admin/build/block/list','admin/build/block','Cube','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/settings/date-time/formats/custom','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','date_api_configure_custom_date_formats','a:0:{}',31,5,'admin/settings/date-time/formats','admin/settings/date-time','Custom formats','t','',128,'','Allow users to configure custom date formats.','',2,'profiles/os_demo/modules/contrib/date/date_api.admin.inc'),('admin/content/node-type/webform/delete','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:24:\"node_type_delete_confirm\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:7:\"webform\";s:4:\"name\";s:7:\"Webform\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:138:\"Create a new form or questionnaire accessible to users. Submission results and statistics are recorded and accessible to privileged users.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:7:\"webform\";}}',31,5,'','admin/content/node-type/webform/delete','Delete','t','',4,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/blog/delete','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:24:\"node_type_delete_confirm\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:9:\"Blog post\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:4:\"blog\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:4:\"blog\";s:6:\"is_new\";b:1;}}',31,5,'','admin/content/node-type/blog/delete','Delete','t','',4,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/event/delete','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:24:\"node_type_delete_confirm\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:5:\"Event\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:7:\"Details\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:5:\"event\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:5:\"event\";s:6:\"is_new\";b:1;}}',31,5,'','admin/content/node-type/event/delete','Delete','t','',4,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/page/delete','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:24:\"node_type_delete_confirm\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:4:\"Page\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:258:\"A <em>page</em> is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:4:\"page\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:4:\"page\";s:6:\"is_new\";b:1;}}',31,5,'','admin/content/node-type/page/delete','Delete','t','',4,'','','',0,'modules/node/content_types.inc'),('admin/content/node-type/slide/delete','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:24:\"node_type_delete_confirm\";i:1;O:8:\"stdClass\":15:{s:4:\"name\";s:5:\"Slide\";s:6:\"module\";s:8:\"features\";s:11:\"description\";s:46:\"An image to be used in the homepage slideshow.\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:8:\"Headline\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:11:\"Description\";s:14:\"min_word_count\";s:1:\"0\";s:4:\"help\";s:0:\"\";s:4:\"type\";s:5:\"slide\";s:6:\"custom\";b:0;s:8:\"modified\";b:0;s:6:\"locked\";b:1;s:9:\"orig_type\";s:5:\"slide\";s:6:\"is_new\";b:1;}}',31,5,'','admin/content/node-type/slide/delete','Delete','t','',4,'','','',0,'modules/node/content_types.inc'),('admin/content/nodequeue/%/delete','a:1:{i:3;s:14:\"nodequeue_load\";}','','user_access','a:1:{i:0;s:20:\"administer nodequeue\";}','drupal_get_form','a:2:{i:0;s:22:\"nodequeue_admin_delete\";i:1;i:3;}',29,5,'','admin/content/nodequeue/%/delete','Delete','t','',4,'','','',5,''),('admin/content/node-type/blog/display','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"blog\";}',31,5,'admin/content/node-type/blog','admin/content/node-type/blog','Display fields','t','',128,'','','',2,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/display','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"event\";}',31,5,'admin/content/node-type/event','admin/content/node-type/event','Display fields','t','',128,'','','',2,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/page/display','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"page\";}',31,5,'admin/content/node-type/page','admin/content/node-type/page','Display fields','t','',128,'','','',2,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/display','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"slide\";}',31,5,'admin/content/node-type/slide','admin/content/node-type/slide','Display fields','t','',128,'','','',2,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/webform/display','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:29:\"content_display_overview_form\";i:1;s:7:\"webform\";}',31,5,'admin/content/node-type/webform','admin/content/node-type/webform','Display fields','t','',128,'','','',2,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/build/block/list/doune','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":15:{s:8:\"filename\";s:40:\"profiles/os_demo/themes/doune/doune.info\";s:4:\"name\";s:5:\"doune\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:14:{s:4:\"name\";s:5:\"Doune\";s:11:\"description\";s:24:\"OpenSourcery base theme.\";s:10:\"screenshot\";s:44:\"profiles/os_demo/themes/doune/screenshot.png\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:3:\"zen\";s:7:\"version\";s:7:\"6.x-0.2\";s:11:\"stylesheets\";a:3:{s:3:\"all\";a:37:{s:9:\"admin.css\";s:39:\"profiles/os_demo/themes/doune/admin.css\";s:9:\"block.css\";s:39:\"profiles/os_demo/themes/doune/block.css\";s:8:\"book.css\";s:38:\"profiles/os_demo/themes/doune/book.css\";s:11:\"comment.css\";s:41:\"profiles/os_demo/themes/doune/comment.css\";s:9:\"dblog.css\";s:39:\"profiles/os_demo/themes/doune/dblog.css\";s:12:\"defaults.css\";s:42:\"profiles/os_demo/themes/doune/defaults.css\";s:9:\"forum.css\";s:39:\"profiles/os_demo/themes/doune/forum.css\";s:8:\"help.css\";s:38:\"profiles/os_demo/themes/doune/help.css\";s:15:\"maintenance.css\";s:45:\"profiles/os_demo/themes/doune/maintenance.css\";s:8:\"node.css\";s:38:\"profiles/os_demo/themes/doune/node.css\";s:10:\"openid.css\";s:40:\"profiles/os_demo/themes/doune/openid.css\";s:8:\"poll.css\";s:38:\"profiles/os_demo/themes/doune/poll.css\";s:11:\"profile.css\";s:41:\"profiles/os_demo/themes/doune/profile.css\";s:10:\"search.css\";s:40:\"profiles/os_demo/themes/doune/search.css\";s:10:\"system.css\";s:40:\"profiles/os_demo/themes/doune/system.css\";s:16:\"system-menus.css\";s:46:\"profiles/os_demo/themes/doune/system-menus.css\";s:12:\"taxonomy.css\";s:42:\"profiles/os_demo/themes/doune/taxonomy.css\";s:11:\"tracker.css\";s:41:\"profiles/os_demo/themes/doune/tracker.css\";s:10:\"update.css\";s:40:\"profiles/os_demo/themes/doune/update.css\";s:8:\"user.css\";s:38:\"profiles/os_demo/themes/doune/user.css\";s:18:\"css/html-reset.css\";s:48:\"profiles/os_demo/themes/doune/css/html-reset.css\";s:18:\"css/wireframes.css\";s:48:\"profiles/os_demo/themes/doune/css/wireframes.css\";s:20:\"css/layout-fixed.css\";s:50:\"profiles/os_demo/themes/doune/css/layout-fixed.css\";s:24:\"css/page-backgrounds.css\";s:54:\"profiles/os_demo/themes/doune/css/page-backgrounds.css\";s:12:\"css/tabs.css\";s:42:\"profiles/os_demo/themes/doune/css/tabs.css\";s:16:\"css/messages.css\";s:46:\"profiles/os_demo/themes/doune/css/messages.css\";s:13:\"css/pages.css\";s:43:\"profiles/os_demo/themes/doune/css/pages.css\";s:21:\"css/block-editing.css\";s:51:\"profiles/os_demo/themes/doune/css/block-editing.css\";s:14:\"css/blocks.css\";s:44:\"profiles/os_demo/themes/doune/css/blocks.css\";s:18:\"css/navigation.css\";s:48:\"profiles/os_demo/themes/doune/css/navigation.css\";s:21:\"css/panels-styles.css\";s:51:\"profiles/os_demo/themes/doune/css/panels-styles.css\";s:20:\"css/views-styles.css\";s:50:\"profiles/os_demo/themes/doune/css/views-styles.css\";s:13:\"css/nodes.css\";s:43:\"profiles/os_demo/themes/doune/css/nodes.css\";s:16:\"css/comments.css\";s:46:\"profiles/os_demo/themes/doune/css/comments.css\";s:13:\"css/forms.css\";s:43:\"profiles/os_demo/themes/doune/css/forms.css\";s:14:\"css/fields.css\";s:44:\"profiles/os_demo/themes/doune/css/fields.css\";s:12:\"css/type.css\";s:42:\"profiles/os_demo/themes/doune/css/type.css\";}s:6:\"screen\";a:1:{s:14:\"css/drupal.css\";s:44:\"profiles/os_demo/themes/doune/css/drupal.css\";}s:5:\"print\";a:1:{s:13:\"css/print.css\";s:43:\"profiles/os_demo/themes/doune/css/print.css\";}}s:23:\"conditional-stylesheets\";a:2:{s:5:\"if IE\";a:1:{s:3:\"all\";a:1:{i:0;s:10:\"css/ie.css\";}}s:11:\"if lte IE 6\";a:1:{s:3:\"all\";a:1:{i:0;s:11:\"css/ie6.css\";}}}s:7:\"scripts\";a:1:{s:21:\"js/search-box-text.js\";s:51:\"profiles/os_demo/themes/doune/js/search-box-text.js\";}s:7:\"regions\";a:10:{s:13:\"sidebar_first\";s:13:\"First sidebar\";s:14:\"sidebar_second\";s:14:\"Second sidebar\";s:10:\"navigation\";s:14:\"Navigation bar\";s:9:\"highlight\";s:19:\"Highlighted content\";s:11:\"content_top\";s:11:\"Content top\";s:14:\"content_bottom\";s:14:\"Content bottom\";s:6:\"header\";s:6:\"Header\";s:10:\"postscript\";s:10:\"Postscript\";s:6:\"footer\";s:6:\"Footer\";s:12:\"page_closure\";s:12:\"Page closure\";}s:8:\"features\";a:10:{i:0;s:4:\"logo\";i:1;s:4:\"name\";i:2;s:6:\"slogan\";i:3;s:7:\"mission\";i:4;s:17:\"node_user_picture\";i:5;s:20:\"comment_user_picture\";i:6;s:6:\"search\";i:7;s:7:\"favicon\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:8:\"settings\";a:8:{s:17:\"zen_block_editing\";s:1:\"1\";s:14:\"zen_breadcrumb\";s:3:\"yes\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";s:1:\"1\";s:23:\"zen_breadcrumb_trailing\";s:1:\"1\";s:20:\"zen_breadcrumb_title\";s:1:\"0\";s:20:\"zen_rebuild_registry\";s:1:\"1\";s:14:\"zen_wireframes\";s:1:\"0\";}s:3:\"php\";s:5:\"4.3.5\";s:6:\"engine\";s:11:\"phptemplate\";}s:11:\"stylesheets\";a:3:{s:3:\"all\";a:37:{s:9:\"admin.css\";s:39:\"profiles/os_demo/themes/doune/admin.css\";s:9:\"block.css\";s:39:\"profiles/os_demo/themes/doune/block.css\";s:8:\"book.css\";s:38:\"profiles/os_demo/themes/doune/book.css\";s:11:\"comment.css\";s:41:\"profiles/os_demo/themes/doune/comment.css\";s:9:\"dblog.css\";s:39:\"profiles/os_demo/themes/doune/dblog.css\";s:12:\"defaults.css\";s:42:\"profiles/os_demo/themes/doune/defaults.css\";s:9:\"forum.css\";s:39:\"profiles/os_demo/themes/doune/forum.css\";s:8:\"help.css\";s:38:\"profiles/os_demo/themes/doune/help.css\";s:15:\"maintenance.css\";s:45:\"profiles/os_demo/themes/doune/maintenance.css\";s:8:\"node.css\";s:38:\"profiles/os_demo/themes/doune/node.css\";s:10:\"openid.css\";s:40:\"profiles/os_demo/themes/doune/openid.css\";s:8:\"poll.css\";s:38:\"profiles/os_demo/themes/doune/poll.css\";s:11:\"profile.css\";s:41:\"profiles/os_demo/themes/doune/profile.css\";s:10:\"search.css\";s:40:\"profiles/os_demo/themes/doune/search.css\";s:10:\"system.css\";s:40:\"profiles/os_demo/themes/doune/system.css\";s:16:\"system-menus.css\";s:46:\"profiles/os_demo/themes/doune/system-menus.css\";s:12:\"taxonomy.css\";s:42:\"profiles/os_demo/themes/doune/taxonomy.css\";s:11:\"tracker.css\";s:41:\"profiles/os_demo/themes/doune/tracker.css\";s:10:\"update.css\";s:40:\"profiles/os_demo/themes/doune/update.css\";s:8:\"user.css\";s:38:\"profiles/os_demo/themes/doune/user.css\";s:18:\"css/html-reset.css\";s:48:\"profiles/os_demo/themes/doune/css/html-reset.css\";s:18:\"css/wireframes.css\";s:48:\"profiles/os_demo/themes/doune/css/wireframes.css\";s:20:\"css/layout-fixed.css\";s:50:\"profiles/os_demo/themes/doune/css/layout-fixed.css\";s:24:\"css/page-backgrounds.css\";s:54:\"profiles/os_demo/themes/doune/css/page-backgrounds.css\";s:12:\"css/tabs.css\";s:42:\"profiles/os_demo/themes/doune/css/tabs.css\";s:16:\"css/messages.css\";s:46:\"profiles/os_demo/themes/doune/css/messages.css\";s:13:\"css/pages.css\";s:43:\"profiles/os_demo/themes/doune/css/pages.css\";s:21:\"css/block-editing.css\";s:51:\"profiles/os_demo/themes/doune/css/block-editing.css\";s:14:\"css/blocks.css\";s:44:\"profiles/os_demo/themes/doune/css/blocks.css\";s:18:\"css/navigation.css\";s:48:\"profiles/os_demo/themes/doune/css/navigation.css\";s:21:\"css/panels-styles.css\";s:51:\"profiles/os_demo/themes/doune/css/panels-styles.css\";s:20:\"css/views-styles.css\";s:50:\"profiles/os_demo/themes/doune/css/views-styles.css\";s:13:\"css/nodes.css\";s:43:\"profiles/os_demo/themes/doune/css/nodes.css\";s:16:\"css/comments.css\";s:46:\"profiles/os_demo/themes/doune/css/comments.css\";s:13:\"css/forms.css\";s:43:\"profiles/os_demo/themes/doune/css/forms.css\";s:14:\"css/fields.css\";s:44:\"profiles/os_demo/themes/doune/css/fields.css\";s:12:\"css/type.css\";s:42:\"profiles/os_demo/themes/doune/css/type.css\";}s:6:\"screen\";a:1:{s:14:\"css/drupal.css\";s:44:\"profiles/os_demo/themes/doune/css/drupal.css\";}s:5:\"print\";a:1:{s:13:\"css/print.css\";s:43:\"profiles/os_demo/themes/doune/css/print.css\";}}s:7:\"scripts\";a:1:{s:21:\"js/search-box-text.js\";s:51:\"profiles/os_demo/themes/doune/js/search-box-text.js\";}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:3:\"zen\";s:11:\"base_themes\";a:1:{s:3:\"zen\";s:3:\"Zen\";}}}','block_admin_display','a:1:{i:0;s:5:\"doune\";}',31,5,'admin/build/block/list','admin/build/block','Doune','t','',136,'','','',-10,'modules/block/block.admin.inc'),('admin/build/menu-customize/%/edit','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:3:{i:0;s:14:\"menu_edit_menu\";i:1;s:4:\"edit\";i:2;i:3;}',29,5,'admin/build/menu-customize/%','admin/build/menu-customize/%','Edit menu','t','',128,'','','',0,'modules/menu/menu.admin.inc'),('admin/content/taxonomy/edit/term','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','taxonomy_admin_term_edit','a:0:{}',31,5,'','admin/content/taxonomy/edit/term','Edit term','t','',4,'','','',0,'modules/taxonomy/taxonomy.admin.inc'),('admin/build/block/list/garland','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:27:\"themes/garland/garland.info\";s:4:\"name\";s:7:\"garland\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:7:\"Garland\";s:11:\"description\";s:66:\"Tableless, recolorable, multi-column, fluid width theme (default).\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:24:\"themes/garland/script.js\";}s:10:\"screenshot\";s:29:\"themes/garland/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:7:\"garland\";}',31,5,'admin/build/block/list','admin/build/block','Garland','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/build/block/list/js','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','block_admin_display_js','a:0:{}',31,5,'','admin/build/block/list/js','JavaScript List Form','t','',4,'','','',0,'modules/block/block.admin.inc'),('admin/content/node-type/blog/fields','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:27:\"content_field_overview_form\";i:1;s:4:\"blog\";}',31,5,'admin/content/node-type/blog','admin/content/node-type/blog','Manage fields','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/fields','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:27:\"content_field_overview_form\";i:1;s:5:\"event\";}',31,5,'admin/content/node-type/event','admin/content/node-type/event','Manage fields','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/page/fields','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:27:\"content_field_overview_form\";i:1;s:4:\"page\";}',31,5,'admin/content/node-type/page','admin/content/node-type/page','Manage fields','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/fields','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:27:\"content_field_overview_form\";i:1;s:5:\"slide\";}',31,5,'admin/content/node-type/slide','admin/content/node-type/slide','Manage fields','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/webform/fields','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:27:\"content_field_overview_form\";i:1;s:7:\"webform\";}',31,5,'admin/content/node-type/webform','admin/content/node-type/webform','Manage fields','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/build/block/list/marvin','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:35:\"themes/chameleon/marvin/marvin.info\";s:4:\"name\";s:6:\"marvin\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:0:\"\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:6:\"Marvin\";s:11:\"description\";s:31:\"Boxy tabled theme in all grays.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:9:\"chameleon\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/chameleon/marvin/script.js\";}s:10:\"screenshot\";s:38:\"themes/chameleon/marvin/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:10:\"base_theme\";s:9:\"chameleon\";}}','block_admin_display','a:1:{i:0;s:6:\"marvin\";}',31,5,'admin/build/block/list','admin/build/block','Marvin','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/build/block/list/minnelli','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:37:\"themes/garland/minnelli/minnelli.info\";s:4:\"name\";s:8:\"minnelli\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:14:{s:4:\"name\";s:8:\"Minnelli\";s:11:\"description\";s:56:\"Tableless, recolorable, multi-column, fixed width theme.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:7:\"garland\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/garland/minnelli/script.js\";}s:10:\"screenshot\";s:38:\"themes/garland/minnelli/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";s:6:\"engine\";s:11:\"phptemplate\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:7:\"garland\";}}','block_admin_display','a:1:{i:0;s:8:\"minnelli\";}',31,5,'admin/build/block/list','admin/build/block','Minnelli','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/build/block/list/pushbutton','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/pushbutton/pushbutton.info\";s:4:\"name\";s:10:\"pushbutton\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"name\";s:10:\"Pushbutton\";s:11:\"description\";s:52:\"Tabled, multi-column theme in blue and orange tones.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/pushbutton/script.js\";}s:10:\"screenshot\";s:32:\"themes/pushbutton/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:10:\"pushbutton\";}',31,5,'admin/build/block/list','admin/build/block','Pushbutton','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/settings/filters/%/order','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_order_page','a:1:{i:0;i:3;}',29,5,'admin/settings/filters/%','admin/settings/filters/%','Rearrange','t','',128,'','','',2,'modules/filter/filter.admin.inc'),('user/reset/%/%/%','a:3:{i:2;N;i:3;N;i:4;N;}','','1','a:0:{}','drupal_get_form','a:4:{i:0;s:15:\"user_pass_reset\";i:1;i:2;i:2;i:3;i:3;i:4;}',24,5,'','user/reset/%/%/%','Reset password','t','',4,'','','',0,'modules/user/user.pages.inc'),('admin/build/block/list/rubik','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":14:{s:8:\"filename\";s:40:\"profiles/os_demo/themes/rubik/rubik.info\";s:4:\"name\";s:5:\"rubik\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:14:{s:4:\"name\";s:5:\"Rubik\";s:11:\"description\";s:18:\"Clean admin theme.\";s:10:\"base theme\";s:3:\"tao\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"scripts\";a:1:{s:11:\"js/rubik.js\";s:41:\"profiles/os_demo/themes/rubik/js/rubik.js\";}s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:3:{s:8:\"core.css\";s:38:\"profiles/os_demo/themes/rubik/core.css\";s:9:\"icons.css\";s:39:\"profiles/os_demo/themes/rubik/icons.css\";s:9:\"style.css\";s:39:\"profiles/os_demo/themes/rubik/style.css\";}}s:7:\"version\";s:13:\"6.x-3.0-beta2\";s:7:\"project\";s:5:\"rubik\";s:9:\"datestamp\";s:10:\"1285709466\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:10:\"screenshot\";s:44:\"profiles/os_demo/themes/rubik/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:3:{s:8:\"core.css\";s:38:\"profiles/os_demo/themes/rubik/core.css\";s:9:\"icons.css\";s:39:\"profiles/os_demo/themes/rubik/icons.css\";s:9:\"style.css\";s:39:\"profiles/os_demo/themes/rubik/style.css\";}}s:7:\"scripts\";a:1:{s:11:\"js/rubik.js\";s:41:\"profiles/os_demo/themes/rubik/js/rubik.js\";}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:3:\"tao\";}}','block_admin_display','a:1:{i:0;s:5:\"rubik\";}',31,5,'admin/build/block/list','admin/build/block','Rubik','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/build/block/list/tao','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:36:\"profiles/os_demo/themes/tao/tao.info\";s:4:\"name\";s:3:\"tao\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:13:{s:4:\"core\";s:3:\"6.x\";s:11:\"description\";s:149:\"Tao is a base theme that is all about going with the flow. It takes care of key reset and utility tasks so that sub-themes can get on with their job.\";s:6:\"engine\";s:11:\"phptemplate\";s:4:\"name\";s:3:\"Tao\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:7:\"scripts\";a:1:{s:9:\"js/tao.js\";s:37:\"profiles/os_demo/themes/tao/js/tao.js\";}s:11:\"stylesheets\";a:3:{s:6:\"screen\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:10:\"drupal.css\";s:38:\"profiles/os_demo/themes/tao/drupal.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";}s:5:\"print\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";s:9:\"print.css\";s:37:\"profiles/os_demo/themes/tao/print.css\";}s:3:\"all\";a:20:{s:9:\"admin.css\";s:37:\"profiles/os_demo/themes/tao/admin.css\";s:9:\"block.css\";s:37:\"profiles/os_demo/themes/tao/block.css\";s:8:\"book.css\";s:36:\"profiles/os_demo/themes/tao/book.css\";s:11:\"comment.css\";s:39:\"profiles/os_demo/themes/tao/comment.css\";s:9:\"dblog.css\";s:37:\"profiles/os_demo/themes/tao/dblog.css\";s:12:\"defaults.css\";s:40:\"profiles/os_demo/themes/tao/defaults.css\";s:9:\"forum.css\";s:37:\"profiles/os_demo/themes/tao/forum.css\";s:8:\"help.css\";s:36:\"profiles/os_demo/themes/tao/help.css\";s:15:\"maintenance.css\";s:43:\"profiles/os_demo/themes/tao/maintenance.css\";s:8:\"node.css\";s:36:\"profiles/os_demo/themes/tao/node.css\";s:10:\"openid.css\";s:38:\"profiles/os_demo/themes/tao/openid.css\";s:8:\"poll.css\";s:36:\"profiles/os_demo/themes/tao/poll.css\";s:11:\"profile.css\";s:39:\"profiles/os_demo/themes/tao/profile.css\";s:10:\"search.css\";s:38:\"profiles/os_demo/themes/tao/search.css\";s:10:\"system.css\";s:38:\"profiles/os_demo/themes/tao/system.css\";s:16:\"system-menus.css\";s:44:\"profiles/os_demo/themes/tao/system-menus.css\";s:12:\"taxonomy.css\";s:40:\"profiles/os_demo/themes/tao/taxonomy.css\";s:11:\"tracker.css\";s:39:\"profiles/os_demo/themes/tao/tracker.css\";s:10:\"update.css\";s:38:\"profiles/os_demo/themes/tao/update.css\";s:8:\"user.css\";s:36:\"profiles/os_demo/themes/tao/user.css\";}}s:7:\"version\";s:7:\"6.x-3.1\";s:7:\"project\";s:3:\"tao\";s:9:\"datestamp\";s:10:\"1285704363\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:10:\"screenshot\";s:42:\"profiles/os_demo/themes/tao/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:3:{s:6:\"screen\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:10:\"drupal.css\";s:38:\"profiles/os_demo/themes/tao/drupal.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";}s:5:\"print\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";s:9:\"print.css\";s:37:\"profiles/os_demo/themes/tao/print.css\";}s:3:\"all\";a:20:{s:9:\"admin.css\";s:37:\"profiles/os_demo/themes/tao/admin.css\";s:9:\"block.css\";s:37:\"profiles/os_demo/themes/tao/block.css\";s:8:\"book.css\";s:36:\"profiles/os_demo/themes/tao/book.css\";s:11:\"comment.css\";s:39:\"profiles/os_demo/themes/tao/comment.css\";s:9:\"dblog.css\";s:37:\"profiles/os_demo/themes/tao/dblog.css\";s:12:\"defaults.css\";s:40:\"profiles/os_demo/themes/tao/defaults.css\";s:9:\"forum.css\";s:37:\"profiles/os_demo/themes/tao/forum.css\";s:8:\"help.css\";s:36:\"profiles/os_demo/themes/tao/help.css\";s:15:\"maintenance.css\";s:43:\"profiles/os_demo/themes/tao/maintenance.css\";s:8:\"node.css\";s:36:\"profiles/os_demo/themes/tao/node.css\";s:10:\"openid.css\";s:38:\"profiles/os_demo/themes/tao/openid.css\";s:8:\"poll.css\";s:36:\"profiles/os_demo/themes/tao/poll.css\";s:11:\"profile.css\";s:39:\"profiles/os_demo/themes/tao/profile.css\";s:10:\"search.css\";s:38:\"profiles/os_demo/themes/tao/search.css\";s:10:\"system.css\";s:38:\"profiles/os_demo/themes/tao/system.css\";s:16:\"system-menus.css\";s:44:\"profiles/os_demo/themes/tao/system-menus.css\";s:12:\"taxonomy.css\";s:40:\"profiles/os_demo/themes/tao/taxonomy.css\";s:11:\"tracker.css\";s:39:\"profiles/os_demo/themes/tao/tracker.css\";s:10:\"update.css\";s:38:\"profiles/os_demo/themes/tao/update.css\";s:8:\"user.css\";s:36:\"profiles/os_demo/themes/tao/user.css\";}}s:7:\"scripts\";a:1:{s:9:\"js/tao.js\";s:37:\"profiles/os_demo/themes/tao/js/tao.js\";}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:3:\"tao\";}',31,5,'admin/build/block/list','admin/build/block','Tao','t','',128,'','','',0,'modules/block/block.admin.inc'),('admin/build/block/list/zen','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:36:\"profiles/os_demo/themes/zen/zen.info\";s:4:\"name\";s:3:\"zen\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:15:{s:4:\"name\";s:3:\"Zen\";s:11:\"description\";s:189:\"Zen sub-themes are the ultimate starting themes for Drupal 6. Read the <a href=\"http://drupal.org/node/226507\">online docs</a> or the included README-FIRST.txt on how to create a sub-theme.\";s:10:\"screenshot\";s:56:\"profiles/os_demo/themes/zen/zen-internals/screenshot.png\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:9:{s:13:\"sidebar_first\";s:13:\"First sidebar\";s:14:\"sidebar_second\";s:14:\"Second sidebar\";s:10:\"navigation\";s:14:\"Navigation bar\";s:9:\"highlight\";s:19:\"Highlighted content\";s:11:\"content_top\";s:11:\"Content top\";s:14:\"content_bottom\";s:14:\"Content bottom\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";s:12:\"page_closure\";s:12:\"Page closure\";}s:8:\"features\";a:10:{i:0;s:4:\"logo\";i:1;s:4:\"name\";i:2;s:6:\"slogan\";i:3;s:7:\"mission\";i:4;s:17:\"node_user_picture\";i:5;s:20:\"comment_user_picture\";i:6;s:6:\"search\";i:7;s:7:\"favicon\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:8:\"settings\";a:9:{s:17:\"zen_block_editing\";s:1:\"1\";s:14:\"zen_breadcrumb\";s:3:\"yes\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";s:1:\"1\";s:23:\"zen_breadcrumb_trailing\";s:1:\"1\";s:20:\"zen_breadcrumb_title\";s:1:\"0\";s:10:\"zen_layout\";s:18:\"zen-columns-liquid\";s:20:\"zen_rebuild_registry\";s:1:\"0\";s:14:\"zen_wireframes\";s:1:\"0\";}s:7:\"plugins\";a:1:{s:6:\"panels\";a:1:{s:7:\"layouts\";s:7:\"layouts\";}}s:7:\"version\";s:7:\"6.x-2.0\";s:7:\"project\";s:3:\"zen\";s:9:\"datestamp\";s:10:\"1277583313\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:37:\"profiles/os_demo/themes/zen/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:37:\"profiles/os_demo/themes/zen/script.js\";}s:3:\"php\";s:5:\"4.3.5\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:37:\"profiles/os_demo/themes/zen/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:3:\"zen\";}',31,5,'admin/build/block/list','admin/build/block','Zen','t','',128,'','','',0,'modules/block/block.admin.inc'),('node/%/webform/components/%','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:2:{i:0;i:1;i:1;i:5;}}i:4;a:1:{s:27:\"webform_menu_component_load\";a:2:{i:0;i:1;i:1;i:5;}}}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','drupal_get_form','a:4:{i:0;s:27:\"webform_component_edit_form\";i:1;i:1;i:2;i:4;i:3;b:0;}',22,5,'node/%/webform/components','node/%','','t','',128,'','','',0,''),('admin/settings/date-time/formats/add','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:30:\"date_api_add_date_formats_form\";}',31,5,'admin/settings/date-time/formats','admin/settings/date-time','Add format','t','',128,'','Allow users to add additional date formats.','',3,'profiles/os_demo/modules/contrib/date/date_api.admin.inc'),('admin/content/taxonomy/add/vocabulary','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:1:{i:0;s:24:\"taxonomy_form_vocabulary\";}',31,5,'admin/content/taxonomy','admin/content/taxonomy','Add vocabulary','t','',128,'','','',0,'modules/taxonomy/taxonomy.admin.inc'),('admin/settings/date-time/formats/configure','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:26:\"date_api_date_formats_form\";}',31,5,'admin/settings/date-time/formats','admin/settings/date-time','Configure','t','',136,'','Allow users to configure date formats','',1,'profiles/os_demo/modules/contrib/date/date_api.admin.inc'),('admin/settings/actions/delete/%','a:1:{i:4;s:12:\"actions_load\";}','','user_access','a:1:{i:0;s:18:\"administer actions\";}','drupal_get_form','a:2:{i:0;s:26:\"system_actions_delete_form\";i:1;i:4;}',30,5,'','admin/settings/actions/delete/%','Delete action','t','',4,'','Delete an action.','',0,''),('admin/views/ajax/autocomplete/user','','','user_access','a:1:{i:0;s:14:\"access content\";}','views_ajax_autocomplete_user','a:0:{}',31,5,'','admin/views/ajax/autocomplete/user','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/views/includes/ajax.inc'),('admin/build/menu-customize/%/delete','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_delete_menu_page','a:1:{i:0;i:3;}',29,5,'','admin/build/menu-customize/%/delete','Delete menu','t','',4,'','','',0,'modules/menu/menu.admin.inc'),('admin/build/pages/edit/%','a:1:{i:4;s:23:\"page_manager_cache_load\";}','','user_access','a:1:{i:0;s:16:\"use page manager\";}','page_manager_edit_page','a:1:{i:0;i:4;}',30,5,'','admin/build/pages/edit/%','Edit','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/page_manager.admin.inc'),('node/%/webform/emails/%','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:1:{i:0;i:1;}}i:4;a:1:{s:23:\"webform_menu_email_load\";a:1:{i:0;i:1;}}}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','drupal_get_form','a:3:{i:0;s:23:\"webform_email_edit_form\";i:1;i:1;i:2;i:4;}',22,5,'node/%/webform/emails','node/%','Edit e-mail settings','t','',128,'','','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.emails.inc'),('node/%/revisions/%/view','a:2:{i:1;a:1:{s:9:\"node_load\";a:1:{i:0;i:3;}}i:3;N;}','','_node_revision_access','a:1:{i:0;i:1;}','node_show','a:3:{i:0;i:1;i:1;N;i:2;b:1;}',21,5,'','node/%/revisions/%/view','Revisions','t','',4,'','','',0,''),('node/%/webform-results/analysis/%','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:2:{i:0;i:1;i:1;i:4;}}i:4;a:1:{s:27:\"webform_menu_component_load\";a:2:{i:0;i:1;i:1;i:4;}}}','','webform_results_access','a:1:{i:0;i:1;}','webform_results_analysis','a:3:{i:0;i:1;i:1;a:0:{}i:2;i:4;}',22,5,'','node/%/webform-results/analysis/%','Analysis','t','',4,'','','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.report.inc'),('node/%/submission/%/delete','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:1:{i:0;i:1;}}i:3;a:1:{s:28:\"webform_menu_submission_load\";a:1:{i:0;i:1;}}}','','webform_submission_access','a:3:{i:0;i:1;i:1;i:3;i:2;s:6:\"delete\";}','drupal_get_form','a:3:{i:0;s:30:\"webform_submission_delete_form\";i:1;i:1;i:2;i:3;}',21,5,'node/%/submission/%','node/%/submission/%','Delete','t','',128,'','','',2,'profiles/os_demo/modules/contrib/webform/includes/webform.submissions.inc'),('admin/settings/date-time/delete/%','a:1:{i:4;N;}','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:2:{i:0;s:32:\"date_api_delete_format_type_form\";i:1;i:4;}',30,5,'','admin/settings/date-time/delete/%','Delete date format type','t','',4,'','Allow users to delete a configured date format type.','',0,'profiles/os_demo/modules/contrib/date/date_api.admin.inc'),('node/%/revisions/%/delete','a:2:{i:1;a:1:{s:9:\"node_load\";a:1:{i:0;i:3;}}i:3;N;}','','_node_revision_access','a:2:{i:0;i:1;i:1;s:6:\"delete\";}','drupal_get_form','a:2:{i:0;s:28:\"node_revision_delete_confirm\";i:1;i:1;}',21,5,'','node/%/revisions/%/delete','Delete earlier revision','t','',4,'','','',0,'modules/node/node.pages.inc'),('admin/build/path-redirect/delete/%','a:1:{i:4;s:18:\"path_redirect_load\";}','','user_access','a:1:{i:0;s:20:\"administer redirects\";}','drupal_get_form','a:2:{i:0;s:25:\"path_redirect_delete_form\";i:1;i:4;}',30,5,'','admin/build/path-redirect/delete/%','Delete redirect','t','',4,'','Delete an existing URL redirect.','',0,'profiles/os_demo/modules/contrib/path_redirect/path_redirect.admin.inc'),('node/%/submission/%/edit','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:1:{i:0;i:1;}}i:3;a:1:{s:28:\"webform_menu_submission_load\";a:1:{i:0;i:1;}}}','','webform_submission_access','a:3:{i:0;i:1;i:1;i:3;i:2;s:4:\"edit\";}','webform_submission_page','a:3:{i:0;i:1;i:1;i:3;i:2;s:4:\"form\";}',21,5,'node/%/submission/%','node/%/submission/%','Edit','t','',128,'','','',1,'profiles/os_demo/modules/contrib/webform/includes/webform.submissions.inc'),('admin/build/path-redirect/edit/%','a:1:{i:4;s:18:\"path_redirect_load\";}','','user_access','a:1:{i:0;s:20:\"administer redirects\";}','drupal_get_form','a:2:{i:0;s:23:\"path_redirect_edit_form\";i:1;i:4;}',30,5,'','admin/build/path-redirect/edit/%','Edit redirect','t','',4,'','Edit an existing URL redirect.','',0,'profiles/os_demo/modules/contrib/path_redirect/path_redirect.admin.inc'),('admin/build/features/%/recreate','a:1:{i:3;s:12:\"feature_load\";}','','user_access','a:1:{i:0;s:19:\"administer features\";}','drupal_get_form','a:2:{i:0;s:20:\"features_export_form\";i:1;i:3;}',29,5,'admin/build/features/%','admin/build/features/%','Recreate','t','',128,'','Recreate an existing feature.','',11,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('node/%/revisions/%/revert','a:2:{i:1;a:1:{s:9:\"node_load\";a:1:{i:0;i:3;}}i:3;N;}','','_node_revision_access','a:2:{i:0;i:1;i:1;s:6:\"update\";}','drupal_get_form','a:2:{i:0;s:28:\"node_revision_revert_confirm\";i:1;i:1;}',21,5,'','node/%/revisions/%/revert','Revert to earlier revision','t','',4,'','','',0,'modules/node/node.pages.inc'),('node/%/submission/%/view','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:1:{i:0;i:1;}}i:3;a:1:{s:28:\"webform_menu_submission_load\";a:1:{i:0;i:1;}}}','','webform_submission_access','a:3:{i:0;i:1;i:1;i:3;i:2;s:4:\"view\";}','webform_submission_page','a:3:{i:0;i:1;i:1;i:3;i:2;s:4:\"html\";}',21,5,'node/%/submission/%','node/%/submission/%','View','t','',136,'','','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.submissions.inc'),('admin/build/features/export/populate','','','user_access','a:1:{i:0;s:19:\"administer features\";}','features_export_build_form_populate','a:0:{}',31,5,'','admin/build/features/export/populate','Populate feature','t','',4,'','AHAH callback to populate a feature from selected components.','',0,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('admin/build/features/%/status','a:1:{i:3;s:12:\"feature_load\";}','','user_access','a:1:{i:0;s:19:\"administer features\";}','features_feature_status','a:1:{i:0;i:3;}',29,5,'','admin/build/features/%/status','Status','t','',4,'','Javascript status call back.','',0,'profiles/os_demo/modules/contrib/features/features.admin.inc'),('admin/content/node-type/blog/display/basic','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"blog\";i:2;s:5:\"basic\";}',63,6,'admin/content/node-type/blog/display','admin/content/node-type/blog','Basic','t','',136,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/display/basic','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"event\";i:2;s:5:\"basic\";}',63,6,'admin/content/node-type/event/display','admin/content/node-type/event','Basic','t','',136,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/page/display/basic','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"page\";i:2;s:5:\"basic\";}',63,6,'admin/content/node-type/page/display','admin/content/node-type/page','Basic','t','',136,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/display/basic','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"slide\";i:2;s:5:\"basic\";}',63,6,'admin/content/node-type/slide/display','admin/content/node-type/slide','Basic','t','',136,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/webform/display/basic','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:7:\"webform\";i:2;s:5:\"basic\";}',63,6,'admin/content/node-type/webform/display','admin/content/node-type/webform','Basic','t','',136,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/blog/display/rss','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"blog\";i:2;s:3:\"rss\";}',63,6,'admin/content/node-type/blog/display','admin/content/node-type/blog','RSS','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/display/rss','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"event\";i:2;s:3:\"rss\";}',63,6,'admin/content/node-type/event/display','admin/content/node-type/event','RSS','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/page/display/rss','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"page\";i:2;s:3:\"rss\";}',63,6,'admin/content/node-type/page/display','admin/content/node-type/page','RSS','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/display/rss','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"slide\";i:2;s:3:\"rss\";}',63,6,'admin/content/node-type/slide/display','admin/content/node-type/slide','RSS','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/webform/display/rss','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:7:\"webform\";i:2;s:3:\"rss\";}',63,6,'admin/content/node-type/webform/display','admin/content/node-type/webform','RSS','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/blog/display/token','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"blog\";i:2;s:5:\"token\";}',63,6,'admin/content/node-type/blog/display','admin/content/node-type/blog','Token','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/display/token','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"event\";i:2;s:5:\"token\";}',63,6,'admin/content/node-type/event/display','admin/content/node-type/event','Token','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/page/display/token','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:4:\"page\";i:2;s:5:\"token\";}',63,6,'admin/content/node-type/page/display','admin/content/node-type/page','Token','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/display/token','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:5:\"slide\";i:2;s:5:\"token\";}',63,6,'admin/content/node-type/slide/display','admin/content/node-type/slide','Token','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/webform/display/token','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:29:\"content_display_overview_form\";i:1;s:7:\"webform\";i:2;s:5:\"token\";}',63,6,'admin/content/node-type/webform/display','admin/content/node-type/webform','Token','t','',128,'','','',1,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/fields/field_event_date','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:23:\"content_field_edit_form\";i:1;s:5:\"event\";i:2;s:16:\"field_event_date\";}',63,6,'admin/content/node-type/event/fields','admin/content/node-type/event','Date/time','t','',128,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('node/%/webform/emails/%/delete','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:1:{i:0;i:1;}}i:4;a:1:{s:23:\"webform_menu_email_load\";a:1:{i:0;i:1;}}}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','drupal_get_form','a:3:{i:0;s:25:\"webform_email_delete_form\";i:1;i:1;i:2;i:4;}',45,6,'node/%/webform/emails/%','node/%','Delete e-mail settings','t','',128,'','','',0,'profiles/os_demo/modules/contrib/webform/includes/webform.emails.inc'),('admin/content/node-type/blog/fields/field_blog_images','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:23:\"content_field_edit_form\";i:1;s:4:\"blog\";i:2;s:17:\"field_blog_images\";}',63,6,'admin/content/node-type/blog/fields','admin/content/node-type/blog','Image(s)','t','',128,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/fields/field_event_image','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:23:\"content_field_edit_form\";i:1;s:5:\"event\";i:2;s:17:\"field_event_image\";}',63,6,'admin/content/node-type/event/fields','admin/content/node-type/event','Image(s)','t','',128,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/fields/field_slide_link','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:23:\"content_field_edit_form\";i:1;s:5:\"slide\";i:2;s:16:\"field_slide_link\";}',63,6,'admin/content/node-type/slide/fields','admin/content/node-type/slide','Link','t','',128,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/fields/field_slide_image','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:23:\"content_field_edit_form\";i:1;s:5:\"slide\";i:2;s:17:\"field_slide_image\";}',63,6,'admin/content/node-type/slide/fields','admin/content/node-type/slide','Slide image','t','',128,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/nodequeue/%/view/%','a:2:{i:3;s:14:\"nodequeue_load\";i:5;s:13:\"subqueue_load\";}','','nodequeue_queue_access','a:2:{i:0;i:3;i:1;i:5;}','nodequeue_admin_view','a:2:{i:0;i:3;i:1;i:5;}',58,6,'admin/content/nodequeue/%','admin/content/nodequeue/%','View','t','',136,'','','',-10,''),('admin/build/pages/%/operation/%','a:2:{i:3;s:14:\"ctools_js_load\";i:5;s:23:\"page_manager_cache_load\";}','','user_access','a:1:{i:0;s:16:\"use page manager\";}','page_manager_edit_page_operation','a:2:{i:0;i:3;i:1;i:5;}',58,6,'','admin/build/pages/%/operation/%','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/page_manager.admin.inc'),('admin/build/pages/%/enable/%','a:2:{i:3;s:14:\"ctools_js_load\";i:5;s:23:\"page_manager_cache_load\";}','','user_access','a:1:{i:0;s:16:\"use page manager\";}','page_manager_enable_page','a:3:{i:0;b:0;i:1;i:3;i:2;i:5;}',58,6,'','admin/build/pages/%/enable/%','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/page_manager.admin.inc'),('admin/build/pages/%/disable/%','a:2:{i:3;s:14:\"ctools_js_load\";i:5;s:23:\"page_manager_cache_load\";}','','user_access','a:1:{i:0;s:16:\"use page manager\";}','page_manager_enable_page','a:3:{i:0;b:1;i:1;i:3;i:2;i:5;}',58,6,'','admin/build/pages/%/disable/%','','t','',4,'','','',0,'profiles/os_demo/modules/contrib/ctools/page_manager/page_manager.admin.inc'),('admin/content/taxonomy/%/add/term','a:1:{i:3;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','taxonomy_add_term_page','a:1:{i:0;i:3;}',59,6,'admin/content/taxonomy/%','admin/content/taxonomy/%','Add term','t','',128,'','','',0,'modules/taxonomy/taxonomy.admin.inc'),('admin/build/menu/item/%/delete','a:1:{i:4;s:14:\"menu_link_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_item_delete_page','a:1:{i:0;i:4;}',61,6,'','admin/build/menu/item/%/delete','Delete menu item','t','',4,'','','',0,'modules/menu/menu.admin.inc'),('node/%/webform/components/%/delete','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:2:{i:0;i:1;i:1;i:5;}}i:4;a:1:{s:27:\"webform_menu_component_load\";a:2:{i:0;i:1;i:1;i:5;}}}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','drupal_get_form','a:3:{i:0;s:29:\"webform_component_delete_form\";i:1;i:1;i:2;i:4;}',45,6,'node/%/webform/components/%','node/%','','t','',128,'','','',0,''),('admin/content/nodequeue/%/clear/%','a:2:{i:3;s:14:\"nodequeue_load\";i:5;s:13:\"subqueue_load\";}','','nodequeue_queue_access','a:2:{i:0;i:3;i:1;i:5;}','drupal_get_form','a:3:{i:0;s:23:\"nodequeue_clear_confirm\";i:1;i:3;i:2;i:5;}',58,6,'','admin/content/nodequeue/%/clear/%','Clear','t','',4,'','','',0,''),('admin/content/taxonomy/edit/vocabulary/%','a:1:{i:5;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','taxonomy_admin_vocabulary_edit','a:1:{i:0;i:5;}',62,6,'','admin/content/taxonomy/edit/vocabulary/%','Edit vocabulary','t','',4,'','','',0,'modules/taxonomy/taxonomy.admin.inc'),('admin/build/menu/item/%/reset','a:1:{i:4;s:14:\"menu_link_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:23:\"menu_reset_item_confirm\";i:1;i:4;}',61,6,'','admin/build/menu/item/%/reset','Reset menu item','t','',4,'','','',0,'modules/menu/menu.admin.inc'),('node/%/webform/components/%/clone','a:2:{i:1;a:1:{s:17:\"webform_menu_load\";a:2:{i:0;i:1;i:1;i:5;}}i:4;a:1:{s:27:\"webform_menu_component_load\";a:2:{i:0;i:1;i:1;i:5;}}}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','drupal_get_form','a:4:{i:0;s:27:\"webform_component_edit_form\";i:1;i:1;i:2;i:4;i:3;b:1;}',45,6,'node/%/webform/components/%','node/%','','t','',128,'','','',0,''),('admin/build/menu/item/%/edit','a:1:{i:4;s:14:\"menu_link_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:4:{i:0;s:14:\"menu_edit_item\";i:1;s:4:\"edit\";i:2;i:4;i:3;N;}',61,6,'','admin/build/menu/item/%/edit','Edit menu item','t','',4,'','','',0,'modules/menu/menu.admin.inc'),('admin/settings/date-time/formats/delete/%','a:1:{i:5;N;}','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:2:{i:0;s:27:\"date_api_delete_format_form\";i:1;i:5;}',62,6,'','admin/settings/date-time/formats/delete/%','Delete date format','t','',4,'','Allow users to delete a configured date format.','',0,'profiles/os_demo/modules/contrib/date/date_api.admin.inc'),('admin/settings/wysiwyg/profile/%/edit','a:1:{i:4;s:20:\"wysiwyg_profile_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:2:{i:0;s:20:\"wysiwyg_profile_form\";i:1;i:4;}',61,6,'admin/settings/wysiwyg/profile/%wysiwyg_profile','admin/settings/wysiwyg/profile','Edit','t','',128,'','','',0,'profiles/os_demo/modules/contrib/wysiwyg/wysiwyg.admin.inc'),('admin/settings/wysiwyg/profile/%/delete','a:1:{i:4;s:20:\"wysiwyg_profile_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:2:{i:0;s:30:\"wysiwyg_profile_delete_confirm\";i:1;i:4;}',61,6,'admin/settings/wysiwyg/profile/%wysiwyg_profile','admin/settings/wysiwyg/profile','Remove','t','',128,'','','',10,'profiles/os_demo/modules/contrib/wysiwyg/wysiwyg.admin.inc'),('admin/content/node-type/blog/fields/field_blog_images/remove','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:25:\"content_field_remove_form\";i:1;s:4:\"blog\";i:2;s:17:\"field_blog_images\";}',127,7,'','admin/content/node-type/blog/fields/field_blog_images/remove','Remove field','t','',4,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/fields/field_event_date/remove','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:25:\"content_field_remove_form\";i:1;s:5:\"event\";i:2;s:16:\"field_event_date\";}',127,7,'','admin/content/node-type/event/fields/field_event_date/remove','Remove field','t','',4,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/event/fields/field_event_image/remove','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:25:\"content_field_remove_form\";i:1;s:5:\"event\";i:2;s:17:\"field_event_image\";}',127,7,'','admin/content/node-type/event/fields/field_event_image/remove','Remove field','t','',4,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/fields/field_slide_image/remove','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:25:\"content_field_remove_form\";i:1;s:5:\"slide\";i:2;s:17:\"field_slide_image\";}',127,7,'','admin/content/node-type/slide/fields/field_slide_image/remove','Remove field','t','',4,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/node-type/slide/fields/field_slide_link/remove','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:3:{i:0;s:25:\"content_field_remove_form\";i:1;s:5:\"slide\";i:2;s:16:\"field_slide_link\";}',127,7,'','admin/content/node-type/slide/fields/field_slide_link/remove','Remove field','t','',4,'','','',0,'profiles/os_demo/modules/contrib/cck/includes/content.admin.inc'),('admin/content/nodequeue/%/add/%/%','a:3:{i:3;s:14:\"nodequeue_load\";i:5;s:13:\"subqueue_load\";i:6;s:9:\"node_load\";}','','nodequeue_node_and_queue_access','a:3:{i:0;i:6;i:1;i:3;i:2;i:5;}','nodequeue_admin_add_node','a:3:{i:0;i:3;i:1;i:5;i:2;i:6;}',116,7,'','admin/content/nodequeue/%/add/%/%','','t','',4,'','','',0,''),('admin/content/nodequeue/%/remove-node/%/%','a:3:{i:3;s:14:\"nodequeue_load\";i:5;s:13:\"subqueue_load\";i:6;s:9:\"node_load\";}','','nodequeue_node_and_queue_access','a:3:{i:0;i:6;i:1;i:3;i:2;i:5;}','nodequeue_admin_remove_node','a:3:{i:0;i:3;i:1;i:5;i:2;i:6;}',116,7,'','admin/content/nodequeue/%/remove-node/%/%','','t','',4,'','','',0,'');
/*!40000 ALTER TABLE `menu_router` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node`
--

DROP TABLE IF EXISTS `node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node` (
  `nid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL DEFAULT '',
  `language` varchar(12) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `uid` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `created` int(11) NOT NULL DEFAULT '0',
  `changed` int(11) NOT NULL DEFAULT '0',
  `comment` int(11) NOT NULL DEFAULT '0',
  `promote` int(11) NOT NULL DEFAULT '0',
  `moderate` int(11) NOT NULL DEFAULT '0',
  `sticky` int(11) NOT NULL DEFAULT '0',
  `tnid` int(10) unsigned NOT NULL DEFAULT '0',
  `translate` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`),
  UNIQUE KEY `vid` (`vid`),
  KEY `node_changed` (`changed`),
  KEY `node_created` (`created`),
  KEY `node_moderate` (`moderate`),
  KEY `node_promote_status` (`promote`,`status`),
  KEY `node_status_type` (`status`,`type`,`nid`),
  KEY `node_title_type` (`title`,`type`(4)),
  KEY `node_type` (`type`(4)),
  KEY `uid` (`uid`),
  KEY `tnid` (`tnid`),
  KEY `translate` (`translate`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node`
--

LOCK TABLES `node` WRITE;
/*!40000 ALTER TABLE `node` DISABLE KEYS */;
INSERT INTO `node` VALUES (1,1,'page','','Welcome',1,1,1285794141,1285794141,0,0,0,0,0,0),(2,2,'page','','About OpenSourcery',1,1,1285794141,1285794141,0,0,0,0,0,0),(3,3,'webform','','Contact Us',1,1,1285794141,1285794141,0,0,0,0,0,0);
/*!40000 ALTER TABLE `node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_access`
--

DROP TABLE IF EXISTS `node_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_access` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  `realm` varchar(255) NOT NULL DEFAULT '',
  `grant_view` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grant_update` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grant_delete` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`,`gid`,`realm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_access`
--

LOCK TABLES `node_access` WRITE;
/*!40000 ALTER TABLE `node_access` DISABLE KEYS */;
INSERT INTO `node_access` VALUES (0,0,'all',1,0,0);
/*!40000 ALTER TABLE `node_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_comment_statistics`
--

DROP TABLE IF EXISTS `node_comment_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_comment_statistics` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_timestamp` int(11) NOT NULL DEFAULT '0',
  `last_comment_name` varchar(60) DEFAULT NULL,
  `last_comment_uid` int(11) NOT NULL DEFAULT '0',
  `comment_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`),
  KEY `node_comment_timestamp` (`last_comment_timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_comment_statistics`
--

LOCK TABLES `node_comment_statistics` WRITE;
/*!40000 ALTER TABLE `node_comment_statistics` DISABLE KEYS */;
INSERT INTO `node_comment_statistics` VALUES (1,1285794141,NULL,1,0),(2,1285794141,NULL,1,0),(3,1285794141,NULL,1,0);
/*!40000 ALTER TABLE `node_comment_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_counter`
--

DROP TABLE IF EXISTS `node_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_counter` (
  `nid` int(11) NOT NULL DEFAULT '0',
  `totalcount` bigint(20) unsigned NOT NULL DEFAULT '0',
  `daycount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_counter`
--

LOCK TABLES `node_counter` WRITE;
/*!40000 ALTER TABLE `node_counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `node_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_revisions`
--

DROP TABLE IF EXISTS `node_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_revisions` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `body` longtext NOT NULL,
  `teaser` longtext NOT NULL,
  `log` longtext NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `format` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_revisions`
--

LOCK TABLES `node_revisions` WRITE;
/*!40000 ALTER TABLE `node_revisions` DISABLE KEYS */;
INSERT INTO `node_revisions` VALUES (1,1,1,'Welcome','This is the OpenSourcery default Drupal installation demo server. Have a look around.','','',1285794141,0),(2,2,1,'About OpenSourcery','Placeholder (Edit me!)','','',1285794141,0),(3,3,1,'Contact Us','','','',1285794141,0);
/*!40000 ALTER TABLE `node_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_type`
--

DROP TABLE IF EXISTS `node_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_type` (
  `type` varchar(32) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `module` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `help` mediumtext NOT NULL,
  `has_title` tinyint(3) unsigned NOT NULL,
  `title_label` varchar(255) NOT NULL DEFAULT '',
  `has_body` tinyint(3) unsigned NOT NULL,
  `body_label` varchar(255) NOT NULL DEFAULT '',
  `min_word_count` smallint(5) unsigned NOT NULL,
  `custom` tinyint(4) NOT NULL DEFAULT '0',
  `modified` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `orig_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_type`
--

LOCK TABLES `node_type` WRITE;
/*!40000 ALTER TABLE `node_type` DISABLE KEYS */;
INSERT INTO `node_type` VALUES ('webform','Webform','node','Create a new form or questionnaire accessible to users. Submission results and statistics are recorded and accessible to privileged users.','',1,'Title',1,'Body',0,1,1,0,'webform'),('page','Page','features','A <em>page</em> is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.','',1,'Title',1,'Body',0,0,0,1,'page'),('blog','Blog post','features','','',1,'Title',1,'Body',0,0,0,1,'blog'),('event','Event','features','','',1,'Title',1,'Details',0,0,0,1,'event'),('slide','Slide','features','An image to be used in the homepage slideshow.','',1,'Headline',1,'Description',0,0,0,1,'slide');
/*!40000 ALTER TABLE `node_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodequeue_nodes`
--

DROP TABLE IF EXISTS `nodequeue_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodequeue_nodes` (
  `qid` int(10) unsigned NOT NULL,
  `sqid` int(10) unsigned NOT NULL,
  `nid` int(10) unsigned DEFAULT NULL,
  `position` int(10) unsigned DEFAULT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `nodequeue_nodes_sqid_idx` (`sqid`,`position`),
  KEY `nodequeue_subqueue_nid_idx` (`nid`),
  KEY `nodequeue_nodes_qid_nid_idx` (`qid`,`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodequeue_nodes`
--

LOCK TABLES `nodequeue_nodes` WRITE;
/*!40000 ALTER TABLE `nodequeue_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `nodequeue_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodequeue_queue`
--

DROP TABLE IF EXISTS `nodequeue_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodequeue_queue` (
  `qid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subqueue_title` varchar(255) NOT NULL,
  `size` int(11) DEFAULT '0',
  `link` varchar(40) DEFAULT NULL,
  `link_remove` varchar(40) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `show_in_ui` tinyint(4) DEFAULT '1',
  `show_in_tab` tinyint(4) DEFAULT '1',
  `show_in_links` tinyint(4) DEFAULT '1',
  `reference` varchar(255) DEFAULT '0',
  `reverse` tinyint(4) DEFAULT NULL,
  `i18n` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`qid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodequeue_queue`
--

LOCK TABLES `nodequeue_queue` WRITE;
/*!40000 ALTER TABLE `nodequeue_queue` DISABLE KEYS */;
INSERT INTO `nodequeue_queue` VALUES (1,'Homepage Slideshow','',0,'Add to slideshow','Remove from slideshow','nodequeue',1,1,1,'0',0,1);
/*!40000 ALTER TABLE `nodequeue_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodequeue_roles`
--

DROP TABLE IF EXISTS `nodequeue_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodequeue_roles` (
  `qid` bigint(20) unsigned NOT NULL,
  `rid` bigint(20) unsigned NOT NULL,
  KEY `nodequeue_roles_qid_idx` (`qid`),
  KEY `nodequeue_roles_rid_idx` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodequeue_roles`
--

LOCK TABLES `nodequeue_roles` WRITE;
/*!40000 ALTER TABLE `nodequeue_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `nodequeue_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodequeue_subqueue`
--

DROP TABLE IF EXISTS `nodequeue_subqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodequeue_subqueue` (
  `sqid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qid` int(10) unsigned NOT NULL,
  `reference` varchar(255) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  PRIMARY KEY (`sqid`),
  KEY `nodequeue_subqueue_qid_idx` (`qid`),
  KEY `nodequeue_subqueue_reference_idx` (`reference`),
  KEY `nodequeue_subqueue_title_idx` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodequeue_subqueue`
--

LOCK TABLES `nodequeue_subqueue` WRITE;
/*!40000 ALTER TABLE `nodequeue_subqueue` DISABLE KEYS */;
INSERT INTO `nodequeue_subqueue` VALUES (1,1,'1','Homepage Slideshow');
/*!40000 ALTER TABLE `nodequeue_subqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodequeue_types`
--

DROP TABLE IF EXISTS `nodequeue_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodequeue_types` (
  `qid` bigint(20) unsigned NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  KEY `nodequeue_types_qid_idx` (`qid`),
  KEY `nodequeue_types_type_idx` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodequeue_types`
--

LOCK TABLES `nodequeue_types` WRITE;
/*!40000 ALTER TABLE `nodequeue_types` DISABLE KEYS */;
INSERT INTO `nodequeue_types` VALUES (1,'slide');
/*!40000 ALTER TABLE `nodequeue_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_manager_handlers`
--

DROP TABLE IF EXISTS `page_manager_handlers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_manager_handlers` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `task` varchar(64) DEFAULT NULL,
  `subtask` varchar(64) NOT NULL DEFAULT '',
  `handler` varchar(64) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `conf` longtext NOT NULL,
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`name`),
  KEY `fulltask` (`task`,`subtask`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_manager_handlers`
--

LOCK TABLES `page_manager_handlers` WRITE;
/*!40000 ALTER TABLE `page_manager_handlers` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_manager_handlers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_manager_pages`
--

DROP TABLE IF EXISTS `page_manager_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_manager_pages` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `task` varchar(64) DEFAULT 'page',
  `admin_title` varchar(255) DEFAULT NULL,
  `admin_description` longtext,
  `path` varchar(255) DEFAULT NULL,
  `access` longtext NOT NULL,
  `menu` longtext NOT NULL,
  `arguments` longtext NOT NULL,
  `conf` longtext NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `name` (`name`),
  KEY `task` (`task`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_manager_pages`
--

LOCK TABLES `page_manager_pages` WRITE;
/*!40000 ALTER TABLE `page_manager_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_manager_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_manager_weights`
--

DROP TABLE IF EXISTS `page_manager_weights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_manager_weights` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `weights` (`name`,`weight`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_manager_weights`
--

LOCK TABLES `page_manager_weights` WRITE;
/*!40000 ALTER TABLE `page_manager_weights` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_manager_weights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `path_redirect`
--

DROP TABLE IF EXISTS `path_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `path_redirect` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `redirect` varchar(255) NOT NULL,
  `query` varchar(255) DEFAULT NULL,
  `fragment` varchar(50) DEFAULT NULL,
  `language` varchar(12) NOT NULL DEFAULT '',
  `type` smallint(6) NOT NULL,
  `last_used` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  UNIQUE KEY `source_language` (`source`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `path_redirect`
--

LOCK TABLES `path_redirect` WRITE;
/*!40000 ALTER TABLE `path_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `path_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL DEFAULT '0',
  `perm` longtext,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (14,2,'access comments, access content, post comments, post comments without approval, show format selection for nodes, show format selection for comments, show format selection for blocks, show format tips, show more format tips link, collapsible format selection, collapse format fieldset by default',0),(13,1,'access content, show format selection for nodes, show format selection for comments, show format selection for blocks, show format tips, show more format tips link, collapsible format selection, collapse format fieldset by default, access comments, post comments, post comments without approval',0),(15,3,', create page content, delete any page content, edit any page content, administer comments, create event content, delete any event content, delete own event content, edit any event content, edit own event content',0),(16,4,', create page content, delete own page content, edit any page content, administer comments, create event content, delete any event content, delete own event content, edit any event content, edit own event content',0);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`rid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'anonymous user'),(2,'authenticated user'),(3,'administrator'),(4,'site editor');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semaphore`
--

DROP TABLE IF EXISTS `semaphore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semaphore` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `expire` double NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semaphore`
--

LOCK TABLES `semaphore` WRITE;
/*!40000 ALTER TABLE `semaphore` DISABLE KEYS */;
/*!40000 ALTER TABLE `semaphore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system`
--

DROP TABLE IF EXISTS `system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system` (
  `filename` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `owner` varchar(255) NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '0',
  `throttle` tinyint(4) NOT NULL DEFAULT '0',
  `bootstrap` int(11) NOT NULL DEFAULT '0',
  `schema_version` smallint(6) NOT NULL DEFAULT '-1',
  `weight` int(11) NOT NULL DEFAULT '0',
  `info` text,
  PRIMARY KEY (`filename`),
  KEY `modules` (`type`(12),`status`,`weight`,`filename`),
  KEY `bootstrap` (`type`(12),`status`,`bootstrap`,`weight`,`filename`),
  KEY `type_name` (`type`(12),`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system`
--

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` VALUES ('profiles/os_demo/themes/tao/tao.info','tao','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:13:{s:4:\"core\";s:3:\"6.x\";s:11:\"description\";s:149:\"Tao is a base theme that is all about going with the flow. It takes care of key reset and utility tasks so that sub-themes can get on with their job.\";s:6:\"engine\";s:11:\"phptemplate\";s:4:\"name\";s:3:\"Tao\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:7:\"scripts\";a:1:{s:9:\"js/tao.js\";s:37:\"profiles/os_demo/themes/tao/js/tao.js\";}s:11:\"stylesheets\";a:3:{s:6:\"screen\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:10:\"drupal.css\";s:38:\"profiles/os_demo/themes/tao/drupal.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";}s:5:\"print\";a:3:{s:9:\"reset.css\";s:37:\"profiles/os_demo/themes/tao/reset.css\";s:8:\"base.css\";s:36:\"profiles/os_demo/themes/tao/base.css\";s:9:\"print.css\";s:37:\"profiles/os_demo/themes/tao/print.css\";}s:3:\"all\";a:20:{s:9:\"admin.css\";s:37:\"profiles/os_demo/themes/tao/admin.css\";s:9:\"block.css\";s:37:\"profiles/os_demo/themes/tao/block.css\";s:8:\"book.css\";s:36:\"profiles/os_demo/themes/tao/book.css\";s:11:\"comment.css\";s:39:\"profiles/os_demo/themes/tao/comment.css\";s:9:\"dblog.css\";s:37:\"profiles/os_demo/themes/tao/dblog.css\";s:12:\"defaults.css\";s:40:\"profiles/os_demo/themes/tao/defaults.css\";s:9:\"forum.css\";s:37:\"profiles/os_demo/themes/tao/forum.css\";s:8:\"help.css\";s:36:\"profiles/os_demo/themes/tao/help.css\";s:15:\"maintenance.css\";s:43:\"profiles/os_demo/themes/tao/maintenance.css\";s:8:\"node.css\";s:36:\"profiles/os_demo/themes/tao/node.css\";s:10:\"openid.css\";s:38:\"profiles/os_demo/themes/tao/openid.css\";s:8:\"poll.css\";s:36:\"profiles/os_demo/themes/tao/poll.css\";s:11:\"profile.css\";s:39:\"profiles/os_demo/themes/tao/profile.css\";s:10:\"search.css\";s:38:\"profiles/os_demo/themes/tao/search.css\";s:10:\"system.css\";s:38:\"profiles/os_demo/themes/tao/system.css\";s:16:\"system-menus.css\";s:44:\"profiles/os_demo/themes/tao/system-menus.css\";s:12:\"taxonomy.css\";s:40:\"profiles/os_demo/themes/tao/taxonomy.css\";s:11:\"tracker.css\";s:39:\"profiles/os_demo/themes/tao/tracker.css\";s:10:\"update.css\";s:38:\"profiles/os_demo/themes/tao/update.css\";s:8:\"user.css\";s:36:\"profiles/os_demo/themes/tao/user.css\";}}s:7:\"version\";s:7:\"6.x-3.1\";s:7:\"project\";s:3:\"tao\";s:9:\"datestamp\";s:10:\"1285704363\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:10:\"screenshot\";s:42:\"profiles/os_demo/themes/tao/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/themes/zen/zen.info','zen','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:15:{s:4:\"name\";s:3:\"Zen\";s:11:\"description\";s:189:\"Zen sub-themes are the ultimate starting themes for Drupal 6. Read the <a href=\"http://drupal.org/node/226507\">online docs</a> or the included README-FIRST.txt on how to create a sub-theme.\";s:10:\"screenshot\";s:56:\"profiles/os_demo/themes/zen/zen-internals/screenshot.png\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:9:{s:13:\"sidebar_first\";s:13:\"First sidebar\";s:14:\"sidebar_second\";s:14:\"Second sidebar\";s:10:\"navigation\";s:14:\"Navigation bar\";s:9:\"highlight\";s:19:\"Highlighted content\";s:11:\"content_top\";s:11:\"Content top\";s:14:\"content_bottom\";s:14:\"Content bottom\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";s:12:\"page_closure\";s:12:\"Page closure\";}s:8:\"features\";a:10:{i:0;s:4:\"logo\";i:1;s:4:\"name\";i:2;s:6:\"slogan\";i:3;s:7:\"mission\";i:4;s:17:\"node_user_picture\";i:5;s:20:\"comment_user_picture\";i:6;s:6:\"search\";i:7;s:7:\"favicon\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:8:\"settings\";a:9:{s:17:\"zen_block_editing\";s:1:\"1\";s:14:\"zen_breadcrumb\";s:3:\"yes\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";s:1:\"1\";s:23:\"zen_breadcrumb_trailing\";s:1:\"1\";s:20:\"zen_breadcrumb_title\";s:1:\"0\";s:10:\"zen_layout\";s:18:\"zen-columns-liquid\";s:20:\"zen_rebuild_registry\";s:1:\"0\";s:14:\"zen_wireframes\";s:1:\"0\";}s:7:\"plugins\";a:1:{s:6:\"panels\";a:1:{s:7:\"layouts\";s:7:\"layouts\";}}s:7:\"version\";s:7:\"6.x-2.0\";s:7:\"project\";s:3:\"zen\";s:9:\"datestamp\";s:10:\"1277583313\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:37:\"profiles/os_demo/themes/zen/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:37:\"profiles/os_demo/themes/zen/script.js\";}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/themes/doune/doune.info','doune','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:14:{s:4:\"name\";s:5:\"Doune\";s:11:\"description\";s:24:\"OpenSourcery base theme.\";s:10:\"screenshot\";s:44:\"profiles/os_demo/themes/doune/screenshot.png\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:3:\"zen\";s:7:\"version\";s:7:\"6.x-0.2\";s:11:\"stylesheets\";a:3:{s:3:\"all\";a:37:{s:9:\"admin.css\";s:39:\"profiles/os_demo/themes/doune/admin.css\";s:9:\"block.css\";s:39:\"profiles/os_demo/themes/doune/block.css\";s:8:\"book.css\";s:38:\"profiles/os_demo/themes/doune/book.css\";s:11:\"comment.css\";s:41:\"profiles/os_demo/themes/doune/comment.css\";s:9:\"dblog.css\";s:39:\"profiles/os_demo/themes/doune/dblog.css\";s:12:\"defaults.css\";s:42:\"profiles/os_demo/themes/doune/defaults.css\";s:9:\"forum.css\";s:39:\"profiles/os_demo/themes/doune/forum.css\";s:8:\"help.css\";s:38:\"profiles/os_demo/themes/doune/help.css\";s:15:\"maintenance.css\";s:45:\"profiles/os_demo/themes/doune/maintenance.css\";s:8:\"node.css\";s:38:\"profiles/os_demo/themes/doune/node.css\";s:10:\"openid.css\";s:40:\"profiles/os_demo/themes/doune/openid.css\";s:8:\"poll.css\";s:38:\"profiles/os_demo/themes/doune/poll.css\";s:11:\"profile.css\";s:41:\"profiles/os_demo/themes/doune/profile.css\";s:10:\"search.css\";s:40:\"profiles/os_demo/themes/doune/search.css\";s:10:\"system.css\";s:40:\"profiles/os_demo/themes/doune/system.css\";s:16:\"system-menus.css\";s:46:\"profiles/os_demo/themes/doune/system-menus.css\";s:12:\"taxonomy.css\";s:42:\"profiles/os_demo/themes/doune/taxonomy.css\";s:11:\"tracker.css\";s:41:\"profiles/os_demo/themes/doune/tracker.css\";s:10:\"update.css\";s:40:\"profiles/os_demo/themes/doune/update.css\";s:8:\"user.css\";s:38:\"profiles/os_demo/themes/doune/user.css\";s:18:\"css/html-reset.css\";s:48:\"profiles/os_demo/themes/doune/css/html-reset.css\";s:18:\"css/wireframes.css\";s:48:\"profiles/os_demo/themes/doune/css/wireframes.css\";s:20:\"css/layout-fixed.css\";s:50:\"profiles/os_demo/themes/doune/css/layout-fixed.css\";s:24:\"css/page-backgrounds.css\";s:54:\"profiles/os_demo/themes/doune/css/page-backgrounds.css\";s:12:\"css/tabs.css\";s:42:\"profiles/os_demo/themes/doune/css/tabs.css\";s:16:\"css/messages.css\";s:46:\"profiles/os_demo/themes/doune/css/messages.css\";s:13:\"css/pages.css\";s:43:\"profiles/os_demo/themes/doune/css/pages.css\";s:21:\"css/block-editing.css\";s:51:\"profiles/os_demo/themes/doune/css/block-editing.css\";s:14:\"css/blocks.css\";s:44:\"profiles/os_demo/themes/doune/css/blocks.css\";s:18:\"css/navigation.css\";s:48:\"profiles/os_demo/themes/doune/css/navigation.css\";s:21:\"css/panels-styles.css\";s:51:\"profiles/os_demo/themes/doune/css/panels-styles.css\";s:20:\"css/views-styles.css\";s:50:\"profiles/os_demo/themes/doune/css/views-styles.css\";s:13:\"css/nodes.css\";s:43:\"profiles/os_demo/themes/doune/css/nodes.css\";s:16:\"css/comments.css\";s:46:\"profiles/os_demo/themes/doune/css/comments.css\";s:13:\"css/forms.css\";s:43:\"profiles/os_demo/themes/doune/css/forms.css\";s:14:\"css/fields.css\";s:44:\"profiles/os_demo/themes/doune/css/fields.css\";s:12:\"css/type.css\";s:42:\"profiles/os_demo/themes/doune/css/type.css\";}s:6:\"screen\";a:1:{s:14:\"css/drupal.css\";s:44:\"profiles/os_demo/themes/doune/css/drupal.css\";}s:5:\"print\";a:1:{s:13:\"css/print.css\";s:43:\"profiles/os_demo/themes/doune/css/print.css\";}}s:23:\"conditional-stylesheets\";a:2:{s:5:\"if IE\";a:1:{s:3:\"all\";a:1:{i:0;s:10:\"css/ie.css\";}}s:11:\"if lte IE 6\";a:1:{s:3:\"all\";a:1:{i:0;s:11:\"css/ie6.css\";}}}s:7:\"scripts\";a:1:{s:21:\"js/search-box-text.js\";s:51:\"profiles/os_demo/themes/doune/js/search-box-text.js\";}s:7:\"regions\";a:10:{s:13:\"sidebar_first\";s:13:\"First sidebar\";s:14:\"sidebar_second\";s:14:\"Second sidebar\";s:10:\"navigation\";s:14:\"Navigation bar\";s:9:\"highlight\";s:19:\"Highlighted content\";s:11:\"content_top\";s:11:\"Content top\";s:14:\"content_bottom\";s:14:\"Content bottom\";s:6:\"header\";s:6:\"Header\";s:10:\"postscript\";s:10:\"Postscript\";s:6:\"footer\";s:6:\"Footer\";s:12:\"page_closure\";s:12:\"Page closure\";}s:8:\"features\";a:10:{i:0;s:4:\"logo\";i:1;s:4:\"name\";i:2;s:6:\"slogan\";i:3;s:7:\"mission\";i:4;s:17:\"node_user_picture\";i:5;s:20:\"comment_user_picture\";i:6;s:6:\"search\";i:7;s:7:\"favicon\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:8:\"settings\";a:8:{s:17:\"zen_block_editing\";s:1:\"1\";s:14:\"zen_breadcrumb\";s:3:\"yes\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";s:1:\"1\";s:23:\"zen_breadcrumb_trailing\";s:1:\"1\";s:20:\"zen_breadcrumb_title\";s:1:\"0\";s:20:\"zen_rebuild_registry\";s:1:\"1\";s:14:\"zen_wireframes\";s:1:\"0\";}s:3:\"php\";s:5:\"4.3.5\";s:6:\"engine\";s:11:\"phptemplate\";}'),('profiles/os_demo/themes/rubik/rubik.info','rubik','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:14:{s:4:\"name\";s:5:\"Rubik\";s:11:\"description\";s:18:\"Clean admin theme.\";s:10:\"base theme\";s:3:\"tao\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"scripts\";a:1:{s:11:\"js/rubik.js\";s:41:\"profiles/os_demo/themes/rubik/js/rubik.js\";}s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:3:{s:8:\"core.css\";s:38:\"profiles/os_demo/themes/rubik/core.css\";s:9:\"icons.css\";s:39:\"profiles/os_demo/themes/rubik/icons.css\";s:9:\"style.css\";s:39:\"profiles/os_demo/themes/rubik/style.css\";}}s:7:\"version\";s:13:\"6.x-3.0-beta2\";s:7:\"project\";s:5:\"rubik\";s:9:\"datestamp\";s:10:\"1285709466\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:10:\"screenshot\";s:44:\"profiles/os_demo/themes/rubik/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('themes/garland/minnelli/minnelli.info','minnelli','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:14:{s:4:\"name\";s:8:\"Minnelli\";s:11:\"description\";s:56:\"Tableless, recolorable, multi-column, fixed width theme.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:7:\"garland\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/garland/minnelli/script.js\";}s:10:\"screenshot\";s:38:\"themes/garland/minnelli/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";s:6:\"engine\";s:11:\"phptemplate\";}'),('themes/garland/garland.info','garland','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:13:{s:4:\"name\";s:7:\"Garland\";s:11:\"description\";s:66:\"Tableless, recolorable, multi-column, fluid width theme (default).\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:24:\"themes/garland/script.js\";}s:10:\"screenshot\";s:29:\"themes/garland/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('themes/chameleon/marvin/marvin.info','marvin','theme','',0,0,0,-1,0,'a:13:{s:4:\"name\";s:6:\"Marvin\";s:11:\"description\";s:31:\"Boxy tabled theme in all grays.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:10:\"base theme\";s:9:\"chameleon\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/chameleon/marvin/script.js\";}s:10:\"screenshot\";s:38:\"themes/chameleon/marvin/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('themes/chameleon/chameleon.info','chameleon','theme','themes/chameleon/chameleon.theme',0,0,0,-1,0,'a:12:{s:4:\"name\";s:9:\"Chameleon\";s:11:\"description\";s:42:\"Minimalist tabled theme with light colors.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:8:\"features\";a:4:{i:0;s:4:\"logo\";i:1;s:7:\"favicon\";i:2;s:4:\"name\";i:3;s:6:\"slogan\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"scripts\";a:1:{s:9:\"script.js\";s:26:\"themes/chameleon/script.js\";}s:10:\"screenshot\";s:31:\"themes/chameleon/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('themes/bluemarine/bluemarine.info','bluemarine','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:13:{s:4:\"name\";s:10:\"Bluemarine\";s:11:\"description\";s:66:\"Table-based multi-column theme with a marine and ash color scheme.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/bluemarine/script.js\";}s:10:\"screenshot\";s:32:\"themes/bluemarine/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('themes/pushbutton/pushbutton.info','pushbutton','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:13:{s:4:\"name\";s:10:\"Pushbutton\";s:11:\"description\";s:52:\"Tabled, multi-column theme in blue and orange tones.\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/pushbutton/script.js\";}s:10:\"screenshot\";s:32:\"themes/pushbutton/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/themes/rubik/cube/cube.info','cube','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:16:{s:4:\"name\";s:4:\"Cube\";s:11:\"description\";s:44:\"Spaces-aware front-end theme based on Rubik.\";s:10:\"base theme\";s:5:\"rubik\";s:4:\"core\";s:3:\"6.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:1:{s:6:\"screen\";a:1:{s:9:\"style.css\";s:44:\"profiles/os_demo/themes/rubik/cube/style.css\";}}s:7:\"regions\";a:4:{s:6:\"header\";s:6:\"Header\";s:7:\"content\";s:7:\"Content\";s:4:\"left\";s:4:\"Left\";s:5:\"right\";s:5:\"Right\";}s:9:\"designkit\";a:2:{s:5:\"color\";a:1:{s:10:\"background\";s:7:\"#0088cc\";}s:4:\"logo\";a:2:{s:4:\"logo\";s:23:\"imagecache_scale:200x50\";s:5:\"print\";s:24:\"imagecache_scale:600x150\";}}s:7:\"layouts\";a:5:{s:7:\"default\";a:3:{s:4:\"name\";s:7:\"Default\";s:11:\"description\";s:23:\"Simple one column page.\";s:8:\"template\";s:4:\"page\";}s:7:\"sidebar\";a:5:{s:4:\"name\";s:7:\"Sidebar\";s:11:\"description\";s:26:\"Main content with sidebar.\";s:10:\"stylesheet\";s:18:\"layout-sidebar.css\";s:8:\"template\";s:14:\"layout-sidebar\";s:7:\"regions\";a:2:{i:0;s:7:\"content\";i:1;s:5:\"right\";}}s:5:\"split\";a:5:{s:4:\"name\";s:5:\"Split\";s:11:\"description\";s:12:\"50/50 split.\";s:10:\"stylesheet\";s:16:\"layout-split.css\";s:8:\"template\";s:14:\"layout-sidebar\";s:7:\"regions\";a:2:{i:0;s:7:\"content\";i:1;s:5:\"right\";}}s:7:\"columns\";a:5:{s:4:\"name\";s:7:\"Columns\";s:11:\"description\";s:20:\"Three column layout.\";s:10:\"stylesheet\";s:18:\"layout-columns.css\";s:8:\"template\";s:14:\"layout-columns\";s:7:\"regions\";a:4:{i:0;s:6:\"header\";i:1;s:7:\"content\";i:2;s:4:\"left\";i:3;s:5:\"right\";}}s:6:\"offset\";a:5:{s:4:\"name\";s:15:\"Offset sidebars\";s:11:\"description\";s:38:\"Main content with two offset sidebars.\";s:10:\"stylesheet\";s:17:\"layout-offset.css\";s:8:\"template\";s:13:\"layout-offset\";s:7:\"regions\";a:4:{i:0;s:6:\"header\";i:1;s:7:\"content\";i:2;s:4:\"left\";i:3;s:5:\"right\";}}}s:7:\"version\";s:13:\"6.x-3.0-beta2\";s:7:\"project\";s:5:\"rubik\";s:9:\"datestamp\";s:10:\"1285709466\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:44:\"profiles/os_demo/themes/rubik/cube/script.js\";}s:10:\"screenshot\";s:49:\"profiles/os_demo/themes/rubik/cube/screenshot.png\";s:3:\"php\";s:5:\"4.3.5\";}'),('modules/system/system.module','system','module','',1,0,0,6055,0,'a:10:{s:4:\"name\";s:6:\"System\";s:11:\"description\";s:54:\"Handles general site configuration for administrators.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/views_bulk_operations/actions_permissions.module','actions_permissions','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:19:\"Actions permissions\";s:11:\"description\";s:46:\"Integrates actions with the permission system.\";s:7:\"package\";s:14:\"Administration\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.9\";s:7:\"project\";s:21:\"views_bulk_operations\";s:9:\"datestamp\";s:10:\"1265245814\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/admin/admin.module','admin','module','',1,0,0,6202,1,'a:10:{s:4:\"name\";s:5:\"Admin\";s:11:\"description\";s:42:\"UI helpers for Drupal admins and managers.\";s:7:\"package\";s:14:\"Administration\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.0\";s:7:\"project\";s:5:\"admin\";s:9:\"datestamp\";s:10:\"1282226188\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/development/admin_menu/admin_menu.module','admin_menu','module','',1,0,0,6001,0,'a:10:{s:4:\"name\";s:19:\"Administration menu\";s:11:\"description\";s:123:\"Provides a dropdown menu to most administrative tasks and other common destinations (to users with the proper permissions).\";s:7:\"package\";s:14:\"Administration\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.6\";s:7:\"project\";s:10:\"admin_menu\";s:9:\"datestamp\";s:10:\"1283512306\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/advanced_help/advanced_help.module','advanced_help','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:13:\"Advanced help\";s:11:\"description\";s:38:\"Allow advanced help and documentation.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.2\";s:7:\"project\";s:13:\"advanced_help\";s:9:\"datestamp\";s:10:\"1238954409\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/aggregator/aggregator.module','aggregator','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"Aggregator\";s:11:\"description\";s:57:\"Aggregates syndicated content (RSS, RDF, and Atom feeds).\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/better_formats/better_formats.module','better_formats','module','',1,0,0,6110,100,'a:9:{s:4:\"name\";s:14:\"Better Formats\";s:11:\"description\";s:85:\"Enhances the core input format system by managing input format defaults and settings.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.2\";s:7:\"project\";s:14:\"better_formats\";s:9:\"datestamp\";s:10:\"1265402405\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/block/block.module','block','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:5:\"Block\";s:11:\"description\";s:62:\"Controls the boxes that are displayed around the main content.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/blog/blog.module','blog','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:4:\"Blog\";s:11:\"description\";s:69:\"Enables keeping easily and regularly updated user web pages or blogs.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/blogapi/blogapi.module','blogapi','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:8:\"Blog API\";s:11:\"description\";s:79:\"Allows users to post content using applications that support XML-RPC blog APIs.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/book/book.module','book','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:4:\"Book\";s:11:\"description\";s:63:\"Allows users to structure site pages in a hierarchy or outline.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/ctools/bulk_export/bulk_export.module','bulk_export','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:11:\"Bulk Export\";s:11:\"description\";s:67:\"Performs bulk exporting of data objects known about by Chaos tools.\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:1:{i:0;s:6:\"ctools\";}s:7:\"package\";s:16:\"Chaos tool suite\";s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/calendar/calendar.module','calendar','module','',1,0,0,6002,1,'a:8:{s:4:\"name\";s:8:\"Calendar\";s:11:\"description\";s:60:\"Views plugin to display views containing dates as Calendars.\";s:12:\"dependencies\";a:3:{i:0;s:5:\"views\";i:1;s:8:\"date_api\";i:2;s:13:\"date_timezone\";}s:7:\"package\";s:9:\"Date/Time\";s:4:\"core\";s:3:\"6.x\";s:10:\"dependents\";a:0:{}s:7:\"version\";N;s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/calendar/calendar_ical/calendar_ical.module','calendar_ical','module','',0,0,0,-1,0,'a:8:{s:4:\"name\";s:13:\"Calendar iCal\";s:11:\"description\";s:42:\"Adds ical functionality to Calendar views.\";s:12:\"dependencies\";a:3:{i:0;s:5:\"views\";i:1;s:8:\"date_api\";i:2;s:8:\"calendar\";}s:7:\"package\";s:9:\"Date/Time\";s:4:\"core\";s:3:\"6.x\";s:10:\"dependents\";a:0:{}s:7:\"version\";N;s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/development/coder/coder.module','coder','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:5:\"Coder\";s:11:\"description\";s:66:\"Developer Module that assists with code review and version upgrade\";s:7:\"package\";s:11:\"Development\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:13:\"6.x-2.0-beta1\";s:7:\"project\";s:5:\"coder\";s:9:\"datestamp\";s:10:\"1256306115\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/color/color.module','color','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:5:\"Color\";s:11:\"description\";s:61:\"Allows the user to change the color scheme of certain themes.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/comment/comment.module','comment','module','',1,0,0,6003,0,'a:10:{s:4:\"name\";s:7:\"Comment\";s:11:\"description\";s:57:\"Allows users to comment on and discuss published content.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/contact/contact.module','contact','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:7:\"Contact\";s:11:\"description\";s:61:\"Enables the use of both personal and site-wide contact forms.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/content.module','content','module','',1,0,0,6010,0,'a:10:{s:4:\"name\";s:7:\"Content\";s:11:\"description\";s:50:\"Allows administrators to define new content types.\";s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/content_copy/content_copy.module','content_copy','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:12:\"Content Copy\";s:11:\"description\";s:51:\"Enables ability to import/export field definitions.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/content_permissions/content_permissions.module','content_permissions','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:19:\"Content Permissions\";s:11:\"description\";s:43:\"Set field-level permissions for CCK fields.\";s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/context/context.module','context','module','',1,0,0,6304,0,'a:10:{s:4:\"name\";s:7:\"Context\";s:12:\"dependencies\";a:1:{i:0;s:6:\"ctools\";}s:11:\"description\";s:66:\"Provide modules with a cache that lasts for a single page request.\";s:7:\"package\";s:7:\"Context\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-3.0\";s:7:\"project\";s:7:\"context\";s:9:\"datestamp\";s:10:\"1282588006\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/context_admin/context_admin.module','context_admin','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:25:\"Contextual Administration\";s:11:\"description\";s:85:\"A module for building and exporting menu items for a given contextual area of a site.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:25:\"Contextual Administration\";s:12:\"dependencies\";a:1:{i:0;s:12:\"page_manager\";}s:7:\"version\";s:14:\"6.x-1.0-beta11\";s:7:\"project\";s:13:\"context_admin\";s:9:\"datestamp\";s:10:\"1284904560\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/context_admin/contrib/context_admin_vbo/context_admin_vbo.module','context_admin_vbo','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:47:\"Contextual Administration Views Bulk Operations\";s:11:\"description\";s:69:\"Contextual Adminsitration plugins for use with Views Bulk Operations.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:25:\"Contextual Administration\";s:12:\"dependencies\";a:2:{i:0;s:13:\"context_admin\";i:1;s:21:\"views_bulk_operations\";}s:7:\"version\";s:14:\"6.x-1.0-beta11\";s:7:\"project\";s:13:\"context_admin\";s:9:\"datestamp\";s:10:\"1284904560\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/context/context_layouts/context_layouts.module','context_layouts','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:15:\"Context layouts\";s:11:\"description\";s:80:\"Allow theme layer to provide multiple region layouts and integrate with context.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"context\";}s:7:\"package\";s:7:\"Context\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-3.0\";s:7:\"project\";s:7:\"context\";s:9:\"datestamp\";s:10:\"1282588006\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/context/context_ui/context_ui.module','context_ui','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"Context UI\";s:11:\"description\";s:68:\"Provides a simple UI for settings up a site structure using Context.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"context\";}s:7:\"package\";s:7:\"Context\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-3.0\";s:7:\"project\";s:7:\"context\";s:9:\"datestamp\";s:10:\"1282588006\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/cookie_cache_bypass/cookie_cache_bypass.module','cookie_cache_bypass','module','',0,0,0,-1,0,'a:8:{s:4:\"name\";s:19:\"Cookie cache bypass\";s:11:\"description\";s:147:\"Sets a cookie on form submission directing a reverse proxy to temporarily not serve cached pages for an anonymous user that just submitted content.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:9:\"Pressflow\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:7:\"version\";N;s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/ctools/ctools.module','ctools','module','',1,0,0,6007,0,'a:10:{s:4:\"name\";s:11:\"Chaos tools\";s:11:\"description\";s:46:\"A library of helpful tools by Merlin of Chaos.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:16:\"Chaos tool suite\";s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/ctools/ctools_access_ruleset/ctools_access_ruleset.module','ctools_access_ruleset','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:15:\"Custom rulesets\";s:11:\"description\";s:81:\"Create custom, exportable, reusable access rulesets for applications like Panels.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:16:\"Chaos tool suite\";s:12:\"dependencies\";a:1:{i:0;s:6:\"ctools\";}s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/ctools/ctools_custom_content/ctools_custom_content.module','ctools_custom_content','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:20:\"Custom content panes\";s:11:\"description\";s:79:\"Create custom, exportable, reusable content panes for applications like Panels.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:16:\"Chaos tool suite\";s:12:\"dependencies\";a:1:{i:0;s:6:\"ctools\";}s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/ctools/ctools_plugin_example/ctools_plugin_example.module','ctools_plugin_example','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:35:\"Chaos Tools (CTools) Plugin Example\";s:11:\"description\";s:75:\"Shows how an external module can provide ctools plugins (for Panels, etc.).\";s:7:\"package\";s:16:\"Chaos tool suite\";s:12:\"dependencies\";a:4:{i:0;s:6:\"ctools\";i:1;s:6:\"panels\";i:2;s:12:\"page_manager\";i:3;s:13:\"advanced_help\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date/date.module','date','module','',1,0,0,6005,0,'a:10:{s:4:\"name\";s:4:\"Date\";s:11:\"description\";s:41:\"Defines CCK date/time fields and widgets.\";s:12:\"dependencies\";a:3:{i:0;s:7:\"content\";i:1;s:8:\"date_api\";i:2;s:13:\"date_timezone\";}s:7:\"package\";s:9:\"Date/Time\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date_api.module','date_api','module','',1,0,0,6006,0,'a:10:{s:4:\"name\";s:8:\"Date API\";s:11:\"description\";s:45:\"A Date API that can be used by other modules.\";s:7:\"package\";s:9:\"Date/Time\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date_locale/date_locale.module','date_locale','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:11:\"Date Locale\";s:11:\"description\";s:124:\"Allows the site admin to configure multiple formats for date/time display to tailor dates for a specific locale or audience.\";s:7:\"package\";s:9:\"Date/Time\";s:12:\"dependencies\";a:2:{i:0;s:8:\"date_api\";i:1;s:6:\"locale\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date_php4/date_php4.module','date_php4','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:9:\"Date PHP4\";s:11:\"description\";s:134:\"Emulate PHP 5.2 date functions in PHP 4.x, PHP 5.0, and PHP 5.1. Required when using the Date API with PHP versions less than PHP 5.2.\";s:7:\"package\";s:9:\"Date/Time\";s:12:\"dependencies\";a:1:{i:0;s:8:\"date_api\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date_popup/date_popup.module','date_popup','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"Date Popup\";s:11:\"description\";s:84:\"Enables jquery popup calendars and time entry widgets for selecting dates and times.\";s:12:\"dependencies\";a:2:{i:0;s:8:\"date_api\";i:1;s:13:\"date_timezone\";}s:7:\"package\";s:9:\"Date/Time\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date_repeat/date_repeat.module','date_repeat','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:15:\"Date Repeat API\";s:11:\"description\";s:73:\"A Date Repeat API to calculate repeating dates and times from iCal rules.\";s:12:\"dependencies\";a:1:{i:0;s:8:\"date_api\";}s:7:\"package\";s:9:\"Date/Time\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date_timezone/date_timezone.module','date_timezone','module','',1,0,0,5200,0,'a:10:{s:4:\"name\";s:13:\"Date Timezone\";s:11:\"description\";s:111:\"Needed when using Date API. Overrides site and user timezone handling to set timezone names instead of offsets.\";s:7:\"package\";s:9:\"Date/Time\";s:12:\"dependencies\";a:1:{i:0;s:8:\"date_api\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/date/date_tools/date_tools.module','date_tools','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"Date Tools\";s:11:\"description\";s:52:\"Tools to import and auto-create dates and calendars.\";s:12:\"dependencies\";a:2:{i:0;s:7:\"content\";i:1;s:4:\"date\";}s:7:\"package\";s:9:\"Date/Time\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.6\";s:7:\"project\";s:4:\"date\";s:9:\"datestamp\";s:10:\"1281786990\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/dblog/dblog.module','dblog','module','',1,0,0,6000,0,'a:10:{s:4:\"name\";s:16:\"Database logging\";s:11:\"description\";s:47:\"Logs and records system events to the database.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/development/devel/devel.module','devel','module','',1,0,1,6003,88,'a:10:{s:4:\"name\";s:5:\"Devel\";s:11:\"description\";s:52:\"Various blocks, pages, and functions for developers.\";s:7:\"package\";s:11:\"Development\";s:12:\"dependencies\";a:1:{i:0;s:4:\"menu\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-1.22\";s:7:\"project\";s:5:\"devel\";s:9:\"datestamp\";s:10:\"1281718291\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/development/devel/devel_generate.module','devel_generate','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:14:\"Devel generate\";s:11:\"description\";s:48:\"Generate dummy users, nodes, and taxonomy terms.\";s:7:\"package\";s:11:\"Development\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-1.22\";s:7:\"project\";s:5:\"devel\";s:9:\"datestamp\";s:10:\"1281718291\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/development/devel/devel_node_access.module','devel_node_access','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:17:\"Devel node access\";s:11:\"description\";s:67:\"Developer block and page illustrating relevant node_access records.\";s:7:\"package\";s:11:\"Development\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-1.22\";s:7:\"project\";s:5:\"devel\";s:9:\"datestamp\";s:10:\"1281718291\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('sites/all/modules/features/doune_theme_settings/doune_theme_settings.module','doune_theme_settings','module','',1,0,0,0,0,'a:11:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:2:{i:0;s:9:\"strongarm\";i:1;s:4:\"less\";}s:11:\"description\";s:33:\"Base settings for the Doune theme\";s:8:\"features\";a:2:{s:6:\"ctools\";a:1:{i:0;s:21:\"strongarm:strongarm:1\";}s:8:\"variable\";a:2:{i:0;s:20:\"theme_doune_settings\";i:1;s:14:\"theme_settings\";}}s:4:\"name\";s:20:\"Doune Theme Settings\";s:7:\"package\";s:5:\"Theme\";s:7:\"project\";s:20:\"doune_theme_settings\";s:18:\"project status url\";s:36:\"http://code.opensourcery.com/fserver\";s:7:\"version\";s:13:\"6.x-1.0-beta1\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/features/features.module','features','module','',1,0,0,6101,20,'a:10:{s:4:\"name\";s:8:\"Features\";s:11:\"description\";s:39:\"Provides feature management for Drupal.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:8:\"Features\";s:7:\"version\";s:7:\"6.x-1.0\";s:7:\"project\";s:8:\"features\";s:9:\"datestamp\";s:10:\"1282573607\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/features/tests/features_test.module','features_test','module','',0,0,0,-1,0,'a:11:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:4:{i:0;s:8:\"features\";i:1;s:10:\"fieldgroup\";i:2;s:4:\"text\";i:3;s:5:\"views\";}s:11:\"description\";s:33:\"Test module for Features testing.\";s:8:\"features\";a:8:{s:7:\"content\";a:3:{i:0;s:33:\"features_test-field_features_test\";i:1;s:41:\"features_test-field_features_test_child_a\";i:2;s:41:\"features_test-field_features_test_child_b\";}s:10:\"fieldgroup\";a:1:{i:0;s:33:\"features_test-group_features_test\";}s:6:\"filter\";a:1:{i:0;s:13:\"features_test\";}s:10:\"imagecache\";a:1:{i:0;s:13:\"features_test\";}s:4:\"node\";a:1:{i:0;s:13:\"features_test\";}s:15:\"user_permission\";a:1:{i:0;s:28:\"create features_test content\";}s:5:\"views\";a:1:{i:0;s:13:\"features_test\";}s:9:\"views_api\";a:1:{i:0;s:5:\"api:2\";}}s:4:\"name\";s:14:\"Features Tests\";s:7:\"package\";s:7:\"Testing\";s:7:\"version\";s:7:\"6.x-1.0\";s:7:\"project\";s:8:\"features\";s:9:\"datestamp\";s:10:\"1282573607\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/fieldgroup/fieldgroup.module','fieldgroup','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"Fieldgroup\";s:11:\"description\";s:37:\"Create display groups for CCK fields.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/filefield/filefield.module','filefield','module','',1,0,0,6104,0,'a:10:{s:4:\"name\";s:9:\"FileField\";s:11:\"description\";s:26:\"Defines a file field type.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:3:\"php\";s:3:\"5.0\";s:7:\"version\";s:7:\"6.x-3.7\";s:7:\"project\";s:9:\"filefield\";s:9:\"datestamp\";s:10:\"1277943012\";s:10:\"dependents\";a:0:{}}'),('profiles/os_demo/modules/contrib/filefield/filefield_meta/filefield_meta.module','filefield_meta','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:14:\"FileField Meta\";s:11:\"description\";s:48:\"Add metadata gathering and storage to FileField.\";s:12:\"dependencies\";a:2:{i:0;s:9:\"filefield\";i:1;s:6:\"getid3\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:3:\"php\";s:3:\"5.0\";s:7:\"version\";s:7:\"6.x-3.7\";s:7:\"project\";s:9:\"filefield\";s:9:\"datestamp\";s:10:\"1277943012\";s:10:\"dependents\";a:0:{}}'),('profiles/os_demo/modules/contrib/filefield_paths/filefield_paths.module','filefield_paths','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:15:\"FileField Paths\";s:11:\"description\";s:68:\"Adds improved Token based file sorting and renaming functionalities.\";s:12:\"dependencies\";a:1:{i:0;s:5:\"token\";}s:7:\"package\";s:15:\"FileField Paths\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.4\";s:7:\"project\";s:15:\"filefield_paths\";s:9:\"datestamp\";s:10:\"1263190506\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/filefield_sources/filefield_sources.module','filefield_sources','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:17:\"FileField Sources\";s:11:\"description\";s:89:\"Extends FileField to allow referencing of existing files, remote files, and server files.\";s:12:\"dependencies\";a:1:{i:0;s:9:\"filefield\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.2\";s:7:\"project\";s:17:\"filefield_sources\";s:9:\"datestamp\";s:10:\"1281545492\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/filter/filter.module','filter','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:6:\"Filter\";s:11:\"description\";s:60:\"Handles the filtering of content in preparation for display.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/forum/forum.module','forum','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:5:\"Forum\";s:11:\"description\";s:50:\"Enables threaded discussions about general topics.\";s:12:\"dependencies\";a:2:{i:0;s:8:\"taxonomy\";i:1;s:7:\"comment\";}s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/help/help.module','help','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:4:\"Help\";s:11:\"description\";s:35:\"Manages the display of online help.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/advanced_help/help_example/help_example.module','help_example','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:21:\"Advanced help example\";s:11:\"description\";s:62:\"A example help module to demonstrate the advanced help module.\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:1:{i:0;s:13:\"advanced_help\";}s:7:\"version\";s:7:\"6.x-1.2\";s:7:\"project\";s:13:\"advanced_help\";s:9:\"datestamp\";s:10:\"1238954409\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/image_resize_filter/image_resize_filter.module','image_resize_filter','module','',1,0,0,6102,0,'a:9:{s:4:\"name\";s:19:\"Image resize filter\";s:11:\"description\";s:74:\"Filter to automatically scale images to their height and width dimensions.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.9\";s:7:\"project\";s:19:\"image_resize_filter\";s:9:\"datestamp\";s:10:\"1274048707\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/imageapi/imageapi.module','imageapi','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:8:\"ImageAPI\";s:11:\"description\";s:38:\"ImageAPI supporting multiple toolkits.\";s:7:\"package\";s:10:\"ImageCache\";s:4:\"core\";s:3:\"6.x\";s:3:\"php\";s:3:\"5.1\";s:7:\"version\";s:7:\"6.x-1.8\";s:7:\"project\";s:8:\"imageapi\";s:9:\"datestamp\";s:10:\"1272675611\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}}'),('profiles/os_demo/modules/contrib/imageapi/imageapi_gd.module','imageapi_gd','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:12:\"ImageAPI GD2\";s:11:\"description\";s:49:\"Uses PHP\'s built-in GD2 image processing support.\";s:7:\"package\";s:10:\"ImageCache\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.8\";s:7:\"project\";s:8:\"imageapi\";s:9:\"datestamp\";s:10:\"1272675611\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/imageapi/imageapi_imagemagick.module','imageapi_imagemagick','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:20:\"ImageAPI ImageMagick\";s:11:\"description\";s:33:\"Command Line ImageMagick support.\";s:7:\"package\";s:10:\"ImageCache\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.8\";s:7:\"project\";s:8:\"imageapi\";s:9:\"datestamp\";s:10:\"1272675611\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/imagecache/imagecache.module','imagecache','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"ImageCache\";s:11:\"description\";s:36:\"Dynamic image manipulator and cache.\";s:7:\"package\";s:10:\"ImageCache\";s:12:\"dependencies\";a:1:{i:0;s:8:\"imageapi\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:14:\"6.x-2.0-beta10\";s:7:\"project\";s:10:\"imagecache\";s:9:\"datestamp\";s:10:\"1250716281\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/imagecache/imagecache_ui.module','imagecache_ui','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:13:\"ImageCache UI\";s:11:\"description\";s:26:\"ImageCache User Interface.\";s:12:\"dependencies\";a:2:{i:0;s:10:\"imagecache\";i:1;s:8:\"imageapi\";}s:7:\"package\";s:10:\"ImageCache\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:14:\"6.x-2.0-beta10\";s:7:\"project\";s:10:\"imagecache\";s:9:\"datestamp\";s:10:\"1250716281\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/imagefield/imagefield.module','imagefield','module','',1,0,0,6006,0,'a:10:{s:4:\"name\";s:10:\"ImageField\";s:11:\"description\";s:28:\"Defines an image field type.\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:2:{i:0;s:7:\"content\";i:1;s:9:\"filefield\";}s:7:\"package\";s:3:\"CCK\";s:7:\"version\";s:7:\"6.x-3.7\";s:7:\"project\";s:10:\"imagefield\";s:9:\"datestamp\";s:10:\"1277942710\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/imagefield_tokens/imagefield_tokens.module','imagefield_tokens','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:17:\"ImageField Tokens\";s:11:\"description\";s:58:\"Adds Node tokens to ImageFields ALT and Title text fields.\";s:12:\"dependencies\";a:2:{i:0;s:10:\"imagefield\";i:1;s:15:\"filefield_paths\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.0\";s:7:\"project\";s:17:\"imagefield_tokens\";s:9:\"datestamp\";s:10:\"1241250704\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/insert/insert.module','insert','module','',1,0,0,0,15,'a:9:{s:4:\"name\";s:6:\"Insert\";s:11:\"description\";s:91:\"Assists in inserting files, images, or other media into the body field or other text areas.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:13:\"6.x-1.0-beta6\";s:7:\"project\";s:6:\"insert\";s:9:\"datestamp\";s:10:\"1281207975\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/calendar/jcalendar/jcalendar.module','jcalendar','module','',0,0,0,-1,0,'a:8:{s:4:\"name\";s:14:\"Calendar Popup\";s:11:\"description\";s:115:\"Replaces the links to calendar items with a javascript popup that gracefully regresses if javascript is not enabled\";s:12:\"dependencies\";a:2:{i:0;s:8:\"calendar\";i:1;s:5:\"views\";}s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:9:\"Date/Time\";s:10:\"dependents\";a:0:{}s:7:\"version\";N;s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/jquery_ui/jquery_ui.module','jquery_ui','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:9:\"jQuery UI\";s:11:\"description\";s:55:\"Provides the jQuery UI plug-in to other Drupal modules.\";s:7:\"package\";s:14:\"User interface\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.4\";s:7:\"project\";s:9:\"jquery_ui\";s:9:\"datestamp\";s:10:\"1284001909\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/less/less.module','less','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:21:\"LESS CSS Preprocessor\";s:11:\"description\";s:43:\"Allows themes or modules to use LESS files.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.2\";s:7:\"project\";s:4:\"less\";s:9:\"datestamp\";s:10:\"1284075707\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/libraries/libraries.module','libraries','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:9:\"Libraries\";s:11:\"description\";s:45:\"External library handling for Drupal modules.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:14:\"6.x-1.0-alpha1\";s:7:\"project\";s:9:\"libraries\";s:9:\"datestamp\";s:10:\"1262190965\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/link/link.module','link','module','',1,0,0,6002,0,'a:10:{s:4:\"name\";s:4:\"Link\";s:11:\"description\";s:32:\"Defines simple link field types.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.9\";s:7:\"project\";s:4:\"link\";s:9:\"datestamp\";s:10:\"1276539609\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/locale/locale.module','locale','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:6:\"Locale\";s:11:\"description\";s:119:\"Adds language handling functionality and enables the translation of the user interface to languages other than English.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/menu/menu.module','menu','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:4:\"Menu\";s:11:\"description\";s:60:\"Allows administrators to customize the site navigation menu.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/node/node.module','node','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:4:\"Node\";s:11:\"description\";s:66:\"Allows content to be submitted to the site and displayed on pages.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/nodequeue/nodequeue.module','nodequeue','module','',1,0,0,6005,0,'a:10:{s:4:\"name\";s:9:\"Nodequeue\";s:11:\"description\";s:56:\"Create queues which can contain nodes in arbitrary order\";s:7:\"package\";s:9:\"Nodequeue\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.9\";s:7:\"project\";s:9:\"nodequeue\";s:9:\"datestamp\";s:10:\"1268779506\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/nodequeue/nodequeue_generate.module','nodequeue_generate','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:18:\"Nodequeue generate\";s:11:\"description\";s:60:\"Bulk assign nodes into queues for quickly populating a site.\";s:7:\"package\";s:11:\"Development\";s:12:\"dependencies\";a:1:{i:0;s:9:\"nodequeue\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.9\";s:7:\"project\";s:9:\"nodequeue\";s:9:\"datestamp\";s:10:\"1268779506\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/nodequeue/addons/nodequeue_service/nodequeue_service.module','nodequeue_service','module','',0,0,0,-1,0,'a:10:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:2:{i:0;s:8:\"services\";i:1;s:9:\"nodequeue\";}s:11:\"description\";s:29:\"Provides a nodequeue service.\";s:4:\"name\";s:17:\"Nodequeue Service\";s:7:\"package\";s:9:\"Nodequeue\";s:7:\"version\";s:7:\"6.x-2.9\";s:7:\"project\";s:9:\"nodequeue\";s:9:\"datestamp\";s:10:\"1268779506\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/nodereference/nodereference.module','nodereference','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:14:\"Node Reference\";s:11:\"description\";s:59:\"Defines a field type for referencing one node from another.\";s:12:\"dependencies\";a:3:{i:0;s:7:\"content\";i:1;s:4:\"text\";i:2;s:13:\"optionwidgets\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/number/number.module','number','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:6:\"Number\";s:11:\"description\";s:28:\"Defines numeric field types.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/openid/openid.module','openid','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:6:\"OpenID\";s:11:\"description\";s:48:\"Allows users to log into your site using OpenID.\";s:7:\"version\";s:4:\"6.19\";s:7:\"package\";s:15:\"Core - optional\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/optionwidgets/optionwidgets.module','optionwidgets','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:14:\"Option Widgets\";s:11:\"description\";s:82:\"Defines selection, check box and radio button widgets for text and numeric fields.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('sites/all/modules/features/os_admin/os_admin.module','os_admin','module','',1,0,0,0,0,'a:11:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:3:{i:0;s:5:\"admin\";i:1;s:8:\"features\";i:2;s:9:\"strongarm\";}s:11:\"description\";s:26:\"OpenSourcery admin feature\";s:8:\"features\";a:3:{s:6:\"ctools\";a:1:{i:0;s:21:\"strongarm:strongarm:1\";}s:15:\"user_permission\";a:1:{i:0;s:17:\"use admin toolbar\";}s:8:\"variable\";a:2:{i:0;s:11:\"admin_theme\";i:1;s:13:\"admin_toolbar\";}}s:4:\"name\";s:18:\"OpenSourcery Admin\";s:7:\"package\";s:5:\"Admin\";s:7:\"project\";s:8:\"os_admin\";s:18:\"project status url\";s:36:\"http://code.opensourcery.com/fserver\";s:7:\"version\";s:14:\"6.x-1.0-alpha1\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/features/os_base/os_base.module','os_base','module','',1,0,0,0,0,'a:10:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:5:{i:0;s:13:\"context_admin\";i:1;s:6:\"ctools\";i:2;s:8:\"features\";i:3;s:12:\"page_manager\";i:4;s:9:\"strongarm\";}s:11:\"description\";s:52:\"Base content types, roles and usability enhancements\";s:8:\"features\";a:6:{s:6:\"ctools\";a:2:{i:0;s:28:\"page_manager:pages_default:1\";i:1;s:21:\"strongarm:strongarm:1\";}s:4:\"node\";a:1:{i:0;s:4:\"page\";}s:18:\"page_manager_pages\";a:1:{i:0;s:8:\"sub_page\";}s:15:\"user_permission\";a:5:{i:0;s:19:\"create page content\";i:1;s:23:\"delete any page content\";i:2;s:23:\"delete own page content\";i:3;s:21:\"edit any page content\";i:4;s:21:\"edit own page content\";}s:9:\"user_role\";a:2:{i:0;s:13:\"administrator\";i:1;s:11:\"site editor\";}s:8:\"variable\";a:2:{i:0;s:12:\"comment_page\";i:1;s:17:\"node_options_page\";}}s:4:\"name\";s:17:\"OpenSourcery base\";s:7:\"package\";s:8:\"Features\";s:7:\"project\";s:7:\"os_base\";s:7:\"version\";s:13:\"6.x-1.0-beta1\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/features/os_blog/os_blog.module','os_blog','module','',1,0,0,0,0,'a:10:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:12:{i:0;s:7:\"comment\";i:1;s:13:\"context_admin\";i:2;s:17:\"context_admin_vbo\";i:3;s:8:\"features\";i:4;s:19:\"image_resize_filter\";i:5;s:10:\"imagefield\";i:6;s:6:\"insert\";i:7;s:12:\"page_manager\";i:8;s:13:\"semanticviews\";i:9;s:9:\"strongarm\";i:10;s:8:\"taxonomy\";i:11;s:11:\"wp_comments\";}s:11:\"description\";s:18:\"Basic blog feature\";s:8:\"features\";a:9:{s:7:\"content\";a:1:{i:0;s:22:\"blog-field_blog_images\";}s:7:\"context\";a:3:{i:0;s:12:\"blog_archive\";i:1;s:15:\"blog_individual\";i:2;s:9:\"blog_list\";}s:6:\"ctools\";a:3:{i:0;s:17:\"context:context:3\";i:1;s:28:\"page_manager:pages_default:1\";i:2;s:21:\"strongarm:strongarm:1\";}s:10:\"imagecache\";a:1:{i:0;s:9:\"blog-list\";}s:4:\"node\";a:1:{i:0;s:4:\"blog\";}s:18:\"page_manager_pages\";a:3:{i:0;s:8:\"blog_add\";i:1;s:10:\"blog_admin\";i:2;s:15:\"blog_admin_tags\";}s:4:\"user\";a:4:{i:0;s:15:\"access comments\";i:1;s:19:\"administer comments\";i:2;s:13:\"post comments\";i:3;s:30:\"post comments without approval\";}s:8:\"variable\";a:11:{i:0;s:22:\"comment_anonymous_blog\";i:1;s:12:\"comment_blog\";i:2;s:21:\"comment_controls_blog\";i:3;s:25:\"comment_default_mode_blog\";i:4;s:26:\"comment_default_order_blog\";i:5;s:29:\"comment_default_per_page_blog\";i:6;s:26:\"comment_form_location_blog\";i:7;s:20:\"comment_preview_blog\";i:8;s:26:\"comment_subject_field_blog\";i:9;s:26:\"content_extra_weights_blog\";i:10;s:26:\"pathauto_node_blog_pattern\";}s:5:\"views\";a:2:{i:0;s:4:\"blog\";i:1;s:12:\"blog_archive\";}}s:4:\"name\";s:9:\"Blog post\";s:7:\"package\";s:8:\"Features\";s:7:\"project\";s:7:\"os_blog\";s:7:\"version\";s:13:\"6.x-1.0-beta1\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/features/os_event/os_event.module','os_event','module','',1,0,0,0,0,'a:10:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:9:{i:0;s:8:\"calendar\";i:1;s:13:\"context_admin\";i:2;s:17:\"context_admin_vbo\";i:3;s:4:\"date\";i:4;s:8:\"features\";i:5;s:10:\"imagefield\";i:6;s:12:\"page_manager\";i:7;s:13:\"semanticviews\";i:8;s:9:\"strongarm\";}s:11:\"description\";s:14:\"Events feature\";s:8:\"features\";a:8:{s:7:\"content\";a:2:{i:0;s:22:\"event-field_event_date\";i:1;s:23:\"event-field_event_image\";}s:6:\"ctools\";a:2:{i:0;s:28:\"page_manager:pages_default:1\";i:1;s:21:\"strongarm:strongarm:1\";}s:4:\"node\";a:1:{i:0;s:5:\"event\";}s:18:\"page_manager_pages\";a:2:{i:0;s:9:\"event_add\";i:1;s:11:\"event_admin\";}s:15:\"user_permission\";a:5:{i:0;s:20:\"create event content\";i:1;s:24:\"delete any event content\";i:2;s:24:\"delete own event content\";i:3;s:22:\"edit any event content\";i:4;s:22:\"edit own event content\";}s:8:\"variable\";a:3:{i:0;s:27:\"content_extra_weights_event\";i:1;s:18:\"node_options_event\";i:2;s:27:\"pathauto_node_event_pattern\";}s:5:\"views\";a:2:{i:0;s:14:\"event_calendar\";i:1;s:10:\"event_list\";}s:9:\"views_api\";a:1:{i:0;s:5:\"api:2\";}}s:4:\"name\";s:27:\"OpenSourcery Events Feature\";s:7:\"package\";s:8:\"Features\";s:7:\"project\";s:8:\"os_event\";s:7:\"version\";s:13:\"6.x-1.0-beta1\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/features/os_slideshow/os_slideshow.module','os_slideshow','module','',1,0,0,0,0,'a:10:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:8:{i:0;s:8:\"features\";i:1;s:9:\"strongarm\";i:2;s:7:\"context\";i:3;s:10:\"imagefield\";i:4;s:4:\"link\";i:5;s:9:\"nodequeue\";i:6;s:13:\"semanticviews\";i:7;s:11:\"views_cycle\";}s:11:\"description\";s:77:\"Slideshow for Action Center homepage, powered by Views, jQuery, and Nodequeue\";s:8:\"features\";a:7:{s:7:\"content\";a:2:{i:0;s:23:\"slide-field_slide_image\";i:1;s:22:\"slide-field_slide_link\";}s:7:\"context\";a:1:{i:0;s:9:\"slideshow\";}s:6:\"ctools\";a:2:{i:0;s:17:\"context:context:3\";i:1;s:21:\"strongarm:strongarm:1\";}s:10:\"imagecache\";a:1:{i:0;s:18:\"homepage_slideshow\";}s:4:\"node\";a:1:{i:0;s:5:\"slide\";}s:8:\"variable\";a:4:{i:0;s:13:\"comment_slide\";i:1;s:27:\"content_extra_weights_slide\";i:2;s:18:\"node_options_slide\";i:3;s:24:\"nodequeue_view_per_queue\";}s:5:\"views\";a:1:{i:0;s:18:\"homepage_slideshow\";}}s:4:\"name\";s:32:\"Action Center Homepage Slideshow\";s:7:\"package\";s:8:\"Features\";s:7:\"project\";s:12:\"os_slideshow\";s:7:\"version\";s:7:\"6.x-1.0\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/ctools/page_manager/page_manager.module','page_manager','module','',1,0,0,6101,99,'a:10:{s:4:\"name\";s:12:\"Page manager\";s:11:\"description\";s:54:\"Provides a UI and API to manage pages within the site.\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:1:{i:0;s:6:\"ctools\";}s:7:\"package\";s:16:\"Chaos tool suite\";s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/path/path.module','path','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:4:\"Path\";s:11:\"description\";s:28:\"Allows users to rename URLs.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/path_alias_cache/path_alias_cache.module','path_alias_cache','module','',0,0,0,-1,0,'a:8:{s:4:\"name\";s:16:\"Path alias cache\";s:11:\"description\";s:67:\"A path alias implementation which adds a cache to the core version.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:9:\"Pressflow\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:7:\"version\";N;s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/path_redirect/path_redirect.module','path_redirect','module','',1,0,0,6103,0,'a:12:{s:4:\"name\";s:13:\"Path redirect\";s:11:\"description\";s:39:\"Redirect users from one URL to another.\";s:4:\"core\";s:3:\"6.x\";s:8:\"enhances\";a:1:{i:0;s:8:\"pathauto\";}s:8:\"suggests\";a:1:{i:0;s:15:\"global_redirect\";}s:10:\"recommends\";a:1:{i:0;s:8:\"elements\";}s:7:\"version\";s:13:\"6.x-1.0-beta7\";s:7:\"project\";s:13:\"path_redirect\";s:9:\"datestamp\";s:10:\"1281416192\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/path_redirect/generate/path_redirect_generate.module','path_redirect_generate','module','',0,0,0,-1,0,'a:11:{s:4:\"name\";s:22:\"Path redirect generate\";s:11:\"description\";s:34:\"Bulk create redirects for testing.\";s:7:\"package\";s:11:\"Development\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:2:{i:0;s:13:\"path_redirect\";i:1;s:14:\"devel_generate\";}s:4:\"tags\";a:1:{i:0;s:9:\"developer\";}s:7:\"version\";s:13:\"6.x-1.0-beta7\";s:7:\"project\";s:13:\"path_redirect\";s:9:\"datestamp\";s:10:\"1281416192\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/pathauto/pathauto.module','pathauto','module','',1,0,0,7,1,'a:10:{s:4:\"name\";s:8:\"Pathauto\";s:11:\"description\";s:95:\"Provides a mechanism for modules to automatically generate aliases for the content they manage.\";s:12:\"dependencies\";a:2:{i:0;s:4:\"path\";i:1;s:5:\"token\";}s:4:\"core\";s:3:\"6.x\";s:10:\"recommends\";a:1:{i:0;s:13:\"path_redirect\";}s:7:\"version\";s:7:\"6.x-1.4\";s:7:\"project\";s:8:\"pathauto\";s:9:\"datestamp\";s:10:\"1281556294\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/development/devel/performance/performance.module','performance','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:19:\"Performance Logging\";s:11:\"description\";s:91:\"Logs detailed and/or summary page generation time and memory consumption for page requests.\";s:7:\"package\";s:11:\"Development\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-1.22\";s:7:\"project\";s:5:\"devel\";s:9:\"datestamp\";s:10:\"1281718291\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/php/php.module','php','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"PHP filter\";s:11:\"description\";s:50:\"Allows embedded PHP code/snippets to be evaluated.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/ping/ping.module','ping','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:4:\"Ping\";s:11:\"description\";s:51:\"Alerts other sites when your site has been updated.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/poll/poll.module','poll','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:4:\"Poll\";s:11:\"description\";s:95:\"Allows your site to capture votes on different topics in the form of multiple choice questions.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/profile/profile.module','profile','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:7:\"Profile\";s:11:\"description\";s:36:\"Supports configurable user profiles.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/role_delegation/role_delegation.module','role_delegation','module','',1,0,0,6000,0,'a:9:{s:4:\"name\";s:15:\"Role Delegation\";s:11:\"description\";s:95:\"Allows site administrators to grant some roles the authority to assign selected roles to users.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.3\";s:7:\"project\";s:15:\"role_delegation\";s:9:\"datestamp\";s:10:\"1267641013\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/search/search.module','search','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:6:\"Search\";s:11:\"description\";s:36:\"Enables site-wide keyword searching.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/semanticviews/semanticviews.module','semanticviews','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:14:\"Semantic Views\";s:11:\"description\";s:50:\"Views 2 plugins for UI management of output markup\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:1:{i:0;s:5:\"views\";}s:7:\"package\";s:5:\"Views\";s:7:\"version\";s:7:\"6.x-1.1\";s:7:\"project\";s:13:\"semanticviews\";s:9:\"datestamp\";s:10:\"1271635508\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/development/simpletest/simpletest.module','simpletest','module','',0,0,0,-1,0,'a:11:{s:4:\"name\";s:10:\"SimpleTest\";s:11:\"description\";s:53:\"Provides a framework for unit and functional testing.\";s:7:\"package\";s:11:\"Development\";s:4:\"core\";s:3:\"6.x\";s:3:\"php\";s:12:\"5 ; Drupal 6\";s:5:\"files\";a:6:{i:0;s:17:\"simpletest.module\";i:1;s:20:\"simpletest.pages.inc\";i:2;s:18:\"simpletest.install\";i:3;s:15:\"simpletest.test\";i:4;s:24:\"drupal_web_test_case.php\";i:5;s:16:\"tests/block.test\";}s:7:\"version\";s:8:\"6.x-2.10\";s:7:\"project\";s:10:\"simpletest\";s:9:\"datestamp\";s:10:\"1262212859\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}}'),('profiles/os_demo/modules/contrib/nodequeue/smartqueue.module','smartqueue','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:19:\"Smartqueue taxonomy\";s:11:\"description\";s:49:\"Creates a node queue for each taxonomy vocabulary\";s:7:\"package\";s:9:\"Nodequeue\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:2:{i:0;s:9:\"nodequeue\";i:1;s:8:\"taxonomy\";}s:7:\"version\";s:7:\"6.x-2.9\";s:7:\"project\";s:9:\"nodequeue\";s:9:\"datestamp\";s:10:\"1268779506\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/statistics/statistics.module','statistics','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:10:\"Statistics\";s:11:\"description\";s:37:\"Logs access statistics for your site.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/strongarm/strongarm.module','strongarm','module','',1,0,0,6201,-1000,'a:9:{s:4:\"name\";s:9:\"Strongarm\";s:11:\"description\";s:87:\"Enforces variable values defined by modules that need settings set to operate properly.\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:1:{i:0;s:6:\"ctools\";}s:7:\"version\";s:7:\"6.x-2.0\";s:7:\"project\";s:9:\"strongarm\";s:9:\"datestamp\";s:10:\"1281369974\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/ctools/stylizer/stylizer.module','stylizer','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:8:\"Stylizer\";s:11:\"description\";s:53:\"Create custom styles for applications such as Panels.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:16:\"Chaos tool suite\";s:12:\"dependencies\";a:2:{i:0;s:6:\"ctools\";i:1;s:5:\"color\";}s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/syslog/syslog.module','syslog','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:6:\"Syslog\";s:11:\"description\";s:41:\"Logs and records system events to syslog.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/taxonomy/taxonomy.module','taxonomy','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:8:\"Taxonomy\";s:11:\"description\";s:38:\"Enables the categorization of content.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/text/text.module','text','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:4:\"Text\";s:11:\"description\";s:32:\"Defines simple text field types.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"content\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/throttle/throttle.module','throttle','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:8:\"Throttle\";s:11:\"description\";s:66:\"Handles the auto-throttling mechanism, to control site congestion.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/token/token.module','token','module','',1,0,0,1,10,'a:9:{s:4:\"name\";s:5:\"Token\";s:11:\"description\";s:79:\"Provides a shared API for replacement of textual placeholders with actual data.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-1.14\";s:7:\"project\";s:5:\"token\";s:9:\"datestamp\";s:10:\"1281549693\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/token/tokenSTARTER.module','tokenSTARTER','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:12:\"TokenSTARTER\";s:11:\"description\";s:72:\"Provides additional tokens and a base on which to build your own tokens.\";s:12:\"dependencies\";a:1:{i:0;s:5:\"token\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-1.14\";s:7:\"project\";s:5:\"token\";s:9:\"datestamp\";s:10:\"1281549693\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/token/token_actions.module','token_actions','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:13:\"Token actions\";s:11:\"description\";s:73:\"Provides enhanced versions of core Drupal actions using the Token module.\";s:12:\"dependencies\";a:1:{i:0;s:5:\"token\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-1.14\";s:7:\"project\";s:5:\"token\";s:9:\"datestamp\";s:10:\"1281549693\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/tracker/tracker.module','tracker','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:7:\"Tracker\";s:11:\"description\";s:43:\"Enables tracking of recent posts for users.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"comment\";}s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/translation/translation.module','translation','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:19:\"Content translation\";s:11:\"description\";s:57:\"Allows content to be translated into different languages.\";s:12:\"dependencies\";a:1:{i:0;s:6:\"locale\";}s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/trigger/trigger.module','trigger','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:7:\"Trigger\";s:11:\"description\";s:90:\"Enables actions to be fired on certain system events, such as when new content is created.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/update/update.module','update','module','',1,0,0,6000,0,'a:10:{s:4:\"name\";s:13:\"Update status\";s:11:\"description\";s:88:\"Checks the status of available updates for Drupal and your installed modules and themes.\";s:7:\"version\";s:4:\"6.19\";s:7:\"package\";s:15:\"Core - optional\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/upload/upload.module','upload','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:6:\"Upload\";s:11:\"description\";s:51:\"Allows users to upload and attach files to content.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('modules/user/user.module','user','module','',1,0,0,0,0,'a:10:{s:4:\"name\";s:4:\"User\";s:11:\"description\";s:47:\"Manages the user registration and login system.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:4:\"6.19\";s:4:\"core\";s:3:\"6.x\";s:7:\"project\";s:6:\"drupal\";s:9:\"datestamp\";s:10:\"1281559292\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/cck/modules/userreference/userreference.module','userreference','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:14:\"User Reference\";s:11:\"description\";s:56:\"Defines a field type for referencing a user from a node.\";s:12:\"dependencies\";a:3:{i:0;s:7:\"content\";i:1;s:4:\"text\";i:2;s:13:\"optionwidgets\";}s:7:\"package\";s:3:\"CCK\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.8\";s:7:\"project\";s:3:\"cck\";s:9:\"datestamp\";s:10:\"1281570988\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/vertical_tabs/vertical_tabs.module','vertical_tabs','module','',1,0,0,6104,300,'a:9:{s:4:\"name\";s:13:\"Vertical Tabs\";s:11:\"description\";s:67:\"Provides vertical tabs for supported forms like the node edit page.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:14:\"User interface\";s:10:\"recommends\";a:1:{i:0;s:4:\"form\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:7:\"version\";N;s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/views/views.module','views','module','',1,0,0,6009,10,'a:10:{s:4:\"name\";s:5:\"Views\";s:11:\"description\";s:55:\"Create customized lists and queries from your database.\";s:7:\"package\";s:5:\"Views\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-2.11\";s:7:\"project\";s:5:\"views\";s:9:\"datestamp\";s:10:\"1276743614\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/views_bulk_operations/views_bulk_operations.module','views_bulk_operations','module','',1,0,0,6000,0,'a:10:{s:4:\"name\";s:21:\"Views Bulk Operations\";s:11:\"description\";s:103:\"Exposes new Views style \'Bulk Operations\' for selecting multiple nodes and applying operations on them.\";s:12:\"dependencies\";a:1:{i:0;s:5:\"views\";}s:7:\"package\";s:5:\"Views\";s:4:\"core\";s:3:\"6.x\";s:3:\"php\";s:3:\"5.0\";s:7:\"version\";s:7:\"6.x-1.9\";s:7:\"project\";s:21:\"views_bulk_operations\";s:9:\"datestamp\";s:10:\"1265245814\";s:10:\"dependents\";a:0:{}}'),('profiles/os_demo/modules/contrib/ctools/views_content/views_content.module','views_content','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:19:\"Views content panes\";s:11:\"description\";s:104:\"Allows Views content to be used in Panels, Dashboard and other modules which use the CTools Content API.\";s:7:\"package\";s:16:\"Chaos tool suite\";s:12:\"dependencies\";a:2:{i:0;s:6:\"ctools\";i:1;s:5:\"views\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.7\";s:7:\"project\";s:6:\"ctools\";s:9:\"datestamp\";s:10:\"1280189115\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/views_cycle/views_cycle.module','views_cycle','module','',1,0,0,6001,0,'a:10:{s:4:\"name\";s:11:\"Views Cycle\";s:11:\"description\";s:51:\"Wrapper for using the jQuery cycle plugin in Views.\";s:4:\"core\";s:3:\"6.x\";s:3:\"php\";s:3:\"5.2\";s:7:\"package\";s:5:\"Views\";s:12:\"dependencies\";a:2:{i:0;s:5:\"views\";i:1;s:9:\"libraries\";}s:7:\"version\";s:7:\"6.x-1.0\";s:7:\"project\";s:11:\"views_cycle\";s:9:\"datestamp\";s:10:\"1279751415\";s:10:\"dependents\";a:0:{}}'),('profiles/os_demo/modules/contrib/views/views_export/views_export.module','views_export','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:14:\"Views exporter\";s:11:\"description\";s:40:\"Allows exporting multiple views at once.\";s:7:\"package\";s:5:\"Views\";s:12:\"dependencies\";a:1:{i:0;s:5:\"views\";}s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:8:\"6.x-2.11\";s:7:\"project\";s:5:\"views\";s:9:\"datestamp\";s:10:\"1276743614\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/views/views_ui.module','views_ui','module','',0,0,0,-1,0,'a:10:{s:4:\"name\";s:8:\"Views UI\";s:11:\"description\";s:93:\"Administrative interface to views. Without this module, you cannot create or edit your views.\";s:7:\"package\";s:5:\"Views\";s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:1:{i:0;s:5:\"views\";}s:7:\"version\";s:8:\"6.x-2.11\";s:7:\"project\";s:5:\"views\";s:9:\"datestamp\";s:10:\"1276743614\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/webform/webform.module','webform','module','',1,0,0,6318,-1,'a:8:{s:4:\"name\";s:7:\"Webform\";s:11:\"description\";s:49:\"Enables the creation of forms and questionnaires.\";s:4:\"core\";s:3:\"6.x\";s:7:\"package\";s:7:\"Webform\";s:3:\"php\";s:3:\"5.0\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:7:\"version\";N;}'),('profiles/os_demo/modules/contrib/wp_comments/wp_comments.module','wp_comments','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:18:\"WordPress Comments\";s:11:\"description\";s:93:\"Streamlines the appearance of the standard Drupal comment form to appear more like WordPress.\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-1.0\";s:7:\"project\";s:11:\"wp_comments\";s:9:\"datestamp\";s:10:\"1210057815\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/wysiwyg/wysiwyg.module','wysiwyg','module','',1,0,0,6200,0,'a:10:{s:4:\"name\";s:7:\"Wysiwyg\";s:11:\"description\";s:55:\"Allows users to edit contents with client-side editors.\";s:7:\"package\";s:14:\"User interface\";s:4:\"core\";s:3:\"6.x\";s:7:\"version\";s:7:\"6.x-2.1\";s:7:\"project\";s:7:\"wysiwyg\";s:9:\"datestamp\";s:10:\"1268063714\";s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}'),('profiles/os_demo/modules/contrib/wysiwyg_imagefield/wysiwyg_imagefield.module','wysiwyg_imagefield','module','',0,0,0,-1,0,'a:9:{s:4:\"core\";s:3:\"6.x\";s:12:\"dependencies\";a:4:{i:0;s:10:\"imagefield\";i:1;s:6:\"insert\";i:2;s:9:\"jquery_ui\";i:3;s:7:\"wysiwyg\";}s:11:\"description\";s:36:\"An ImageField based IMCE alternative\";s:4:\"name\";s:18:\"WYSIWYG ImageField\";s:7:\"project\";s:18:\"wysiwyg_imagefield\";s:7:\"version\";s:7:\"6.x-1.1\";s:9:\"datestamp\";s:10:\"1281237678\";s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"4.3.5\";}');
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_data`
--

DROP TABLE IF EXISTS `term_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `term_data` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` longtext,
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  KEY `taxonomy_tree` (`vid`,`weight`,`name`),
  KEY `vid_name` (`vid`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term_data`
--

LOCK TABLES `term_data` WRITE;
/*!40000 ALTER TABLE `term_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_hierarchy`
--

DROP TABLE IF EXISTS `term_hierarchy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `term_hierarchy` (
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`,`parent`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term_hierarchy`
--

LOCK TABLES `term_hierarchy` WRITE;
/*!40000 ALTER TABLE `term_hierarchy` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_hierarchy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_node`
--

DROP TABLE IF EXISTS `term_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `term_node` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`,`vid`),
  KEY `vid` (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term_node`
--

LOCK TABLES `term_node` WRITE;
/*!40000 ALTER TABLE `term_node` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_relation`
--

DROP TABLE IF EXISTS `term_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `term_relation` (
  `trid` int(11) NOT NULL AUTO_INCREMENT,
  `tid1` int(10) unsigned NOT NULL DEFAULT '0',
  `tid2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`trid`),
  UNIQUE KEY `tid1_tid2` (`tid1`,`tid2`),
  KEY `tid2` (`tid2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term_relation`
--

LOCK TABLES `term_relation` WRITE;
/*!40000 ALTER TABLE `term_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_synonym`
--

DROP TABLE IF EXISTS `term_synonym`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `term_synonym` (
  `tsid` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`tsid`),
  KEY `tid` (`tid`),
  KEY `name_tid` (`name`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term_synonym`
--

LOCK TABLES `term_synonym` WRITE;
/*!40000 ALTER TABLE `term_synonym` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_synonym` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url_alias`
--

DROP TABLE IF EXISTS `url_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_alias` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `src` varchar(128) NOT NULL DEFAULT '',
  `dst` varchar(128) NOT NULL DEFAULT '',
  `language` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `dst_language_pid` (`dst`,`language`,`pid`),
  KEY `src_language_pid` (`src`,`language`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `url_alias`
--

LOCK TABLES `url_alias` WRITE;
/*!40000 ALTER TABLE `url_alias` DISABLE KEYS */;
INSERT INTO `url_alias` VALUES (1,'user/1','users/opensourcery-administrator',''),(2,'user/2','users/administrator',''),(3,'user/2','users/administrator',''),(4,'user/3','users/editor',''),(5,'node/1','welcome',''),(6,'node/2','about',''),(7,'node/3','contact','');
/*!40000 ALTER TABLE `url_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `pass` varchar(32) NOT NULL DEFAULT '',
  `mail` varchar(64) DEFAULT '',
  `mode` tinyint(4) NOT NULL DEFAULT '0',
  `sort` tinyint(4) DEFAULT '0',
  `threshold` tinyint(4) DEFAULT '0',
  `theme` varchar(255) NOT NULL DEFAULT '',
  `signature` varchar(255) NOT NULL DEFAULT '',
  `signature_format` smallint(6) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `login` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `timezone` varchar(8) DEFAULT NULL,
  `language` varchar(12) NOT NULL DEFAULT '',
  `picture` varchar(255) NOT NULL DEFAULT '',
  `init` varchar(64) DEFAULT '',
  `data` longtext,
  `timezone_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `name` (`name`),
  KEY `access` (`access`),
  KEY `created` (`created`),
  KEY `mail` (`mail`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (0,'','','',0,0,0,'','',0,0,0,0,0,NULL,'','','','a:0:{}',''),(1,'OpenSourcery Administrator','c4ca4238a0b923820dcc509a6f75849b','jhedstrom@opensourcery.com',0,0,0,'','',0,1285794128,1285794150,0,1,NULL,'','','','a:0:{}',''),(2,'Administrator','c4ca4238a0b923820dcc509a6f75849b','alex@opensourcery.com',0,0,0,'','',0,1285794141,0,0,1,NULL,'','','','a:0:{}',''),(3,'Editor','c4ca4238a0b923820dcc509a6f75849b','editor@example.com',0,0,0,'','',0,1285794141,0,0,1,NULL,'','','','b:0;','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_roles` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `rid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES (1,3);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variable`
--

DROP TABLE IF EXISTS `variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variable` (
  `name` varchar(128) NOT NULL DEFAULT '',
  `value` longtext NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variable`
--

LOCK TABLES `variable` WRITE;
/*!40000 ALTER TABLE `variable` DISABLE KEYS */;
INSERT INTO `variable` VALUES ('theme_default','s:5:\"doune\";'),('filter_html_1','i:1;'),('node_options_forum','a:1:{i:0;s:6:\"status\";}'),('drupal_private_key','s:64:\"17b322531afe08592bef70f4aff0ef6241d42891391b8299538cf1f467ae4127\";'),('date_db_tz_support','b:0;'),('menu_masks','a:25:{i:0;i:127;i:1;i:116;i:2;i:63;i:3;i:62;i:4;i:61;i:5;i:59;i:6;i:58;i:7;i:45;i:8;i:31;i:9;i:30;i:10;i:29;i:11;i:24;i:12;i:22;i:13;i:21;i:14;i:15;i:15;i:14;i:16;i:11;i:17;i:10;i:18;i:7;i:19;i:6;i:20;i:5;i:21;i:4;i:22;i:3;i:23;i:2;i:24;i:1;}'),('menu_expanded','a:0:{}'),('conditional_styles_doune','s:269:\"<!--[if IE]>\n<link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"/profiles/os_demo/themes/doune/css/ie.css?P\" />\n<![endif]-->\n<!--[if lte IE 6]>\n<link type=\"text/css\" rel=\"stylesheet\" media=\"all\" href=\"/profiles/os_demo/themes/doune/css/ie6.css?P\" />\n<![endif]-->\n\";'),('date_api_version','s:3:\"5.2\";'),('content_schema_version','i:6009;'),('nodequeue_links','b:1;'),('pathauto_modulelist','a:3:{i:0;s:4:\"node\";i:1;s:4:\"user\";i:2;s:8:\"taxonomy\";}'),('pathauto_taxonomy_supportsfeeds','s:6:\"0/feed\";'),('pathauto_taxonomy_pattern','s:34:\"category/[vocab-raw]/[catpath-raw]\";'),('pathauto_taxonomy_bulkupdate','b:0;'),('pathauto_taxonomy_applytofeeds','b:0;'),('pathauto_taxonomy_2_pattern','s:0:\"\";'),('pathauto_taxonomy_1_pattern','s:0:\"\";'),('pathauto_ignore_words','s:108:\"a,an,as,at,before,but,by,for,from,is,in,into,like,of,off,on,onto,per,since,than,the,this,that,to,up,via,with\";'),('install_task','s:4:\"done\";'),('pathauto_indexaliases','b:0;'),('pathauto_indexaliases_bulkupdate','b:0;'),('pathauto_max_component_length','s:3:\"100\";'),('pathauto_max_length','s:3:\"100\";'),('pathauto_node_bulkupdate','b:0;'),('pathauto_node_forum_pattern','s:0:\"\";'),('pathauto_node_image_pattern','s:0:\"\";'),('pathauto_node_page_pattern','s:0:\"\";'),('pathauto_node_pattern','s:0:\"\";'),('pathauto_node_story_pattern','s:0:\"\";'),('pathauto_punctuation_quotes','i:0;'),('pathauto_separator','s:1:\"-\";'),('pathauto_update_action','s:1:\"2\";'),('pathauto_user_bulkupdate','b:0;'),('pathauto_user_pattern','s:16:\"users/[user-raw]\";'),('pathauto_user_supportsfeeds','N;'),('pathauto_verbose','b:0;'),('pathauto_node_applytofeeds','s:0:\"\";'),('pathauto_punctuation_hyphen','i:1;'),('site_name','s:24:\"OpenSourcery Demo Server\";'),('site_mail','s:24:\"support@opensourcery.com\";'),('anonymous','s:7:\"Visitor\";'),('dblog_row_limit','s:5:\"10000\";'),('user_register','s:1:\"0\";'),('path_redirect_allow_bypass','s:2:\"0;\";'),('path_redirect_auto_redirect','s:2:\"1;\";'),('path_redirect_default_status','s:4:\"301;\";'),('path_redirect_purge_inactive','s:22:\"\'31536000\'; // 1 year.\";'),('path_redirect_redirect_warning','s:2:\"0;\";'),('node_options_page','a:2:{i:0;s:6:\"status\";i:1;s:8:\"revision\";}'),('comment_page','s:1:\"0\";'),('date_default_timezone_name','s:19:\"America/Los_Angeles\";'),('date_default_timezone','s:6:\"-25200\";'),('configurable_timezones','s:1:\"1\";'),('site_footer','s:24:\"&copy;@year OpenSourcery\";'),('site_frontpage','s:7:\"welcome\";'),('css_js_query_string','s:20:\"T8xbPp00000000000000\";'),('file_directory_temp','s:4:\"/tmp\";'),('javascript_parsed','a:0:{}'),('features_ignored_orphans','a:0:{}'),('features_codecache','a:6:{s:20:\"doune_theme_settings\";a:1:{s:12:\"dependencies\";s:32:\"691484d2b878e0df7a34a031f4fcd5e0\";}s:8:\"os_admin\";a:2:{s:12:\"dependencies\";s:32:\"34212c44dbe9aa770045e53f2b35af9e\";s:15:\"user_permission\";s:32:\"9d488670b0ca24508900d51560afec6b\";}s:7:\"os_base\";a:3:{s:12:\"dependencies\";s:32:\"6139844ed09988057e21779918c743c4\";s:9:\"user_role\";s:32:\"e6c99625125c3276f2337cfd4a1c4136\";s:15:\"user_permission\";s:32:\"c31c2a5b538624ec5f1a40a65c6a3d63\";}s:7:\"os_blog\";a:3:{s:12:\"dependencies\";s:32:\"331bb2111c6d3bbe7c6fe5bd871e19d4\";s:15:\"user_permission\";s:32:\"5137d7b3276b0be18ecd1cbedf6e51ac\";s:7:\"content\";s:32:\"ac98ab9b6cff2238c22e3fde3b5b8c37\";}s:8:\"os_event\";a:3:{s:12:\"dependencies\";s:32:\"fcc96f54db9d48158cdb5a6f5dd4e1bc\";s:15:\"user_permission\";s:32:\"ea0505daa4c12dd9de235c22b09876ea\";s:7:\"content\";s:32:\"12faef8937f14f21ffb86b35839f0a3e\";}s:12:\"os_slideshow\";a:2:{s:12:\"dependencies\";s:32:\"2274f8a48511e26f2451754c377c5577\";s:7:\"content\";s:32:\"22a242c49997ce90c0ac88cf194a1b74\";}}'),('features_semaphore','a:0:{}'),('clean_url','b:1;'),('install_time','i:1285794149;'),('install_profile','s:7:\"os_demo\";'),('theme_zen_settings','a:9:{s:17:\"zen_block_editing\";s:1:\"1\";s:14:\"zen_breadcrumb\";s:3:\"yes\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";s:1:\"1\";s:23:\"zen_breadcrumb_trailing\";s:1:\"1\";s:20:\"zen_breadcrumb_title\";s:1:\"0\";s:10:\"zen_layout\";s:18:\"zen-columns-liquid\";s:20:\"zen_rebuild_registry\";s:1:\"0\";s:14:\"zen_wireframes\";s:1:\"0\";}'),('theme_doune_settings','a:24:{s:17:\"zen_block_editing\";i:0;s:14:\"zen_breadcrumb\";s:2:\"no\";s:24:\"zen_breadcrumb_separator\";s:5:\" › \";s:19:\"zen_breadcrumb_home\";i:1;s:23:\"zen_breadcrumb_trailing\";i:1;s:20:\"zen_breadcrumb_title\";i:0;s:20:\"zen_rebuild_registry\";i:0;s:14:\"zen_wireframes\";i:0;s:11:\"toggle_logo\";i:1;s:11:\"toggle_name\";i:1;s:13:\"toggle_slogan\";i:0;s:14:\"toggle_mission\";i:1;s:24:\"toggle_node_user_picture\";i:0;s:27:\"toggle_comment_user_picture\";i:0;s:13:\"toggle_search\";i:0;s:14:\"toggle_favicon\";i:1;s:20:\"toggle_primary_links\";i:1;s:22:\"toggle_secondary_links\";i:1;s:12:\"default_logo\";i:1;s:9:\"logo_path\";s:0:\"\";s:11:\"logo_upload\";s:0:\"\";s:15:\"default_favicon\";i:0;s:12:\"favicon_path\";s:0:\"\";s:14:\"favicon_upload\";s:0:\"\";}'),('admin_menu_rebuild_links','b:1;');
/*!40000 ALTER TABLE `variable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `views_display`
--

DROP TABLE IF EXISTS `views_display`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `views_display` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `id` varchar(64) NOT NULL DEFAULT '',
  `display_title` varchar(64) NOT NULL DEFAULT '',
  `display_plugin` varchar(64) NOT NULL DEFAULT '',
  `position` int(11) DEFAULT '0',
  `display_options` longtext,
  PRIMARY KEY (`vid`,`id`),
  KEY `vid` (`vid`,`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `views_display`
--

LOCK TABLES `views_display` WRITE;
/*!40000 ALTER TABLE `views_display` DISABLE KEYS */;
/*!40000 ALTER TABLE `views_display` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `views_object_cache`
--

DROP TABLE IF EXISTS `views_object_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `views_object_cache` (
  `sid` varchar(64) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `obj` varchar(32) DEFAULT NULL,
  `updated` int(10) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  KEY `sid_obj_name` (`sid`,`obj`,`name`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `views_object_cache`
--

LOCK TABLES `views_object_cache` WRITE;
/*!40000 ALTER TABLE `views_object_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `views_object_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `views_view`
--

DROP TABLE IF EXISTS `views_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `views_view` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `tag` varchar(255) DEFAULT '',
  `view_php` blob,
  `base_table` varchar(64) NOT NULL DEFAULT '',
  `is_cacheable` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `views_view`
--

LOCK TABLES `views_view` WRITE;
/*!40000 ALTER TABLE `views_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `views_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulary`
--

DROP TABLE IF EXISTS `vocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulary` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` longtext,
  `help` varchar(255) NOT NULL DEFAULT '',
  `relations` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hierarchy` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `multiple` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `module` varchar(255) NOT NULL DEFAULT '',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  KEY `list` (`weight`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulary`
--

LOCK TABLES `vocabulary` WRITE;
/*!40000 ALTER TABLE `vocabulary` DISABLE KEYS */;
/*!40000 ALTER TABLE `vocabulary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulary_node_types`
--

DROP TABLE IF EXISTS `vocabulary_node_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulary_node_types` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`type`,`vid`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulary_node_types`
--

LOCK TABLES `vocabulary_node_types` WRITE;
/*!40000 ALTER TABLE `vocabulary_node_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `vocabulary_node_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webform`
--

DROP TABLE IF EXISTS `webform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webform` (
  `nid` int(10) unsigned NOT NULL,
  `confirmation` text NOT NULL,
  `confirmation_format` tinyint(4) NOT NULL DEFAULT '0',
  `redirect_url` varchar(255) DEFAULT NULL,
  `teaser` tinyint(4) NOT NULL DEFAULT '0',
  `allow_draft` tinyint(4) NOT NULL DEFAULT '0',
  `submit_notice` tinyint(4) NOT NULL DEFAULT '0',
  `submit_text` varchar(255) DEFAULT NULL,
  `submit_limit` tinyint(4) NOT NULL DEFAULT '-1',
  `submit_interval` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webform`
--

LOCK TABLES `webform` WRITE;
/*!40000 ALTER TABLE `webform` DISABLE KEYS */;
INSERT INTO `webform` VALUES (3,'Thank you for contacting OpenSourcery.',1,'',0,0,0,'',-1,0);
/*!40000 ALTER TABLE `webform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webform_component`
--

DROP TABLE IF EXISTS `webform_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webform_component` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `form_key` varchar(128) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(16) DEFAULT NULL,
  `value` text NOT NULL,
  `extra` text NOT NULL,
  `mandatory` tinyint(4) NOT NULL DEFAULT '0',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`,`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webform_component`
--

LOCK TABLES `webform_component` WRITE;
/*!40000 ALTER TABLE `webform_component` DISABLE KEYS */;
INSERT INTO `webform_component` VALUES (3,1,0,'email','E-mail','email','','N;',1,1),(3,2,0,'name','Name','textfield','','N;',1,2),(3,3,0,'message','Message','textarea','','N;',1,3);
/*!40000 ALTER TABLE `webform_component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webform_emails`
--

DROP TABLE IF EXISTS `webform_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webform_emails` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `eid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `email` text,
  `subject` varchar(255) DEFAULT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `template` text,
  `excluded_components` text NOT NULL,
  PRIMARY KEY (`nid`,`eid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webform_emails`
--

LOCK TABLES `webform_emails` WRITE;
/*!40000 ALTER TABLE `webform_emails` DISABLE KEYS */;
INSERT INTO `webform_emails` VALUES (3,1,'support@opensourcery.com','default','default','default','default','0');
/*!40000 ALTER TABLE `webform_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webform_roles`
--

DROP TABLE IF EXISTS `webform_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webform_roles` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `rid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`,`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webform_roles`
--

LOCK TABLES `webform_roles` WRITE;
/*!40000 ALTER TABLE `webform_roles` DISABLE KEYS */;
INSERT INTO `webform_roles` VALUES (3,1),(3,2);
/*!40000 ALTER TABLE `webform_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webform_submissions`
--

DROP TABLE IF EXISTS `webform_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webform_submissions` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `is_draft` tinyint(4) NOT NULL DEFAULT '0',
  `submitted` int(11) NOT NULL DEFAULT '0',
  `remote_addr` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`sid`),
  UNIQUE KEY `sid_nid` (`sid`,`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webform_submissions`
--

LOCK TABLES `webform_submissions` WRITE;
/*!40000 ALTER TABLE `webform_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `webform_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webform_submitted_data`
--

DROP TABLE IF EXISTS `webform_submitted_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webform_submitted_data` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `sid` int(10) unsigned NOT NULL DEFAULT '0',
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `no` varchar(128) NOT NULL DEFAULT '0',
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`nid`,`sid`,`cid`,`no`),
  KEY `nid` (`nid`),
  KEY `sid_nid` (`sid`,`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webform_submitted_data`
--

LOCK TABLES `webform_submitted_data` WRITE;
/*!40000 ALTER TABLE `webform_submitted_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `webform_submitted_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wysiwyg`
--

DROP TABLE IF EXISTS `wysiwyg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wysiwyg` (
  `format` int(11) NOT NULL DEFAULT '0',
  `editor` varchar(128) NOT NULL DEFAULT '',
  `settings` text,
  PRIMARY KEY (`format`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wysiwyg`
--

LOCK TABLES `wysiwyg` WRITE;
/*!40000 ALTER TABLE `wysiwyg` DISABLE KEYS */;
/*!40000 ALTER TABLE `wysiwyg` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-09-29 14:08:54
-- MySQL dump 10.13  Distrib 5.1.49-MariaDB, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: di_local
-- ------------------------------------------------------
-- Server version	5.1.49-MariaDB-mariadb82

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_block`
--

DROP TABLE IF EXISTS `cache_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_block` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_content`
--

DROP TABLE IF EXISTS `cache_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_content` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_form`
--

DROP TABLE IF EXISTS `cache_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_form` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_filter`
--

DROP TABLE IF EXISTS `cache_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_filter` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_menu`
--

DROP TABLE IF EXISTS `cache_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_menu` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_page`
--

DROP TABLE IF EXISTS `cache_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_page` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_update`
--

DROP TABLE IF EXISTS `cache_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_update` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `nid` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`nid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `uid` int(10) unsigned NOT NULL,
  `sid` varchar(64) NOT NULL DEFAULT '',
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `cache` int(11) NOT NULL DEFAULT '0',
  `session` longtext,
  PRIMARY KEY (`sid`),
  KEY `timestamp` (`timestamp`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `watchdog`
--

DROP TABLE IF EXISTS `watchdog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watchdog` (
  `wid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(16) NOT NULL DEFAULT '',
  `message` longtext NOT NULL,
  `variables` longtext NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `link` varchar(255) NOT NULL DEFAULT '',
  `location` text NOT NULL,
  `referer` text,
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wid`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-09-29 14:08:54
